#!/usr/bin/env python3
"""Read-only authentication for independent MI28 statement-source review."""
from pathlib import Path
import gzip
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
EXPECTED_PACKET_MANIFEST = 'f34964a178d08ded6e9f7d729f70da606c9edac8475d344e7a5d2c00e1c1f1fd'
checks = 0

def check(ok, message):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def bound(path, digest):
    check(Path(path).is_file(), f'exists {path}')
    check(sha(path) == digest, f'hash {path}')

def verify_manifest(path, expected=None):
    if expected is not None:
        bound(path, expected)
    data = load(path)
    root = Path(path).parent
    rows = data['files']
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p != Path(path)}
    check(actual == {r['path'] for r in rows}, 'exact manifest inventory')
    check(len(rows) == len(actual), 'unique manifest rows')
    for row in rows:
        check(not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts, 'safe relative path')
        bound(root/row['path'], row['sha256'])
        check((root/row['path']).stat().st_size == row['bytes'], 'exact file byte count')
    return rows

review_rows = verify_manifest(HERE/'MANIFEST.json')
binding = load(HERE/'BINDINGS.json')
verdict = load(HERE/'VERDICT.json')
packet = Path(binding['packet'])
check(binding['packet_manifest_sha256'] == verdict['packet_manifest_sha256'] == EXPECTED_PACKET_MANIFEST, 'fixed checkpoint')
rows = verify_manifest(packet/'MANIFEST.json', EXPECTED_PACKET_MANIFEST)
check(len(rows) == binding['payload_count'] == verdict['payloads_bound'] == 16, 'all 16 payloads')
coverage = {r['path']: r for r in binding['read_coverage']}
check(set(coverage) == {r['path'] for r in rows}, 'complete recorded read coverage')
for row in rows:
    check(all(coverage[row['path']][k] == row[k] for k in ['path','bytes','sha256']), 'read coverage exact bytes')
    check(bool(coverage[row['path']]['read_scope']), 'explicit read scope')

definitions = (packet/'NLA/MI28/Definitions.lean').read_text()
challenge = (packet/'Challenge.lean').read_text()
cfg = load(packet/'comparator.json')
names = re.findall(r'^theorem\s+(\w+)', challenge, re.M)
check(len(names) == 20 and cfg['theorem_names'] == ['NLA.MI28.'+n for n in names], '20 exact configured contracts')
check(len(binding['selected_contracts']) == 20, '20 independent semantic rows')
check(cfg['challenge_module'] == 'Challenge' and cfg['solution_module'] == 'Solution', 'separate target modules')
check(cfg['definition_names'] == [], 'no replacement-definition contracts')
check(set(cfg['permitted_axioms']) == {'propext','Classical.choice','Quot.sound'}, 'standard axioms only')
check(challenge.count(':= by sorry') == 20, 'exact statement placeholders')
check(not (packet/'Solution.lean').exists(), 'no proof implementation')
check(not re.search(r'\b(sorry|admit|axiom)\b', definitions), 'definitions have no proof holes or axioms')
check(re.findall(r'^(?:def|abbrev)\s+(\w+)', definitions, re.M) == binding['definition_names'], 'every definition listed')
for i,row in enumerate(binding['selected_contracts']):
    name = names[i]
    m = re.search(r'^theorem\s+'+name+r'\b[\s\S]*?(?=\s*:=\s*by)', challenge, re.M)
    header = m.group().rstrip()
    check(row['contract'] == f'C{i+1:02}' and row['name'] == 'NLA.MI28.'+name, 'contract identity/order')
    check(row['header'] == header and hashlib.sha256(header.encode()).hexdigest() == row['header_sha256'], 'exact reviewed header')
    check(row['line'] == challenge[:m.start()].count('\n')+1, 'header location')
    check(row['source_semantic_disposition'] == 'approve' and bool(row['reason']), 'individual semantic disposition')

# Lexical assertions authenticate the semantic objects inspected in REVIEW.md;
# they are not presented as a theorem prover or a substitute for elaboration.
required = [
    'abbrev Mat (n : ℕ) := Matrix (Fin n) (Fin n) ℂ',
    'CFC.rpow A r', 'CFC.abs X',
    '‖Matrix.toEuclideanCLM (n := Fin n) (𝕜 := ℂ) X‖',
    'hA.isHermitian.eigenvalues₀ (Fin.cast (Fintype.card_fin n).symm i)',
    '∀ n : ℕ, 1 ≤ n → ∀ A B : Mat n, A.PosDef → B.PosDef →',
    '∀ k p : ℝ, 0 ≤ k → 0 ≤ p → p ≤ 2 →',
    'Matrix.det (spectralPower A k + spectralPower (matrixModulus (A * B)) p)',
    'Matrix.det (spectralPower A k + spectralPower A p * spectralPower B p)',
    '∃ hH : (normalizedH A B k p).PosDef,',
    '∃ hZ : (normalizedZ A B k p).PosDef,',
    '(determinantLeft A B k p).im = 0 ∧',
    '(determinantRight A B k p).im = 0 ∧',
    '(determinantRight A B k p).re ≤ (determinantLeft A B k p).re']
for text in required:
    check(text in definitions, 'reviewed concrete semantics')
check('theorem determinant_comparison : DeterminantComparison := by sorry' in challenge, 'final export adds no premise')
check('theorem full_log_majorization : FullLogMajorization := by sorry' in challenge, 'stronger export adds no premise')
state = load(packet/'STATE.json')
for key in ['lean_elaborated','proof_implemented','statement_frozen','independent_statement_approved','comparator_run','published','count_increment']:
    check(state[key] is False, 'historical source-only status: '+key)

external = load(packet/'EXTERNAL-BINDINGS.json')
for row in external['files']:
    bound(row['path'], row['sha256'])
    check(Path(row['path']).stat().st_size == row['bytes'], 'external byte count')
for row in binding['standards'] + binding['library_source_checks'] + [binding['reused_scalar_source']]:
    bound(row['path'], row['sha256'])
check(binding['TauCeti_guidance_revision'] == 'afb424eda89e8ac96d9eb69f6a88972055a4cd1b', 'pinned review standard')
check(binding['library_revision'] == external['pins']['mathlib'] == '0df444a360eaa60ab8c11dca51a86af692955474', 'pinned mathematical APIs')
primary = load(HERE/'PRIMARY-SOURCE-CHECK.json')
fujii = primary['checks'][1]
bound(fujii['retained_text_path'], fujii['retained_text_sha256'])

rescan = load(packet/'status/PUBLIC-TREE-RESCAN.json')
bound(rescan['original_audit'], rescan['original_audit_sha256'])
original = load(rescan['original_audit'])
check(rescan['branch_observation_time'] == original['time'], 'dated source branch enumeration')
for key in ['repository_count','branch_head_count','unique_commit_count']:
    check(rescan[key] == original[key], 'unchanged public enumeration count')
check((rescan['repository_count'], rescan['branch_head_count'], rescan['unique_commit_count']) == (15,269,223), 'bounded public scope')
check(len(rescan['observations']) == len(original['observations']) == 223, 'all immutable tree rows')
old = {r['commit']: r for r in original['observations']}
observed = {r['commit']: r for r in rescan['observations']}
check(set(old) == set(observed) and len(observed) == 223, 'same unique complete commit set')
all_matches = []
canonical_entries = None
for row in rescan['observations']:
    prior = old[row['commit']]
    for key in ['repository','commit','tree_snapshot','sha256']:
        check(row[key] == prior[key], 'authenticated original tree relationship')
    check(prior['complete_tree'], 'original complete-tree observation')
    bound(row['tree_snapshot'], row['sha256'])
    data = json.loads(gzip.decompress(Path(row['tree_snapshot']).read_bytes()))
    entries = data.get('tree', data.get('entries', []))
    check(bool(entries) and not data.get('truncated', False), 'complete retained tree')
    check(len(entries) == row['path_count'], 'exact tree path count')
    matches = [e['path'] for e in entries if re.search(r'mi[-_]?28', e['path'], re.I)
               and (e['path'].endswith('.lean') or '/lean/' in e['path'] or '/formalization' in e['path'] or 'comparator' in e['path'].lower())]
    check(matches == row['matching_formalization_paths'], 'independent exact path rescan')
    all_matches.extend({'repository': row['repository'], 'commit': row['commit'], 'path': p} for p in matches)
    if row['commit'] == 'e7519c46fd249a6a033bfe5d11c66bf47f7f8885':
        canonical_entries = {r['path']: r for r in entries}
check(all_matches == rescan['matches'] and len(all_matches) == 30, 'full raw match list')
allowed = 'matrix-functions-and-stability/MF-07/lean/sources/upstream/matrix-inequalities-and-norms/MI-28'
check(all(r['path'] in [allowed, allowed+'/README.md'] for r in all_matches), 'archive-only matches')
check(canonical_entries is not None, 'actual current canonical tree present')
for row in rescan['canonical_tree_entries']:
    check(row == {k:canonical_entries[row['path']][k] for k in row}, 'canonical tree metadata matches actual retained tree')
for name in ['README.md','solution.md']:
    data = (packet/'sources/canonical'/name).read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    check(blob == canonical_entries['matrix-inequalities-and-norms/MI-28/'+name]['sha'], 'canonical text actual Git blob identity')
pr = load(packet/'status/CURRENT-PR-AND-UPSTREAM.json')
check(pr['upstream']['sha'] == 'e7519c46fd249a6a033bfe5d11c66bf47f7f8885', 'dated upstream observation')
check([r['number'] for r in pr['queries'][0]['items']] == [85,111], 'retained matching PR records')
check(pr['queries'][0]['total_count'] == 2 and not pr['queries'][0]['incomplete_results'], 'bounded first PR query')
check(pr['queries'][1]['total_count'] == 0 and not pr['queries'][1]['incomplete_results'], 'bounded second PR query')

check(verdict['overall'] == 'approve_statement_source_only', 'source-only verdict')
check(not verdict['semantic_blockers'] and not verdict['requested_statement_changes'], 'no remaining statement requests')
check(verdict['reviewer_Lean_runs'] == verdict['reviewer_Lake_runs'] == verdict['reviewer_Comparator_runs'] == 0, 'no reviewer compiler claim')
check(not verdict['proof_implementation_approval'] and not verdict['publication_approval'] and verdict['count_increment'] == 0, 'no implementation or final acceptance')
check(not verdict['statement_freeze_authorized_by_this_review_alone'], 'independent second review/elaboration still required')
check(not verdict['numerical_plan']['actual_kernel_certificate_executed'] and not verdict['numerical_plan']['actual_final_body_consumption_verified'], 'numerical execution honestly pending')
replay = binding['actual_author_checker_replay']
check(replay['exit_code'] == 0 and json.loads(replay['stdout']) == {'result':'PASS','checks':813,'live':True,'sealed':True,'scope':'Readonly integrity and declared scope only. No Lean, Comparator or mathematical proof check.'}, 'actual retained Python replay receipt')
email = re.compile(r'[A-Za-z0-9_.+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+')
for path in HERE.rglob('*'):
    if path.is_file():
        check(path.suffix not in {'.pdf','.olean','.gz','.zip'}, 'no bulk primary or compiled artifacts')
        check(not email.search(path.read_text()), 'no email in review payload')

print(json.dumps({'status':'PASS_READ_ONLY_STATEMENT_REVIEW_INTEGRITY','checks':checks,
    'review_verdict':verdict['overall'],'packet_payloads_authenticated':16,
    'exact_proposed_contract_headers_authenticated':20,'standards_files_authenticated':len(binding['standards']),
    'referenced_external_files_authenticated':len(external['files']),
    'complete_immutable_tree_rows_authenticated_and_rescanned':223,'archive_only_matches':30,
    'canonical_git_blob_identities_recomputed':2,'reviewer_Lean_runs':0,'reviewer_Lake_runs':0,
    'reviewer_Comparator_runs':0,'root_statement_elaboration':'pending in this review',
    'statement_freeze_approved_by_this_review_alone':False,'count_increment':0,
    'scope':'Source-faithfulness review with read-only evidence authentication. No Lean execution, proof completion, official Tau Ceti service or final Linux acceptance.'},indent=2))
