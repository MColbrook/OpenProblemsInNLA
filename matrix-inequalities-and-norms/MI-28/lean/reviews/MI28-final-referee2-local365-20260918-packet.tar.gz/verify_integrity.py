#!/usr/bin/env python3
"""Independent read-only MI28 evidence audit. Does not execute Lean/Comparator."""
from pathlib import Path
import hashlib
import json
import re

B = Path('/private/tmp/nla-lean-next-20260915')
S = B / 'MI28-local365-source-snapshot'
D = B / 'MI28-type-diagnostics-366'
EXPECTED = '7054f5dd7c6bfcd03916565315495d463ccd3fc39db72fad13d19f81d389c089'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def obj(path):
    return json.loads(Path(path).read_text())

def checked(path, expected):
    actual = digest(path)
    assert actual == expected, (str(path), expected, actual)
    return actual

checked(S / 'MANIFEST.json', EXPECTED)
manifest = obj(S / 'MANIFEST.json')
for relative, sha in manifest['files'].items():
    p = S / relative
    assert p.resolve().is_relative_to(S.resolve())
    checked(p, sha)
actual_files = {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}
assert actual_files == set(manifest['files']) | {'MANIFEST.json'}

candidate = S / 'candidate'
sources = {str(p.relative_to(candidate)): p for p in candidate.rglob('*.lean')}
assert len(sources) == 53
imports = {}
for relative, path in sources.items():
    imports[relative] = re.findall(r'^import\s+(\S+)', path.read_text(), re.M)
seen = set()
pending = ['Solution.lean']
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name)
    assert name in sources, name
    for imported in imports[name]:
        relative = imported.replace('.', '/') + '.lean'
        if imported.startswith('NLA.'):
            pending.append(relative)
assert len(seen) == 52
assert 'Challenge.lean' not in seen
assert set(sources) - seen == {'Challenge.lean'}
assert imports['Challenge.lean'] == ['NLA.MI28.Definitions']

# Only the trusted challenge has proof placeholders. Comment stripping here is
# supplementary to a full manual read of all source; it is not a Lean parser.
placeholder_hits = []
for relative in sorted(seen):
    text = sources[relative].read_text()
    text = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
    text = re.sub(r'--[^\n]*', '', text)
    bad = re.findall(r'\b(?:sorry|admit|axiom|unsafe|native_decide|run_cmd|elab|macro|initialize)\b|#eval|@\[(?:extern|implemented_by)', text)
    if bad:
        placeholder_hits.append([relative, bad])
assert not placeholder_hits, placeholder_hits
assert len(re.findall(r'\bby sorry\b', sources['Challenge.lean'].read_text())) == 20

complete = obj(S / 'evidence/MI28-LOCAL-COMPLETE-365.json')
assert complete['actual_local_closure_modules'] == 52
assert complete['exact_contracts'] == 20
assert set(complete['sources']) == seen
for relative, sha in complete['sources'].items():
    checked(sources[relative], sha)
checked(complete['receipt'], complete['receipt_sha256'])
checked(complete['assembly'], complete['assembly_sha256'])
retained = complete['retained_original_evidence']
for path, sha in retained.items():
    checked(path, sha)

origins = []
for entry in complete['commands_and_successful_origins']:
    checked(entry['success_origin_receipt'], entry['receipt_sha256'])
    receipt = obj(entry['success_origin_receipt'])
    assert receipt.get('end')
    assert receipt['threads'] == 1 and receipt['memory_cap_mib'] == 4096
    assert receipt['max_compiler_processes'] == 1
    command = entry['command']
    assert command in receipt['commands']
    assert command['exit_code'] == 0 and command.get('end')
    assert '--threads=1' in command['argv'] and '--memory=4096' in command['argv']
    assert command['source_sha256'] == entry['source_sha256']
    assert complete['sources'][entry['canonical_source_path']] == entry['source_sha256']
    log = Path(entry['success_origin_receipt']).parent / (entry['module'] + '.log')
    checked(log, command['log_sha256'])
    output = command['argv'][command['argv'].index('-o') + 1]
    checked(output, command['output_sha256'])
    for reuse in entry['reuse_chain']:
        checked(reuse['receipt'], reuse['sha256'])
    origins.append({'module': entry['module'], 'source_sha256': entry['source_sha256'],
                    'origin_receipt': entry['success_origin_receipt'],
                    'log_sha256': command['log_sha256'],
                    'output_sha256': command['output_sha256']})
assert len(origins) == 52

config = obj(candidate / 'comparator.json')
assert config['definition_names'] == []
permitted = {'propext', 'Classical.choice', 'Quot.sound'}
assert set(config['permitted_axioms']) == permitted
assert set(complete['observed_axioms']) == set(config['theorem_names'])
for names in complete['observed_axioms'].values():
    assert set(names) == permitted
solution_log = Path(complete['receipt']).parent / 'NLA.MI28.Solution.log'
logtext = solution_log.read_text()
for name in config['theorem_names']:
    assert f"'{name}' depends on axioms: [propext, Classical.choice, Quot.sound]" in logtext
    # #assert_trust is silent on success in this pinned LeanCert version.
    # Its presence in the hash-bound source and successful complete compilation
    # are the available execution evidence; do not invent a success log line.
    assert f'#assert_trust kernel {name}' in sources['Solution.lean'].read_text()

comparison = obj(S / 'evidence/TYPE-COMPARISON-366.json')
checked(D / 'COMPARISON.json', manifest['files']['evidence/TYPE-COMPARISON-366.json'])
checked(comparison['receipt'], comparison['receipt_sha256'])
checked(D / 'challenge-types.json', comparison['challenge_dump_sha256'])
checked(D / 'solution-types.json', comparison['solution_dump_sha256'])
checked(D / 'certificate-body-route.json', comparison['body_graph_sha256'])
challenge = obj(D / 'challenge-types.json')
solution = obj(D / 'solution-types.json')
assert len(challenge) == len(solution) == 20
assert [x['name'] for x in challenge] == config['theorem_names']
assert [x['name'] for x in solution] == config['theorem_names']
for left, right in zip(challenge, solution):
    assert left['levelParams'] == right['levelParams']
    assert left['binderNormalizedType'] == right['binderNormalizedType']
for command in comparison['diagnostic_commands']:
    checked(D / 'sources' / command['argv'][-1], command['source_sha256'])
    receipt = obj(comparison['receipt'])
    assert command in receipt['commands']
    assert command['exit_code'] == 0
    checked(Path(comparison['receipt']).parent / (command['module'] + '.log'), command['log_sha256'])

graph = {row['name']: row for row in obj(D / 'certificate-body-route.json')}
routes = comparison['actual_elaborated_body_routes']
for route_name, route in routes.items():
    for a, b in zip(route, route[1:]):
        assert graph[a]['hasBody'] and b in graph[a]['bodyConstants'], (route_name, a, b)
assert len(graph) == 176

reuse = obj(candidate / 'REUSE-MI24-FURUTA.json')
assert reuse['copied_module_count'] == len(reuse['files']) == 18
for entry in reuse['files']:
    checked(candidate / entry['path'], entry['sha256'])
    checked(entry['source_path'], entry['sha256'])

freeze = obj(S / 'evidence/MI28-STATEMENT-FREEZE-local350.json')
assert freeze['proof_implementation_started_before_gate'] is False
assert freeze['contract_names'] == config['theorem_names']
for relative, sha in freeze['frozen_files'].items():
    checked(candidate / relative, sha)

print(json.dumps({
    'verdict': 'PASS', 'scope': 'Independent file/evidence audit; no Lean or Comparator executed by referee2',
    'snapshot_manifest_sha256': EXPECTED, 'snapshot_files': len(manifest['files']),
    'proof_modules_read_and_hash_checked': 52, 'trusted_challenge_placeholders': 20,
    'proof_placeholder_or_execution_hook_hits': placeholder_hits,
    'actual_local_success_origins_reconciled': len(origins),
    'retained_evidence_hashes_reconciled': len(retained),
    'allowed_axioms': sorted(permitted), 'frozen_types_and_universes_matching': 20,
    'certificate_routes_checked': routes, 'reuse_source_files_equal': 18,
    'root_complete_record_sha256': digest(S / 'evidence/MI28-LOCAL-COMPLETE-365.json'),
    'root_type_comparison_sha256': digest(S / 'evidence/TYPE-COMPARISON-366.json'),
    'verifier_sha256': digest(__file__), 'compiler_invoked': False,
    'Comparator_invoked': False, 'count_change': 0,
    'origins': origins,
}, indent=2))
