# MI28 author navigation

This is navigation by the MI28 proof author, Codex agent
`/root/mi24_full_referee1`, not an independent review or a verification receipt.
The coordinator alone runs the serial local compiler. Actual local execution,
complete-source acceptance, independent nonauthor reviews, and final Linux
Comparator/kernel/sandbox evidence must be recorded separately. No official
Tau Ceti engine or human review is asserted here.

The unchanged original target is the complex positive definite statement in the
canonical README: every n≥1, k≥0 and 0≤p≤2, with genuine spectral powers,
|AB|=((AB)^*(AB))^(1/2), and the Euclidean operator norm. The explicit imaginary
parts in C20 preserve the real-order interpretation of the non-Hermitian right
sum. The frozen source definitions and selected headers are unchanged.

George Stepaniants, Department of Computing and Mathematical Sciences,
California Institute of Technology, receives the canonical mathematical and
code credit. Ghabries, Abbas, Mourad and Assi retain their prior mathematical
credit. The Furuta extension follows Masatoshi Fujii, *Furuta inequality and its
related topics* (2010), Theorem 1.3. The canonical higher-power proof credits
Furuta and Tanahashi; its required specialization is proved internally here.
Unchanged MI24 code retains the original file credits, including Codex agent
`/root/nm04_final_referee1` and the coordinator `/root` for ScalarLogMajorization.
`REUSE-MI24-FURUTA.json` binds the exact required closure to the coordinator's
published MI24 revision 194c94929159b78758fd8b9d281f973c261dfabf and the immutable
MI24 local332 snapshot; no Git operation is performed by this author.

| Frozen contract | Main source module | Mathematical content |
| --- | --- | --- |
| C01 | Numerical | Kernel LeanCert checks the single constant 0<1/2<1. |
| C02 | ModulusPowers | The positive Gram identity \|AB\|²=B A² B; the certified half is an actual exponent-domain proof argument. |
| C03 | SwappedModulus | Exact factor order: the modulus of \|AB\|⁻¹ B is A⁻¹. |
| C04 | NormalizedPositivity | Explicit positive-definiteness witnesses for H and Z. |
| C05 | FurutaBoundary | All r≥0 via Fujii's symbolic finite induction, starting from the pinned proved r∈[0,1] result. |
| C06 | FurutaAdmissible | Boundary Furuta followed by a power in [0,1]. |
| C07 | LowerPowerImplication | q=2 in the common substitution, inverse congruence, then power p∈(0,1]. |
| C08 | HigherPowerImplication | s=p(k+2)/(k+p), q=2/s, and the internally proved negative-power step. |
| C09 | SwapImplication | Apply the proved implication at swapped parameters, using C03, then two powers in [0,1]. |
| C10 | SmallBaseImplication | Finite symbolic split at p=1 and p=k/(k+1), with no parameter grid. |
| C11 | SmallBaseNorm | Shared positive scalar normalization applied to C10. |
| C12 | LargeBaseNorm | Internal positive-product order argument, followed by the same scalar normalization. |
| C13 | NormalizedHomogeneity | Actual scaling of both literal matrices by c^p. |
| C14 | NormalizedContinuity | Fixed unitary diagonalization and scalar exponent continuity. |
| C15 | FullLogMajorization | Every actual complex compound, including degree zero, plus exact total-product equality. |
| C16 | LogOneAddTangent | Direct Mathlib weighted arithmetic-geometric mean inequality with weights 1/(1+a), a/(1+a). |
| C17 | ProductOneAdd | Logarithmic prefix bounds, descending nonnegative weights, and unchanged weighted summation by parts. |
| C18 | DeterminantNormalization | Ordered matrix factorizations of both original sums. |
| C19 | DeterminantReality | Positive scalar determinants of the factors, including the non-Hermitian right sum. |
| C20 | DeterminantComparison | C15, C17, C18 and C19, with the exact final determinant orientation. |

## Important internal routes

`FurutaSubstitution` sets X=A^k, Y=|AB|^p, a=2/p and r=2/k. Its concrete
sandwich is (ABA)². C06 is used at unbounded real r, not only the old MI24
bounded range. The proof of C05 is symbolic induction on a natural upper bound
for r, rather than a computation over a real-parameter grid.

`HigherPowerOrder` starts with C^s≤A^(k+2), C=ABA. Negative power order yields
A^(-2)≤C^(-2p/(k+p)). The invertible factor S=A⁻¹C^(1/2) has SS*=B.
The unchanged proved polar identity exposes B^p, after which powers p-1 and
(k-p+2)/(k+2), both in [0,1], finish the comparison. Neither a negative-Furuta
axiom nor an assumption of the desired inequality occurs.

`PositiveProductOrder` proves the needed positive definite specialization of
the Ghabries et al. product argument internally. For X,Y>0, a,b≥0,
X Y^a X≤Y^b implies X²≤Y^(b-a). Its proof sets C=Y^(a/2)XY^(a/2), then
uses the admitted negative and positive power-order comparisons.
`LargeBaseOrder` applies this with D=BA²B, a=p/k and b=1 after raising
D^(p/2)≤A^k to 2/k. This proves C12 without a separate Cordes theorem or an
unproved invocation of the published large-k inequality.

`NormComparison` uses c=||Z||>0 and scales B by c^(-1/p). `NormalizedOrder`
identifies the two contraction conditions with the exact frozen implication.
`FullNorm` handles p=0 by literal equality of H and Z. For k=0 and p>0 it
uses k_m=1/(m+1), C14, and closedness of the real order. This limit is applied
to each compound pair, so no continuity theorem for sorted eigenvalues is used.

`CompoundTransport` consumes C02 through its half-power consequence and proves
compound covariance of the actual modulus and both normalized matrices.
MI24's unchanged compound algebra uses literal complex minors; its proved
norm formula uses the decreasing multiplicity-preserving spectrum. The
compound dimension is positive for every j≤n, including j=0, where it is one.
The complete required transitive import closure is recorded in REUSE; some
Heron modules are unavoidable imports of the existing combined CompoundSpectral
module, but MI28 does not use their Heron comparison conclusions.

`NormalizedDeterminant` obtains det(|AB|).re=det(A).re det(B).re from C02,
positive determinants, and equality of squares. With a=det(A).re>0 and
b=det(B).re>0, it derives

    det H = a^(p-k) b^p = a^(-k) (ab)^p = det Z.

`DeterminantNormalization` applies one shared ordered factorization. For the
right sum the outer exponents are (k+p)/2 and (k-p)/2; the cross exponents
reduce to p and 0, giving exactly A^k+A^p B^p. For the left sum they are both
k/2, giving exactly A^k+|AB|^p. This avoids any claim that the right sum is
Hermitian. C20 multiplies det(I+H)≤det(I+Z) by the positive det(A^k), hence
proves detRight.re≤detLeft.re and both imaginary-part equalities.

The aggregate `NLA/MI28/Solution.lean` requests explicit axiom and kernel-trust
checks for all 20 contracts. Source imports and this navigation are not a
substitute for the coordinator's actual compiled proof-body dependency audit
from C20 through C02 to C01 and LeanCert's checked dyadic verifiers.
