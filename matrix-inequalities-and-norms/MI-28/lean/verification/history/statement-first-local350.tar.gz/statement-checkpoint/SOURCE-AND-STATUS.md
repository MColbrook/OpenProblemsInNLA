# Source, authorship and bounded duplicate audit

Canonical source: [MI-28 README](https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/e7519c46fd249a6a033bfe5d11c66bf47f7f8885/matrix-inequalities-and-norms/MI-28/README.md)
and [complete solution](https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/e7519c46fd249a6a033bfe5d11c66bf47f7f8885/matrix-inequalities-and-norms/MI-28/solution.md).
The exact retained bytes are under sources/canonical. Status is Solved,
not Lean verified. This is a formalization preparation, not a new resolution.

The author's full analytic contribution is credited to George Stepaniants,
Department of Computing and Mathematical Sciences, California Institute of
Technology. The prior k≥2 range remains Ghabries–Abbas–Mourad–Assi's result;
Furuta, Löwner–Heinz, Fujii's proof, Mathlib and LeanCert retain their credit.
MI24 proof sources were authored with AI assistance by the present agent except
the scalar prefix lemma authored by root; the final library-reuse cleanup was
authored by a different referee. Reuse must retain their existing file headers,
source provenance and licenses. The present agent is not an independent reviewer
of this MI28 statement packet.

Primary references inspected:

* [Ghabries–Abbas–Mourad–Assi, 2020 author manuscript](https://www.researchgate.net/publication/342908148_A_proof_of_a_conjectured_determinantal_inequality),
  [DOI](https://doi.org/10.1016/j.laa.2020.07.013): original Lemma 2.5 proof,
  including the dependencies on Lemmas 2.1–2.3 and the exact parameter range.
* Fujii, Furuta Inequality and Its Related Topics, Ann. Funct. Anal. 1(2),
  2010, pp.28–45, Theorem 1.3 proof p.30. The previously retained primary PDF
  and extracted text are bound by hash/URL in EXTERNAL-BINDINGS.json; they are
  not copied into this packet. Its finite extension is the source for C05.
* The full canonical proof supplies the Lemmas 2,3,5/Corollary 6 route and
  identifies the original thesis question and Tanahashi's related theorem.
  This checkpoint does not claim a new independent full rereview of the thesis
  or an inaccessible third-party document.

The latest retained complete public-tree audit enumerated 15 repositories,
269 branch heads and 223 unique commits at 2026-09-18 04:53:58 UTC. This task
SHA-verified and rescanned all 223 immutable complete trees for MI28/MI-28
formalization paths. Thirty conservative matches are just directory/README
copies under MF07's `lean/sources/upstream/.../MI-28` archive. No target-named
MI28 Lean source/config was found. The raw match list and tree hashes are kept.
This task did not rerun branch enumeration, use Git, or search private/deleted
branches. Differently named formalizations are outside this path-based scope.

Fresh read-only GitHub API queries confirmed main at the same commit and searched
upstream PR titles/bodies for MI-28 and MI28. The first query returned merged
[informal resolution #85](https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/85)
and merged catalog PR #111; the second returned zero. No target-named Lean PR was
found. Comments and differently named PRs are not exhausted. Before publication,
the coordinator must refresh both branch and PR scope.

The root campaign/next-proofs and older inequalities triage were inspected.
No MI28 proof project was found there; the old preflight's missing complex
compound foundation is now largely available from MI24. Remaining order and
determinant-transfer work is recorded honestly in IMPLEMENTATION-PLAN.md.

The pinned Tau Ceti REVIEWING.md plus lean/reuse rubrics, Schiffer/Forsythe
statement structures, Comparator README and formalization.yaml v0.4 schema are
the existing retained MI24 records bound in EXTERNAL-BINDINGS.json. A final
package should apply those standards without copying primary papers whose
redistribution license has not been established. This draft only copies our
canonical source text and small new statement/planning files.
