# MI-28: full-target statement checkpoint

Prepared 18 September 2026 for George Stepaniants, Department of Computing and
Mathematical Sciences, California Institute of Technology. AI-assisted preparation
by Codex agent `/root/nm04_final_referee1`; no contact email is included.

This is a mathematical statement and feasibility checkpoint, not a formalization.
The two Lean files are unelaborated proposed definitions and 20 explicit Challenge
placeholders. There is no Solution, no Lean run, no Comparator run, no approval,
no freeze, no publication and no increase to a solved/verified count.

The canonical README and complete analytic solution were fetched through the
read-only GitHub connector at upstream `e7519c46fd249a6a033bfe5d11c66bf47f7f8885`.
Their Git blob identities were checked against the retained complete public tree;
both match the earlier campaign source copies exactly. The original target is
unchanged. For all complex positive definite n-by-n A,B, n ≥ 1, every real k ≥ 0
and 0 ≤ p ≤ 2, prove

    det(A^k + |AB|^p) ≥ det(A^k + A^p B^p).

Powers are the actual continuous spectral functional calculus; |AB| is the
positive modulus sqrt((AB)* (AB)), with star meaning conjugate transpose. The
right matrix need not be Hermitian. The final contract therefore proves both
imaginary parts are zero and compares real parts. C19 additionally proves strict
positivity. These facts are conclusions, not new hypotheses.

The stronger source conclusion uses

    H = A^((p-k)/2) B^p A^((p-k)/2),
    Z = A^(-k/2) |AB|^p A^(-k/2).

Both are proved positive definite for every real k,p. The sorted eigenvalues are
the actual Mathlib descending eigenvalue list, with multiplicity. Log-majorization
means all prefix products are bounded and the complete products are equal. Empty
prefixes are included, with product one. Positive-definite witnesses in the
existential full-source statement prevent vacuous eigenvalue comparisons.

| Contract | Exact role and source |
|---|---|
| C01 | Exact dyadic half-exponent bounds for the root/polar bridges; intended kernel LeanCert input. |
| C02–C03 | Actual noncommuting modulus square and parameter-swap identity, canonical Lemmas 2 and 5. |
| C04 | Positivity of both normalized matrices; all real exponents. |
| C05–C06 | Unbounded sandwich-parameter Furuta, internally proved; only inner powers a ≥ 1 are needed. |
| C07 | Canonical lower-power order implication, k > 0, k/(k+1) ≤ p ≤ 1. The explicit p > 0 follows from these conditions and is harmless. |
| C08 | Canonical higher-power implication, k > 0, 1 ≤ p ≤ 2. |
| C09 | Universal parameter-swap helper, 0 < p ≤ k, including p=k. Its premise is discharged by the proved C07/C08 cases. |
| C10–C11 | Complete small-base range 0 < k ≤ 2, 0 < p ≤ 2, first in order and then in the actual Euclidean operator norm. |
| C12 | All k ≥ 2, 0 < p ≤ 2, using an internal proof of the required Ghabries–Abbas–Mourad–Assi norm comparison. |
| C13 | Exact positive homogeneity in B, all real k,p. |
| C14 | Continuity in k of the two actual normalized operator norms; supports the endpoint k=0. |
| C15 | Complete source Theorem 1 log-majorization, all canonical parameters and dimensions. |
| C16–C17 | Concrete scalar log(1+x) tangent and prefix-product determinant transfer, without a majorization oracle. |
| C18–C19 | Literal determinant identities and positivity/reality, including the non-Hermitian right sum. |
| C20 | Complete original canonical determinant inequality; no Furuta, norm, spectral, or majorization premise. |

Proof implementation must wait for root statement-only elaboration and TWO
independent source-bound reviews of the exact definitions/headers/config. This
draft is not a claim that those checks have occurred. If elaboration changes a
type, preserve this checkpoint and review the successor delta before freezing.

The source's PSD regularization remark is outside the original PD target and is
not silently substituted for it. The published k ≥ 2 subrange alone would not
complete this project. Neither fixed dimensions, commuting pairs, rational
exponents, p=1, p=2, nor positive k without k=0 can be counted as full MI-28.

The next implementation decision should be based on the explicit gaps in
IMPLEMENTATION-PLAN.md. There is no completed generic Furuta proof in this packet.
