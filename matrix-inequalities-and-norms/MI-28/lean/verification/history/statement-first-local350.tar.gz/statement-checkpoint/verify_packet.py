#!/usr/bin/env python3
"""Read-only integrity/scope check; not Lean, Comparator or mathematical verification."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument('--sealed', action='store_true')
parser.add_argument('--live', action='store_true', help='recheck retained external source/tree bytes')
args = parser.parse_args()
root = Path(__file__).resolve().parent
checks = 0
def check(value, why):
    global checks
    checks += 1
    if not value:
        raise AssertionError(why)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text())

challenge = (root/'Challenge.lean').read_text()
definitions = (root/'NLA/MI28/Definitions.lean').read_text()
names = re.findall(r'^theorem\s+(\w+)', challenge, re.M)
config = read(root/'comparator.json')
check(len(names) == 20, 'twenty proposed complete/dependency contracts')
check(config['theorem_names'] == ['NLA.MI28.'+n for n in names], 'exact config scope')
check(challenge.count(':= by sorry') == 20, 'all bodies are explicit placeholders')
check('sorry' not in definitions and 'axiom' not in definitions, 'transparent definitions only')
check(not (root/'Solution.lean').exists(), 'no proof implementation')
check('∀ k p : ℝ, 0 ≤ k → 0 ≤ p → p ≤ 2' in definitions, 'closed real parameter range')
check('∀ n : ℕ, 1 ≤ n → ∀ A B : Mat n, A.PosDef → B.PosDef' in definitions,
      'arbitrary dimension and complex PD pair')
check('Matrix.det (spectralPower A k + spectralPower A p * spectralPower B p)' in definitions,
      'literal original right determinant')
check('Matrix.det (spectralPower A k + spectralPower (matrixModulus (A * B)) p)' in definitions,
      'literal original left determinant')
state = read(root/'STATE.json')
for key in ['lean_elaborated','proof_implemented','statement_frozen','independent_statement_approved',
            'comparator_run','published','count_increment']:
    check(state[key] is False, 'honest draft status: '+key)
rescan = read(root/'status/PUBLIC-TREE-RESCAN.json')
check(len(rescan['observations']) == 223, 'retained unique tree scope')
check(len(rescan['matches']) == 30, 'conservative raw matches retained')
allowed = 'matrix-functions-and-stability/MF-07/lean/sources/upstream/matrix-inequalities-and-norms/MI-28'
for row in rescan['matches']:
    check(row['path'] in [allowed, allowed+'/README.md'], 'archived README false positive only')
for name in ['README.md','solution.md']:
    data = (root/'sources/canonical'/name).read_bytes()
    entry = next(e for e in rescan['canonical_tree_entries'] if e['path'].endswith('/'+name))
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    check(blob == entry['sha'], 'canonical Git object identity: '+name)
pr = read(root/'status/CURRENT-PR-AND-UPSTREAM.json')
check(pr['upstream']['sha'] == 'e7519c46fd249a6a033bfe5d11c66bf47f7f8885', 'observed upstream')
check(pr['queries'][0]['total_count'] == 2 and not pr['queries'][0]['incomplete_results'], 'first PR search')
check([x['number'] for x in pr['queries'][0]['items']] == [85,111], 'observed PRs')
check(pr['queries'][1]['total_count'] == 0 and not pr['queries'][1]['incomplete_results'], 'second PR search')
for path in root.rglob('*'):
    if path.is_file() and path.suffix in {'.md','.json','.lean','.py'}:
        text = path.read_text()
        check(not re.search(r'(?i)[a-z0-9_.+-]*(?:stepaniants|george)[a-z0-9_.+-]*@[a-z0-9.-]+',text),
              'no George email: '+str(path.relative_to(root)))
if args.live:
    for row in read(root/'EXTERNAL-BINDINGS.json')['files']:
        path = Path(row['path'])
        check(path.is_file() and sha(path) == row['sha256'], 'retained source binding: '+str(path))
    for row in rescan['observations']:
        path = Path(row['tree_snapshot'])
        check(sha(path) == row['sha256'], 'tree digest: '+row['commit'])
        data = json.loads(gzip.decompress(path.read_bytes()))
        entries = data.get('tree', data.get('entries',[]))
        check(bool(entries) and not data.get('truncated',False), 'complete tree: '+row['commit'])
        paths = [e['path'] for e in entries]
        matches = [p for p in paths if re.search(r'mi[-_]?28',p,re.I) and
                   (p.endswith('.lean') or '/lean/' in p or '/formalization' in p or 'comparator' in p.lower())]
        check(matches == row['matching_formalization_paths'], 'exact MI28 path rescan')
if args.sealed:
    manifest = read(root/'MANIFEST.json')
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
    check(actual == {r['path'] for r in manifest['files']}, 'exact packet inventory')
    for row in manifest['files']:
        path = root/row['path']
        check(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'packet digest: '+row['path'])
print(json.dumps({'result':'PASS','checks':checks,'live':args.live,'sealed':args.sealed,
                  'scope':'Readonly integrity and declared scope only. No Lean, Comparator or mathematical proof check.'}))
