#!/usr/bin/env python3
"""Construct documentation only from immutable local MI28 records; no tool execution."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import re

B = Path('/private/tmp/nla-lean-next-20260915')
D = Path(__file__).resolve().parent
S = B / 'MI28-local365-source-snapshot'
C = S / 'candidate'
L = Path('/private/tmp/nla-lean-local-shared-20260916')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def put(name, data):
    p = D / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(data if isinstance(data, str) else json.dumps(data, indent=2, ensure_ascii=False) + '\n')

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
complete = read(B / 'MI28-LOCAL-COMPLETE-365.json')
diag = read(B / 'MI28-type-diagnostics-366/COMPARISON.json')
freeze = read(B / 'MI28-STATEMENT-FREEZE-local350.json')
snapshot = read(S / 'MANIFEST.json')
headers = read(C / 'HEADERS.json')
reuse = read(C / 'REUSE-MI24-FURUTA.json')
refresh = read(B / 'MI28-PREPUBLICATION-REFRESH-20260918.json')
upstream = json.loads(refresh['observations'][0]['stdout'])
canonical = json.loads(refresh['observations'][1]['stdout'])
canonical_bytes = base64.b64decode(canonical['content'])
assert canonical_bytes == (S / 'source-inputs/canonical/README.md').read_bytes()
assert hashlib.sha1(b'blob ' + str(len(canonical_bytes)).encode() + b'\0' + canonical_bytes).hexdigest() == canonical['sha']
assert upstream['sha'] == '9342b3d80c207d3e0bfd61251334d027935c387c'
assert len(complete['sources']) == 52 and len(headers) == 20 and diag['all20_match']

for name in ['README.md', 'solution.md']:
    put('source-inputs/canonical/' + name, (S / 'source-inputs/canonical' / name).read_text())
schema_source = S / 'source-inputs/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json'
put('source-inputs/standards/v0.4.schema.json', schema_source.read_text())
old_lake = (C / 'lakefile.toml').read_text()
old_manifest = (C / 'lake-manifest.json').read_text()
assert old_lake.count('defaultTargets = ["Challenge"]') == 1
assert old_manifest.count('"name": "NLAMI22"') == 1
put('lakefile.toml', old_lake.replace('defaultTargets = ["Challenge"]', 'defaultTargets = ["Solution"]'))
put('lake-manifest.json', old_manifest.replace('"name": "NLAMI22"', '"name": "NLAMI28"'))
put('lean-toolchain', (C / 'lean-toolchain').read_text())

contract_notes = [
    'Kernel-mode fixed certificate: 0 < 1/2 < 1; its lower bound supplies the CFC domain witness in C02.',
    'Concrete modulus square |AB|² = B A² B, in this noncommuting order.',
    'Actual swapped modulus ||AB|⁻¹ B| = A⁻¹.',
    'Positive definiteness of the two normalized matrices for all real k and p.',
    'Unbounded nonnegative Furuta sandwich parameter via symbolic induction from the pinned base case.',
    'Admissible Furuta exponent follows from the boundary case by Loewner–Heinz.',
    'Lower-power order implication in the full stated parameter region.',
    'Higher-power implication, including p=1 and p=2, with the negative-power specialization proved internally.',
    'Parameter interchange with the exact factor order and closed p=k endpoint.',
    'Finite algebraic partition covers 0<k≤2 and 0<p≤2.',
    'Small-base Euclidean operator-norm comparison using genuine positive scalar normalization.',
    'Large-base norm comparison via an internal positive-product order proof; no literature oracle.',
    'Exact positive-scalar homogeneity c^p for H and Z.',
    'Continuity in k of both actual normalized norms using a fixed unitary diagonalization.',
    'Every compound degree gives a descending prefix-product inequality; full determinants agree.',
    'Logarithmic tangent bound proved from weighted AM–GM on positive scalars.',
    'Product-of-one-plus comparison from weighted prefix summation, including empty products.',
    'Ordered noncommutative factorizations give both normalized determinant identities.',
    'Both original complex determinants are positive real, without asserting the right matrix is Hermitian.',
    'Complete original complex determinant inequality for every n≥1, k≥0 and 0≤p≤2.'
]
contracts = []
for i, (name, h) in enumerate(headers.items(), 1):
    found = [p for p in (C / 'NLA/MI28').glob('*.lean') if h['header'] in p.read_text()]
    assert len(found) == 1
    p = found[0]
    contracts.append({'contract': f'C{i:02}', 'declaration': name, 'file': str(p.relative_to(C)),
                      'line': p.read_text()[:p.read_text().index(h['header'])].count('\n') + 1,
                      'source_sha256': sha(p), 'frozen_header_sha256': h['sha256'],
                      'meaning': contract_notes[i-1]})
proof_sources = {p: h for p, h in sorted(complete['sources'].items())}
put('IMPLEMENTATION-MAP.json', {
    'scope': 'Current completed implementation; replaces the historical statement-draft implementation plan.',
    'snapshot_manifest_sha256': sha(S / 'MANIFEST.json'),
    'canonical_problem': 'MI-28', 'complete_original_target': True,
    'proof_closure_modules': 52, 'MI28_component_modules': 33, 'root_aggregate_modules': 1,
    'unchanged_MI24_modules': 18, 'contracts': contracts, 'proof_sources_sha256': proof_sources,
    'aggregate_mapping': complete['source_filename_mapping'],
    'aggregate_mapping_note': 'Root compiled the identical aggregate bytes under NLA/MI28/Solution.lean in the shared local assembly; the canonical package path is Solution.lean. This is a filename relocation, not a second proof module.',
    'reuse_record': 'REUSE-MI24-FURUTA.json',
    'no_import_of_Challenge': True, 'no_literature_axioms': True,
    'mathematical_route': 'PROOF-REVIEWER-MAP.md', 'actual_execution': 'STATE.json'
})

review_names = ['MI28-final-referee1-local365-20260918', 'MI28-final-referee2-local365-20260918']
review_rows = []
for i, name in enumerate(review_names, 1):
    p = B / 'reviews' / name / 'MANIFEST.json'
    review_rows.append({'reviewer': f'/root/mi28_final_referee{i}', 'nonauthor_of_statements_and_proof': True,
                       'verdict': 'PASS' if i == 1 else 'APPROVE',
                       'scope': 'Complete unchanged original target, all 20 frozen contracts and all 52 project proof modules; authenticated saved local evidence.',
                       'origin_manifest': str(p), 'manifest': 'reviews/' + name + '/MANIFEST.json',
                       'manifest_sha256': sha(p),
                       'report': 'reviews/' + name + ('/REVIEW.md' if i == 1 else '/REPORT.md'),
                       'Lean_Lake_Comparator_rerun': False, 'official_TauCeti_engine': False,
                       'human_peer_review': False, 'publication_metadata_approval': 'outside this source verdict'})
statement_rows = []
for r in freeze['reviewers']:
    statement_rows.append({'reviewer': r['agent'], 'manifest': 'reviews/' + Path(r['manifest']).parent.name + '/MANIFEST.json',
                           'origin_manifest': r['manifest'], 'manifest_sha256': r['manifest_sha256'],
                           'scope': 'Independent of statement author before implementation; actual root statement350 evidence is separately recorded.',
                           'later_role': 'Proof and documentation author; not an independent final proof reviewer.' if r['agent'] == '/root/mi24_full_referee1' else 'Coordinator and sole local compiler.'})
put('REVIEW-INDEX.json', {'scope': 'Recorded independent source reviews; current publication metadata awaits root review.',
    'source_snapshot_manifest_sha256': sha(S/'MANIFEST.json'), 'statement_reviews': statement_rows,
    'final_source_reviews': review_rows,
    'guidance': {'project': 'TauCetiProject/TauCetiReview', 'revision': 'afb424eda89e8ac96d9eb69f6a88972055a4cd1b',
                 'criteria': ['correctness', 'generality', 'proof-quality', 'reuse', 'attribution'],
                 'scope': 'Manually applied AI-agent criteria; not official engine execution, human review or an exhaustive Tau Ceti theorem-corpus search.'},
    'author_handoff': {'origin': str(B/'MI28-source-author-handoff-local365/MANIFEST.json'),
                       'sha256': sha(B/'MI28-source-author-handoff-local365/MANIFEST.json'),
                       'scope': 'Author-provided execution/source handoff, not independent review.'},
    'metadata_author': '/root/mi24_full_referee1', 'independent_metadata_review': 'pending',
    'Linux_Comparator': 'NOT RUN', 'accepted_count_change': 0})

put('REVIEW-INDEX.md', '''# MI-28 review index

Two fresh nonauthor agents approved the complete proof source at the identical
local365 snapshot. Their reports cover the original target, every frozen
contract, the full 52-module closure, endpoints, numerical consumption and
saved execution evidence. They ran read-only Python audits, not Lean or
Comparator. The exact report and manifest bindings are in
[REVIEW-INDEX.json](REVIEW-INDEX.json).

- [Referee 1: PASS](reviews/MI28-final-referee1-local365-20260918/REVIEW.md).
- [Referee 2: APPROVE](reviews/MI28-final-referee2-local365-20260918/REPORT.md).
- Earlier statement reviews preceded implementation and are bound by
  [STATEMENT-FREEZE.json](STATEMENT-FREEZE.json), local350.

These are AI-agent reviews applying the pinned Tau Ceti correctness, generality,
proof-quality, reuse and attribution rubrics. They are not an official Tau Ceti
engine run or external human peer review. The proof author previously reviewed
the statement, then became the author; that earlier role does not make the
author an independent final proof reviewer.

Both final reports require the publication default target `Solution`, the root
manifest name `NLAMI28`, and clear historical labeling of the frozen draft
comments and plans. This documentation draft prepares those corrections while
preserving every proof and frozen statement byte. Independent review of the
integrated package and metadata remains pending. The final non-root Linux
Comparator, default-kernel, sandbox and negative-control checks are **NOT RUN**.
''')

fresh = sum(x['success_origin_receipt'] == complete['receipt'] for x in complete['commands_and_successful_origins'])
local = {'run': 'development-365', 'scope': 'MI28 closure only; the mixed batch also records unrelated MF14 failures.',
         'platform': 'macOS', 'compiler_owner': '/root', 'max_processes': 1, 'threads': 1, 'memory_cap_mib': 4096,
         'closure_modules': 52, 'fresh_modules': fresh, 'source_matched_reused_modules': 52-fresh,
         'selected_contracts': 20, 'proof_and_kernel_trust': 'PASS',
         'complete_record': 'verification/local365/LOCAL-COMPLETE.json',
         'complete_record_sha256': sha(B/'MI28-LOCAL-COMPLETE-365.json'),
         'receipt_sha256': complete['receipt_sha256'], 'assembly_sha256': complete['assembly_sha256'],
         'standalone_Lake_build': 'NOT RUN',
         'origin_scope': '52 actual source-matched successful command/log origins, including authenticated historical reuse. Receipt-reading is not another Lean run.'}
typed = {'run': 'development-366', 'record': 'verification/type-diagnostics-366/COMPARISON.json',
         'record_sha256': sha(B/'MI28-type-diagnostics-366/COMPARISON.json'),
         'receipt_sha256': diag['receipt_sha256'], 'matched_contracts': 20,
         'types_and_universes': 'PASS; binder names erased only, separately elaborated environments',
         'actual_body_graph_nodes': diag['body_graph_nodes'],
         'certificate_consumption': 'PASS; actual final body reaches C01 and both generated strict-bound integer-check certificates.',
         'Comparator': 'NOT RUN'}
put('STATE.json', {'as_of_utc': now, 'problem': 'MI-28', 'original_math_status': 'Solved before this formalization',
    'purpose': 'New formalization of the existing complete original target; no new mathematical resolution.',
    'upstream_main_observed': upstream['sha'], 'statement_first_gate': 'PASS local350, immutable three-file boundary and 20 headers',
    'source_snapshot_manifest_sha256': sha(S/'MANIFEST.json'), 'local_compilation': local, 'local_type_and_body_diagnostics': typed,
    'final_source_reviews': [{'reviewer': x['reviewer'], 'verdict': x['verdict'], 'manifest_sha256': x['manifest_sha256']} for x in review_rows],
    'publication_documentation': 'Prepared by proof author; independent metadata/package review pending.',
    'standalone_Lake_execution': 'NOT RUN', 'GitHub_Comparator': 'NOT RUN',
    'GitHub_default_kernel_sandbox_negative_controls': 'NOT RUN', 'publication': 'not performed by this task',
    'accepted_Lean_verification_count_change': 0, 'new_mathematical_resolution_count_change': 0,
    'historical_labels': 'Frozen source draft comments and archived plans record the pre-implementation stage; they do not describe current proof status.'})

put('PUBLIC-SCOPE.json', {'observed_at_utc': refresh['time'], 'origin': str(B/'MI28-PREPUBLICATION-REFRESH-20260918.json'),
    'origin_sha256': sha(B/'MI28-PREPUBLICATION-REFRESH-20260918.json'), 'network_queries_by_documentation_author': 0,
    'scope': refresh['scope'], 'upstream_main': upstream['sha'], 'upstream_main_committer_date': upstream['date'],
    'canonical_path': canonical['path'], 'canonical_git_blob_sha1': canonical['sha'],
    'canonical_readme_sha256': hashlib.sha256(canonical_bytes).hexdigest(), 'matches_reviewed_snapshot': True,
    'canonical_status': 'Solved', 'existing_mathematical_solution_PR': 85,
    'targeted_all_state_MI28_PR_results': json.loads(refresh['observations'][2]['stdout']),
    'targeted_formalization_head': 'sgstepaniants:codex/lean-mi28-verification',
    'targeted_formalization_head_results': json.loads(refresh['observations'][3]['stdout']),
    'limitations': 'This is the root’s recorded dated public query, authenticated locally here. It is not a fresh exhaustive fork/head enumeration or a worldwide novelty/prior-formalization audit. The solution.md snapshot is bound separately; no fresh solution.md network fetch is claimed.',
    'interpretation': 'Formalization of an already solved canonical target, not a new mathematical solution.', 'count_change': 0})

standards = {'TauCetiReview': {'project': 'TauCetiProject/TauCetiReview', 'revision': 'afb424eda89e8ac96d9eb69f6a88972055a4cd1b', 'use': 'AI-agent review guidance only'},
             'Comparator': {'project': 'leanprover/comparator', 'revision': '2312244ac716564a61cc0bf4e107d9abf1757a61', 'use': 'Frozen challenge/solution comparison contract; final execution NOT RUN'},
             'formalization_schema': {'project': 'mathlib-initiative/formalization.yaml', 'revision': '99c678e569c7c4c0772db297c5ddd5e4c9b6322e', 'version': 'v0.4', 'sha256': sha(schema_source)}}
patterns = [
    {'project': 'sgstepaniants/Forsythe', 'revision': '8d1b0c0545a77b40245e84705aa7d273e6c81e62', 'role': 'Separate trusted challenge and exact numerical-target documentation pattern; no imported theorem.'},
    {'project': 'jaumededios/Schiffer', 'revision': '2938e277969c329caf154e48a3d8823f3635c7f1', 'role': 'Challenge separation pattern; no imported theorem.'},
    {'project': 'sgstepaniants/OpenProblemsInNLA', 'revision': '1b9f12661b90f40561e255293e11b2a08d79351e', 'component': 'MF-05', 'role': 'Kernel-mode numerical proof idiom by George Stepaniants. Its separate Matthew J. Colbrook neighborhood argument is not reused.'}]
sources = [
    {'title': 'MI-28 — Ghabries’s determinant comparison for arbitrary nonnegative base powers',
     'id': f'https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/{upstream["sha"]}/matrix-inequalities-and-norms/MI-28/README.md',
     'type': 'canonical problem record', 'relationship': 'formalizes', 'location': 'Complete unchanged positive-definite problem statement', 'author_endorsement': 'n/a',
     'note': 'Already Solved upstream. Snapshot matches the fresh recorded README bytes.'},
    {'title': 'MI-28: a determinant inequality for all nonnegative base powers', 'authors': ['George Stepaniants'],
     'id': 'https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/85', 'type': 'solution note',
     'location': '11 September 2026; Theorem 1, Lemmas 2–5 and Corollary 6', 'relationship': 'formalizes', 'author_endorsement': 'participated',
     'note': 'Exact reviewed text is source-inputs/canonical/solution.md; its historical verification footer predates this Lean development.'},
    {'title': 'Contributions to Matrix Inequalities and Some Applications', 'authors': ['M. M. Ghabries'],
     'id': 'https://www.researchgate.net/publication/361793582_Contributions_to_Matrix_Inequalities_and_Some_Applications',
     'type': 'PhD thesis', 'location': '2022, §2.5 and final Open Problems, Problem 1, pp. 109–110', 'relationship': 'background', 'author_endorsement': 'not-contacted'},
    {'title': 'New determinantal inequalities concerning Hermitian and positive semi-definite matrices', 'authors': ['H. Abbas', 'M. M. Ghabries', 'B. Mourad'],
     'id': 'https://files.ele-math.com/articles/oam-15-07.pdf', 'type': 'article', 'location': 'Operators and Matrices 15 (2021), 105–116, §4 Conjecture 2', 'relationship': 'background', 'author_endorsement': 'not-contacted'},
    {'title': 'A proof of a conjectured determinantal inequality', 'authors': ['M. M. Ghabries', 'H. Abbas', 'B. Mourad', 'A. Assi'],
     'id': 'doi:10.1016/j.laa.2020.07.013', 'type': 'article', 'location': 'Linear Algebra and its Applications 605 (2020), 21–28; Lemma 2.5 and Theorem 1.1',
     'relationship': 'independently-proves', 'author_endorsement': 'not-contacted', 'note': 'Credit for the known large-base range is preserved. C12 proves the necessary norm comparison internally with positive-product order; the paper is not a Lean axiom.'},
    {'title': 'Furuta inequality (original 1987 theorem)', 'authors': ['T. Furuta'], 'id': 'Proceedings of the American Mathematical Society 101 (1987), 85–88', 'type': 'article', 'relationship': 'adapts', 'author_endorsement': 'not-contacted', 'note': 'The required boundary and admissible variants are proved in the imported and new Lean sources.'},
    {'title': 'Furuta inequality and its related topics', 'authors': ['Masatoshi Fujii'], 'id': 'Annals of Functional Analysis 1 (2010), no. 2, 28–45', 'type': 'article', 'location': 'Theorem 1.3, printed page 30', 'relationship': 'adapts', 'author_endorsement': 'not-contacted', 'note': 'Route for the bounded base and symbolic extension to every nonnegative sandwich parameter.'},
    {'title': 'The Furuta inequality with negative powers', 'authors': ['K. Tanahashi'], 'id': 'doi:10.1090/S0002-9939-99-04705-X', 'type': 'article', 'location': 'Proceedings of the American Mathematical Society 127 (1999), 1683–1692; Propositions 1–2 and Theorem 3', 'relationship': 'background', 'author_endorsement': 'not-contacted', 'note': 'The needed specialization is proved internally using power order and polar identities; no negative-Furuta axiom.'}
]
put('SOURCE-ATTRIBUTION.json', {'problem': 'MI-28', 'George_Stepaniants': {'name': 'George Stepaniants', 'affiliation': 'Department of Computing and Mathematical Sciences, California Institute of Technology', 'roles': ['Existing full analytic solution', 'Formalization contribution with substantial ChatGPT/Codex assistance']},
    'agent_roles': {'statement_author': '/root/nm04_final_referee1', 'MI28_proof_and_docs_author': '/root/mi24_full_referee1', 'sole_local_compiler_and_coordinator': '/root', 'fresh_final_nonauthor_reviewers': ['/root/mi28_final_referee1', '/root/mi28_final_referee2'], 'MI24_prior_matrix_code': '/root/nm04_final_referee1', 'MI24_prior_scalar_prefix_code': '/root'},
    'mathematical_sources': sources,
    'unchanged_code_reuse': {'record': 'REUSE-MI24-FURUTA.json', 'sha256': sha(C/'REUSE-MI24-FURUTA.json'), 'published_revision': reuse['coordinator_designated_published_revision'], 'source_snapshot_manifest_sha256': reuse['source_snapshot_manifest_sha256'], 'files': reuse['files'], 'scope_note': reuse['transitive_scope_note'], 'credit': 'All original per-file MI24, MI22 and MF06 provenance/credits remain intact; the imported libraries retain their authorship. This task authenticates stored bytes and root publication evidence, without running Git.'},
    'adapted_code_patterns': reuse['attributed_patterns'], 'workflow_patterns': patterns, 'pinned_standards': standards,
    'libraries': {'Mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'LeanCert': '621a43d7cf21f87872392a01e874f2f1dbddc926', 'credit': 'Mathlib and LeanCert contributors; all proofs use their pinned public interfaces and retain imported authorship.'},
    'source_material_policy': 'Small canonical project README/solution and the pinned metadata schema are included. No third-party primary paper PDF or bulk extracted text is copied.',
    'author_endorsement_note': 'Participation by George concerns his own work. No endorsement or contact is asserted for other mathematical authors.'})

put('LAKE-CONFIGURATION.json', {'project_name': 'NLAMI28', 'default_target': 'Solution',
    'toolchain': (D/'lean-toolchain').read_text().strip(),
    'source_snapshot_configuration': {p: sha(C/p) for p in ['lakefile.toml','lake-manifest.json','lean-toolchain']},
    'publication_configuration': {p: sha(D/p) for p in ['lakefile.toml','lake-manifest.json','lean-toolchain']},
    'permitted_changes': {'lakefile.toml': 'defaultTargets: Challenge → Solution only', 'lake-manifest.json': 'root name: NLAMI22 → NLAMI28 only'},
    'entire_dependency_package_objects_unchanged': True,
    'dependency_pins': [{'name': p['name'], 'url': p['url'], 'rev': p['rev']} for p in read(D/'lake-manifest.json')['packages']],
    'actual_campaign_build': 'Root direct serial Lean compilation, not a Lake invocation; exact command lines remain in local365/366 evidence.',
    'canonical_aggregate': complete['source_filename_mapping'],
    'standalone_Lake_build_executed': False, 'Linux_Comparator_executed': False,
    'future_reproduction': 'After integration into the standalone project, lake build Solution (or the default lake build) targets the proof. This command is documented, not executed by this task.'})
put('PACKAGING-CHANGES.json', {'proof_source_changes': [], 'frozen_file_changes': [],
    'configuration_changes': [{'file': p, 'before_sha256': sha(C/p), 'after_sha256': sha(D/p), 'change': c} for p,c in [('lakefile.toml','Default target Challenge to Solution'),('lake-manifest.json','Root package name NLAMI22 to NLAMI28')]],
    'archive_without_editing': [{'source': p, 'destination': 'history/statement-draft/'+p, 'sha256': sha(C/p)} for p in ['IMPLEMENTATION-PLAN.md','NUMERICAL_TARGETS.md','lakefile.toml','lake-manifest.json']],
    'replace_current_documentation': ['README.md','NUMERICAL_TARGETS.md','IMPLEMENTATION-MAP.json','PROOF-REVIEWER-MAP.md','formalization.yaml','STATE.json'],
    'frozen_comment_policy': 'Keep the UNELABORATED/no-proof draft comments in Challenge/Definitions byte-for-byte. The README and current maps explicitly identify them as historical.',
    'independent_review_required': 'Root must review the integrated docs and metadata separately from the two existing proof-source verdicts.'})

put('formalization.yaml', {'version': 'v0.4',
    'project': {'name': 'MI-28: determinant comparison for every nonnegative base power',
                'description': 'For every complex positive definite pair A,B in every dimension n≥1, every real k≥0 and 0≤p≤2, det(A^k+|AB|^p)≥det(A^k+A^pB^p), with determinant reality/positivity and stronger normalized log-majorization proved.',
                'authors': ['George Stepaniants'], 'responsible_maintainers': ['George Stepaniants'], 'license': 'Apache-2.0',
                'affiliation': 'Department of Computing and Mathematical Sciences, California Institute of Technology',
                'contribution_note': 'Substantial ChatGPT/Codex assistance; exact prior mathematical/code authorship and distinct agent roles are in SOURCE-ATTRIBUTION.json.'},
    'repository': {'role': 'substantive-development'}, 'sources': sources,
    'related_formalizations': [{'id': 'https://github.com/sgstepaniants/OpenProblemsInNLA/tree/'+reuse['coordinator_designated_published_revision']+'/matrix-inequalities-and-norms/MI-24/lean', 'relationship': 'builds-on', 'note': '18 unchanged required MI24 modules; complete hashes, original credits and minimal transitive closure in REUSE-MI24-FURUTA.json.'}]
        + [{'id': 'https://github.com/'+p['project']+'/tree/'+p['revision'], 'relationship': 'adapts', 'note': p['role']} for p in patterns],
    'automation': {'methods': [{'method': 'agent', 'framework': 'OpenAI Codex',
        'tool_setup': 'Statement-first independent review and frozen Challenge/Definitions; pinned Mathlib and kernel-mode LeanCert; root alone ran one local Lean process with --threads=1 --memory=4096. Fresh nonauthor proof reviewers read all sources and authenticated saved evidence without compiling.',
        'prompting_notes': 'Preserve the original complex target and all real parameter endpoints, minimize computation, preserve authorship, and distinguish actual local compilation from final Linux Comparator.'}],
        'notes': 'This documentation task ran only filesystem reads/writes and read-only Python validation. No model-version, total-runtime or cost estimate is invented.'},
    'status': {'scope': 'Complete original MI28 proof source locally compiled and independently source-reviewed; standalone package and final Linux acceptance pending.', 'sorry_count': 0, 'sorry_in_definitions': 0,
               'axioms': ['propext','Classical.choice','Quot.sound'], 'deliberate_challenge_placeholders': 20,
               'main_results': [{'declaration': r['declaration'], 'file': r['file'], 'sorry_count': 0, 'axioms': complete['observed_axioms'][r['declaration']],
                                 'comparator_config': 'comparator.json', 'literature_dependencies': [], 'contract': r['contract'], 'source_sha256': r['source_sha256'],
                                 'verification_status': 'Root local365 proof/trust and local366 type/body diagnostics passed; two nonauthor source reviews approved; GitHub Comparator NOT RUN.'} for r in contracts],
               'local_proof': local, 'local_type_diagnostic': typed, 'final_Linux_status': 'NOT RUN', 'accepted_count_change': 0},
    'fidelity': {'divergences': 'The complete canonical positive-definite target and all parameter ranges are unchanged. Literal complex matrices, CFC powers/modulus, Euclidean operator norms and decreasing eigenvalues are used. The large-base range is proved internally through positive-product order instead of assuming the cited Ghabries et al. comparison; unbounded Furuta is proved by symbolic induction. At k=0, continuity of each compound norm replaces informal ordered-eigenvalue continuity. Weighted AM–GM and finite prefix summation prove the scalar determinant comparison instead of invoking a general majorization characterization. The optional positive-semidefinite extension in the analytic remark is outside the canonical positive-definite target. No literature axiom or unproved implication is a final premise. Frozen draft comments are preserved as historical bytes; current status is in STATE.json.'},
    'review': {'status': 'agent-reviewed (complete proof-source scope; publication checks pending)', 'reviewers': ['/root/mi28_final_referee1 — independent nonauthor final proof reviewer','/root/mi28_final_referee2 — independent nonauthor final proof reviewer'],
               'notes': 'Both fresh agents read the canonical target and entire 52-module closure and approved all 20 frozen contracts. These apply pinned Tau Ceti rubrics, not official engine execution or external human peer review. They did not rerun Lean/Comparator. The earlier statement reviewer /root/mi24_full_referee1 subsequently authored the proof and these docs, so is not a final independent proof reviewer. Metadata/package review remains separate and pending. See REVIEW-INDEX.json.'},
    'alignment': {'canonical_problem': 'MI-28', 'current_readme_revision': upstream['sha'], 'canonical_path': 'matrix-inequalities-and-norms/MI-28/README.md',
                  'contracts': 'IMPLEMENTATION-MAP.json', 'frozen_statement': 'STATEMENT-FREEZE.json', 'numerical_targets': 'NUMERICAL_TARGETS.md',
                  'formal_target': 'NLA.MI28.DeterminantComparison', 'formal_proof': 'NLA.MI28.determinant_comparison',
                  'stronger_result': 'NLA.MI28.full_log_majorization', 'extra_substantive_hypotheses': False},
    'acknowledgements': 'George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology. Preserve the original problem and prior results of Ghabries, Abbas, Mourad and Assi; Furuta, Fujii and Tanahashi background; all unchanged MI24/MI22/MF06 source credits; the separate MF05 numerical idiom; and Mathlib/LeanCert authorship. Schiffer and Forsythe supply workflow patterns, not mathematical premises.'})

external = [B/'MI28-LOCAL-COMPLETE-365.json', B/'MI28-STATEMENT-FREEZE-local350.json', S/'MANIFEST.json',
    B/'MI28-type-diagnostics-366/COMPARISON.json', B/'MI28-type-diagnostics-366/challenge-types.json',
    B/'MI28-type-diagnostics-366/solution-types.json', B/'MI28-type-diagnostics-366/certificate-body-route.json',
    B/'MI28-PREPUBLICATION-REFRESH-20260918.json', B/'MI28-source-author-handoff-local365/MANIFEST.json',
    B/'MI28-source-author-handoff-local365-verification.json', B/'MF05-canonical-package-local141/STANDARD-BINDINGS.json',
    B/'MF18-publication-docs-draft/MANIFEST.json', L/'ASSEMBLY-365.json', L/'ASSEMBLY-366.json',
    L/'runs/development-365/RECEIPT.json', L/'runs/development-366/RECEIPT.json', L/'runs/development-350/RECEIPT.json']
external += [Path(r['origin_manifest']) for r in review_rows+statement_rows]
external += [B/'reviews/MI28-final-referee1-local365-20260918-verify.py']
external += sorted((B/'MI28-type-diagnostics-366/sources/NLA/MI28Diagnostics').glob('*.lean'))
external += [S/'evidence/MI28-ROOT-REUSE-CHECK-local363.json']
put('DOCUMENT-SCOPE.json', {'created_at_utc': now, 'author_agent': '/root/mi24_full_referee1', 'role': 'MI28 proof author and publication-documentation author; not final independent proof referee.',
    'task': 'Documentation and two publication metadata corrections only', 'independent_metadata_review': False,
    'Lean_Lake_Comparator_executions_by_this_task': 0, 'Git_or_network_operations_by_this_task': 0, 'proof_source_edits_by_this_task': 0,
    'only_payload_write_directory': str(D), 'source_snapshot': str(S), 'source_snapshot_manifest_sha256': sha(S/'MANIFEST.json'),
    'external_inputs_sha256': {str(p): sha(p) for p in external},
    'expected_frozen_files': freeze['frozen_files'], 'expected_proof_sources': proof_sources,
    'read_scope': 'Current canonical README and full analytic solution; both complete final source reports and their scopes; actual local365 completion and local366 comparison/body route; frozen definitions/headers and source semantics; pinned schema and standards/pattern provenance; earlier MF18 docs structure. This is metadata authoring, not a third independent proof review.',
    'checker_scope': 'Read-only schema, hash, closure, contract, configuration, recorded command/log lineage, type/body graph and review-manifest authentication; no compiler/kernel rerun.',
    'checker_receipt': '../MI28-publication-docs-draft-CHECK.json',
    'checker_receipt_excluded_from_manifest': 'Receipt binds final manifest and checker hash externally to avoid self-hash cycles.',
    'max_payload_bytes': 500000, 'count_change': 0})

destinations = [
    (B/'MI28-STATEMENT-FREEZE-local350.json', 'STATEMENT-FREEZE.json'),
    (B/'MI28-LOCAL-COMPLETE-365.json', 'verification/local365/LOCAL-COMPLETE.json'),
    (B/'MI28-type-diagnostics-366', 'verification/type-diagnostics-366'),
    (B/'MI28-PREPUBLICATION-REFRESH-20260918.json', 'verification/public-scope/MI28-PREPUBLICATION-REFRESH-20260918.json'),
    (S/'evidence/MI28-ROOT-REUSE-CHECK-local363.json', 'verification/reuse/MI28-ROOT-REUSE-CHECK-local363.json')]
destinations += [(Path(r['origin_manifest']).parent, str(Path(r['manifest']).parent)) for r in review_rows+statement_rows]
destinations += [(B/'reviews/MI28-final-referee1-local365-20260918-verify.py','reviews/MI28-final-referee1-local365-20260918-verify.py')]
put('INTEGRATION-REQUIREMENTS.json', {'scope': 'This compact draft is documentation/configuration only, not a duplicate standalone proof package. Root separately assembles the source and evidence.',
    'canonical_publication_directory': 'matrix-inequalities-and-norms/MI-28/lean', 'source_snapshot': str(S), 'source_snapshot_manifest_sha256': sha(S/'MANIFEST.json'),
    'preserve': 'All 52 reviewed proof source bytes, all three frozen files, all 20 headers, LICENSE, and the unchanged REUSE-MI24-FURUTA.json.',
    'canonical_aggregate_mapping': complete['source_filename_mapping'],
    'configuration': 'Copy the three supplied Lake files; only two approved metadata fields differ from the reviewed snapshot. Dependency objects and toolchain are identical. No standalone Lake execution is claimed.',
    'docs_to_copy': ['README.md','formalization.yaml','NUMERICAL_TARGETS.md','IMPLEMENTATION-MAP.json','PROOF-REVIEWER-MAP.md','SOURCE-ATTRIBUTION.json','REVIEW-INDEX.json','REVIEW-INDEX.md','STATE.json','PUBLIC-SCOPE.json','LAKE-CONFIGURATION.json','PACKAGING-CHANGES.json','lakefile.toml','lake-manifest.json','lean-toolchain','source-inputs'],
    'archive_historical_records': read(D/'PACKAGING-CHANGES.json')['archive_without_editing'],
    'evidence_destinations': [{'original': str(p), 'destination': q} for p,q in destinations],
    'source_and_command_evidence': 'Retain exact source-matched successful origin receipts, commands, logs, assembly hashes and authenticated reuse lineage named by local365; retain local350 statement evidence and local366 actual diagnostic sources/dumps/commands/logs. A relocation map must authenticate bytes; preserve historical absolute paths and do not edit sealed reports. The author handoff already retains the source/origin lineage and need not be duplicated wholesale.',
    'pending_checks': ['Independent root metadata/package review','Canonical standalone Lake/configuration integration check by authorized root, with exact execution or explicit non-execution recorded','Final standalone import/hash closure and co-located schema/privacy checks','Actual non-root Linux GitHub Comparator, default-kernel, sandbox and negative/rejection controls on the exact publication commit'],
    'excluded_bulk_material': ['Primary-paper PDFs or bulk extracted paper text','Dependency caches','Compiled outputs','Bulk recursive Git/API archives'],
    'doc_checker_portability': 'verify_documents.py authenticates the original local campaign records. Preserve it as draft provenance; root must separately validate the relocated published package and evidence rather than pretending the local absolute paths are portable.',
    'count_change_authorized_by_this_draft': 0, 'post_Linux_status': 'Append actual tested commit/run ID/results only after execution. Do not mark NOT RUN checks passed in advance.'})

audit_dir = B/'MI28-current-public-audit-v2-20260918'
audit = read(audit_dir/'AUDIT.json')
classification_file = B/'MI28-public-audit-classification-20260918.json'
classification = read(classification_file)
assert classification['audit_sha256'] == sha(audit_dir/'AUDIT.json')
public = read(D/'PUBLIC-SCOPE.json')
public['public_branch_audit'] = {
    'origin': str(audit_dir/'AUDIT.json'), 'sha256': sha(audit_dir/'AUDIT.json'),
    'classification_origin': str(classification_file), 'classification_sha256': sha(classification_file),
    'enumeration_time': audit['enumeration_time'], 'completion_time': audit['time'],
    'repositories': audit['repository_count'], 'branch_heads': audit['branch_head_count'],
    'complete_immutable_trees': audit['unique_commit_count'], 'fresh_tree_traversals': audit['fresh_tree_count'],
    'matching_commits': len(audit['matches']), 'scope': audit['scope'],
    'result': 'All 17 matching commits contain only the archived canonical MI28 README below MF07/lean/sources/upstream, with blob 7d089f64d6a96b004f4fef1851076b7b4f3320f6. No MI28 Lean source or formalization manifest was found in the recorded ID/path scope.',
    'resumption': 'The initial partial audit failed because two immutable commits were unavailable locally. Root fetched them and resumed the same enumerated head snapshot, using complete local Git traversal for truncated API trees.',
    'limitations': 'Dated visible public upstream/direct-fork branches only. No continuous-latest, private/deleted/unpublished or differently named semantic-exhaustiveness claim. The documentation author did not repeat Git or network enumeration.'}
public['limitations'] = 'The targeted PR refresh and subsequent complete visible public-branch audit are distinct dated root observations. This task authenticates their records without Git/network access. The solution.md snapshot is bound separately; no fresh solution.md network fetch is claimed.'
put('PUBLIC-SCOPE.json', public)
review_index = read(D/'REVIEW-INDEX.json')
review_index['root_integrity_replays'] = []
for i in [1,2]:
    p = B/f'reviews/MI28-referee{i}-ROOT-REPLAY-20260918.json'
    replay = read(p)
    assert replay['exit_code'] == 0 and json.loads(replay['stdout'])['verdict'] == 'PASS'
    review_index['root_integrity_replays'].append({'origin': str(p), 'sha256': sha(p), 'executor': '/root',
        'scope': 'Actual read-only replay of the reviewer integrity script; not Lean or Comparator.'})
put('REVIEW-INDEX.json', review_index)
scope = read(D/'DOCUMENT-SCOPE.json')
for p in [audit_dir/'AUDIT.json', audit_dir/'REPOSITORIES.json', audit_dir/'FRESH-BRANCH-HEADS.json', classification_file] + [B/f'reviews/MI28-referee{i}-ROOT-REPLAY-20260918.json' for i in [1,2]]:
    scope['external_inputs_sha256'][str(p)] = sha(p)
scope['read_scope'] += ' Subsequent root public-branch audit and both root read-only reviewer replays were also read and authenticated.'
put('DOCUMENT-SCOPE.json', scope)
integration = read(D/'INTEGRATION-REQUIREMENTS.json')
integration['evidence_destinations'] += [{'original': str(audit_dir/p), 'destination': 'verification/public-scope/'+p} for p in ['AUDIT.json','REPOSITORIES.json','FRESH-BRANCH-HEADS.json']]
integration['evidence_destinations'].append({'original': str(classification_file), 'destination': 'verification/public-scope/CLASSIFICATION.json'})
integration['evidence_destinations'] += [{'original': str(B/f'reviews/MI28-referee{i}-ROOT-REPLAY-20260918.json'), 'destination': f'reviews/MI28-referee{i}-ROOT-REPLAY-20260918.json'} for i in [1,2]]
integration['public_audit_storage'] = 'Retain compact audit/heads/repository records and their exact original tree-snapshot hashes. Keep bulky recursive trees as external campaign evidence; do not silently imply that the compact package embeds them.'
put('INTEGRATION-REQUIREMENTS.json', integration)
print(json.dumps({'generated_document_directory': str(D), 'contracts': len(contracts), 'source_hashes': len(proof_sources), 'source_edits': 0, 'compiler_invocations': 0}))
