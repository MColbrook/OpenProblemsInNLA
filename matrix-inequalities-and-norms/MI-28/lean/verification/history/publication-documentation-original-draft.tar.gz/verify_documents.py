#!/usr/bin/env python3
"""Read-only MI28 documentation audit. No subprocess, compiler, Git or network."""
from pathlib import Path
import base64
import gzip
import hashlib
import json
import re
import sys
import jsonschema

D = Path(__file__).resolve().parent
checks = []

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def hashcheck(p, expected):
    require(sha(p) == expected, 'hash mismatch: ' + str(p))

def manifestcheck(p, strict=False):
    m = read(p)
    f = m['files']
    entries = f.items() if isinstance(f,dict) else [(r['path'],r['sha256']) for r in f]
    names = []
    for rel, expected in entries:
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts, 'unsafe manifest path')
        if isinstance(expected,dict):
            expected = expected['sha256']
        hashcheck(Path(p).parent/rel, expected)
        names.append(rel)
    if strict:
        actual = {str(f.relative_to(Path(p).parent)) for f in Path(p).parent.rglob('*') if f.is_file()}
        require(actual == set(names)|{Path(p).name}, 'unlisted or missing manifest files: '+str(p))
    return len(names)

doc_manifest = D/'MANIFEST.json'
payload_count = manifestcheck(doc_manifest, True)
payload_bytes = sum(p.stat().st_size for p in D.rglob('*') if p.is_file())
require(payload_bytes < 500000, 'compact payload limit exceeded')
require(not any(p.suffix in {'.lean','.pdf','.olean','.gz'} for p in D.rglob('*') if p.is_file()), 'unexpected proof/bulk payload')
checks.append('Sealed documentation manifest, exact payload membership and <500 KB size')
scope = read(D/'DOCUMENT-SCOPE.json')
S = Path(scope['source_snapshot'])
C = S/'candidate'
B = S.parent
L = Path('/private/tmp/nla-lean-local-shared-20260916')
for p,h in scope['external_inputs_sha256'].items():
    hashcheck(p,h)
snapshot_count = manifestcheck(S/'MANIFEST.json', True)
hashcheck(S/'MANIFEST.json',scope['source_snapshot_manifest_sha256'])
checks.append('All external document inputs and all '+str(snapshot_count)+' snapshot payload hashes')

metadata = read(D/'formalization.yaml')
schema = read(D/'source-inputs/standards/v0.4.schema.json')
hashcheck(D/'source-inputs/standards/v0.4.schema.json','25ff6b25ca4511635aff4443cf20480c15e59dddf19591c730950b442ea54fce')
jsonschema.Draft7Validator.check_schema(schema)
jsonschema.Draft7Validator(schema).validate(metadata)
require(metadata['version']=='v0.4', 'wrong schema version')
require(metadata['status']['sorry_count']==0 and metadata['status']['sorry_in_definitions']==0, 'incorrect status')
require(metadata['status']['final_Linux_status']=='NOT RUN', 'unrun Linux claim changed')
require(metadata['status']['accepted_count_change']==0, 'count changed')
require(len(metadata['related_formalizations'])==len({r['id'] for r in metadata['related_formalizations']}), 'duplicate formalization provenance')
checks.append('Pinned v0.4 schema and conservative current status')

complete = read(B/'MI28-LOCAL-COMPLETE-365.json')
freeze = read(B/'MI28-STATEMENT-FREEZE-local350.json')
proof = complete['sources']
require(proof == scope['expected_proof_sources'], 'source inventory differs')
require(len(proof)==52, 'wrong module count')
for p,h in proof.items():
    hashcheck(C/p,h)
for p,h in freeze['frozen_files'].items():
    hashcheck(C/p,h)
require(freeze['frozen_files']==scope['expected_frozen_files'], 'freeze differs')

def import_closure(p, result):
    if p in result:
        return
    require(p in proof, 'unexpected project import '+p)
    result.add(p)
    for group in re.findall(r'^import\s+([^\n]+)',(C/p).read_text(),re.M):
        for module in group.split():
            require(module != 'Challenge', 'solution imports challenge')
            if module.startswith('NLA.'):
                import_closure(module.replace('.','/')+'.lean',result)

closure=set()
import_closure('Solution.lean',closure)
require(closure==set(proof), 'full 52-module closure differs')
require(sum(p.startswith('NLA/MI28/') for p in closure)==33, 'MI28 component count')
require(sum(p.startswith('NLA/MI24/') for p in closure)==18, 'MI24 count')
headers=read(C/'HEADERS.json')
comparator=read(C/'comparator.json')
contracts=read(D/'IMPLEMENTATION-MAP.json')['contracts']
require([r['declaration'] for r in contracts]==list(headers)==freeze['contract_names']==comparator['theorem_names'], 'contract list mismatch')
require(len(contracts)==20, 'contract count')
for c,m in zip(contracts,metadata['status']['main_results']):
    h=headers[c['declaration']]
    require(hashlib.sha256(h['header'].encode()).hexdigest()==h['sha256'], 'invalid header inventory hash')
    require(h['header'] in (C/c['file']).read_text(), 'implementation header differs')
    require(h['header'] in (C/'Challenge.lean').read_text(), 'challenge header differs')
    require(c['source_sha256']==proof[c['file']]==m['source_sha256'], 'contract source hash')
    require(m['declaration']==c['declaration'] and m['file']==c['file'], 'metadata declaration mapping')
    require(m['literature_dependencies']==[], 'unexpected literature premise')
    require(m['axioms']==complete['observed_axioms'][c['declaration']]==comparator['permitted_axioms'], 'axiom report mismatch')
require(len(re.findall(r'\bsorry\b',(C/'Challenge.lean').read_text()))==20,'challenge placeholder count')
require((C/'Solution.lean').read_text().count('#assert_trust kernel NLA.MI28.')==20,'aggregate trust count')
checks.append('Exact 52-module closure, 3 frozen files, 20 headers and metadata declarations')

reuse=read(C/'REUSE-MI24-FURUTA.json')
for row in reuse['files']:
    hashcheck(C/row['path'],row['sha256'])
    hashcheck(row['source_path'],row['sha256'])
require(len(reuse['files'])==18,'reuse inventory')
require({r['path'] for r in reuse['files']}=={p for p in proof if p.startswith('NLA/MI24/')}, 'reuse closure')
checks.append('All 18 unchanged MI24 files against authenticated original snapshot bytes')

old=(C/'lakefile.toml').read_text()
require((D/'lakefile.toml').read_text()==old.replace('defaultTargets = ["Challenge"]','defaultTargets = ["Solution"]'), 'unexpected lakefile change')
old=(C/'lake-manifest.json').read_text()
require((D/'lake-manifest.json').read_text()==old.replace('"name": "NLAMI22"','"name": "NLAMI28"'), 'unexpected manifest change')
require(read(D/'lake-manifest.json')['packages']==read(C/'lake-manifest.json')['packages'], 'dependency package object changed')
require((D/'lean-toolchain').read_bytes()==(C/'lean-toolchain').read_bytes(),'toolchain changed')
config=read(D/'LAKE-CONFIGURATION.json')
for p,h in config['publication_configuration'].items():
    hashcheck(D/p,h)
require(config['standalone_Lake_build_executed'] is False,'false Lake claim')
require(config['Linux_Comparator_executed'] is False,'false Comparator claim')
require(config['canonical_aggregate']==complete['source_filename_mapping'],'aggregate mapping')
require(proof['Solution.lean']==complete['source_filename_mapping']['sha256'],'aggregate byte binding')
checks.append('Only default target and root package name changed; full dependency objects identical')

receipt_cache={}
def receipt(p):
    key=str(p)
    if key not in receipt_cache:
        receipt_cache[key]=read(p)
    return receipt_cache[key]

def command(r,module):
    rows=[c for c in r['commands'] if c.get('module')==module]
    require(len(rows)==1,'ambiguous command '+module)
    return rows[0]

for p,h in complete['retained_original_evidence'].items():
    hashcheck(p,h)
hashcheck(complete['receipt'],complete['receipt_sha256'])
hashcheck(complete['assembly'],complete['assembly_sha256'])
main=receipt(complete['receipt'])
require(main['max_compiler_processes']==1 and main['threads']==1 and main['memory_cap_mib']==4096,'compiler limits')
require(main['end'] and complete['actual_local_closure_modules']==52 and complete['exact_contracts']==20,'incomplete run')
fresh=0
for entry in complete['commands_and_successful_origins']:
    expected=entry['source_sha256']
    require(proof[entry['canonical_source_path']]==expected,'origin source mismatch')
    rp=Path(entry['success_origin_receipt'])
    hashcheck(rp,entry['receipt_sha256'])
    origin=command(receipt(rp),entry['module'])
    require(origin==entry['command'],'saved origin command differs')
    require(origin['exit_code']==0 and origin['end'] and origin['source_sha256']==expected,'unsuccessful origin')
    require('--threads=1' in origin['argv'] and '--memory=4096' in origin['argv'],'command limits')
    hashcheck(rp.parent/(entry['module']+'.log'),origin['log_sha256'])
    chain=entry['reuse_chain']
    require(chain[0]['receipt']==complete['receipt'] and chain[-1]['receipt']==str(rp),'lineage endpoints')
    for i,hop in enumerate(chain):
        hashcheck(hop['receipt'],hop['sha256'])
        row=command(receipt(hop['receipt']),entry['module'])
        require(row['source_sha256']==expected and row['output_sha256']==origin['output_sha256'],'reuse source/output identity')
        if i+1<len(chain):
            require(row['status']=='reused_exact_successful_local_output','non-reuse intermediate hop')
            require(row['prior_receipt']==chain[i+1]['receipt'] and row['prior_receipt_sha256']==chain[i+1]['sha256'],'broken receipt link')
        else:
            require(row==origin,'lineage final command')
    fresh += str(rp)==complete['receipt']
require(fresh==8,'fresh/reused count')
aggregate=next(e for e in complete['commands_and_successful_origins'] if e['canonical_source_path']=='Solution.lean')
log=(Path(aggregate['success_origin_receipt']).parent/(aggregate['module']+'.log')).read_text()
axioms={}
for name, raw in re.findall(r"'(NLA\.MI28\.[^']+)' depends on axioms: \[([^\]]*)\]",log):
    axioms[name]=[a.strip() for a in raw.split(',')]
require(axioms==complete['observed_axioms'],'aggregate actual log axiom mismatch')
checks.append('52 successful command/log origins and complete reuse chains; 92 retained evidence hashes; 8 fresh / 44 reused')

diag=read(B/'MI28-type-diagnostics-366/COMPARISON.json')
hashcheck(diag['receipt'],diag['receipt_sha256'])
hashcheck(L/'ASSEMBLY-366.json',diag['assembly_sha256'])
for fn,key in [('challenge-types.json','challenge_dump_sha256'),('solution-types.json','solution_dump_sha256'),('certificate-body-route.json','body_graph_sha256')]:
    hashcheck(B/'MI28-type-diagnostics-366'/fn,diag[key])
t1=read(B/'MI28-type-diagnostics-366/challenge-types.json')
t2=read(B/'MI28-type-diagnostics-366/solution-types.json')
require(t1==t2 and len(t1)==20, 'separately elaborated normalized types differ')
require({r['name'] for r in t1}==set(headers),'type names mismatch')
require(all(r['same_universes'] and r['same_binder_normalized_type'] for r in diag['results']), 'diagnostic comparison mismatch')
graph={r['name']:r for r in read(B/'MI28-type-diagnostics-366/certificate-body-route.json')}
require(len(graph)==diag['body_graph_nodes']==176,'body node count')
for route in diag['actual_elaborated_body_routes'].values():
    for a,b in zip(route,route[1:]):
        require(graph[a]['hasBody'] and b in graph[a]['bodyConstants'],'body edge missing '+a+' -> '+b)
for cmd in diag['diagnostic_commands']:
    require(cmd==command(receipt(diag['receipt']),cmd['module']), 'diagnostic command differs')
    require(cmd['exit_code']==0 and '--threads=1' in cmd['argv'] and '--memory=4096' in cmd['argv'], 'diagnostic failed')
    hashcheck(Path(diag['receipt']).parent/(cmd['module']+'.log'),cmd['log_sha256'])
    hashcheck(B/'MI28-type-diagnostics-366/sources'/Path(cmd['argv'][-1]),cmd['source_sha256'])
require(diag['Comparator_executed'] is False,'diagnostic mislabeled Comparator')
checks.append('20 actual separate normalized type/universe dumps, 2 diagnostic commands/logs and all 6 body paths')

reviews=read(D/'REVIEW-INDEX.json')
for row in reviews['statement_reviews']+reviews['final_source_reviews']:
    hashcheck(row['origin_manifest'],row['manifest_sha256'])
    manifestcheck(Path(row['origin_manifest']))
require(len(reviews['final_source_reviews'])==2,'wrong review count')
require(all(r['nonauthor_of_statements_and_proof'] and not r['Lean_Lake_Comparator_rerun'] for r in reviews['final_source_reviews']),'review role claim')
for r in reviews['root_integrity_replays']:
    hashcheck(r['origin'],r['sha256'])
    x=read(r['origin'])
    require(x['exit_code']==0 and json.loads(x['stdout'])['verdict']=='PASS','root reviewer replay failure')
    hashcheck(x['argv'][1],x['script_sha256'])
checks.append('Both complete nonauthor review seals, both earlier statement seals and root integrity-replay receipts')

public=read(D/'PUBLIC-SCOPE.json')
refresh=read(public['origin'])
require(all(x['exit_code']==0 for x in refresh['observations']),'public query failure')
upstream=json.loads(refresh['observations'][0]['stdout'])
raw=json.loads(refresh['observations'][1]['stdout'])
body=base64.b64decode(raw['content'])
require(hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==public['canonical_git_blob_sha1'],'canonical blob authentication')
require(body==(D/'source-inputs/canonical/README.md').read_bytes()==(S/'source-inputs/canonical/README.md').read_bytes(),'canonical README bytes differ')
require(upstream['sha']==public['upstream_main']=='9342b3d80c207d3e0bfd61251334d027935c387c','public main binding')
require((D/'source-inputs/canonical/solution.md').read_bytes()==(S/'source-inputs/canonical/solution.md').read_bytes(),'canonical solution differs')
audit=read(public['public_branch_audit']['origin'])
ap=Path(public['public_branch_audit']['origin']).parent
repos=read(ap/'REPOSITORIES.json')
heads=read(ap/'FRESH-BRANCH-HEADS.json')
require(set(repos['repos'])==set(heads) and len(heads)==15,'repository enumeration')
require(sum(map(len,heads.values()))==271,'head count')
commits={x['sha'] for rows in heads.values() for x in rows}
require(len(commits)==225 and commits=={r['commit'] for r in audit['observations']},'immutable commit coverage')
matched=[]
for obs in audit['observations']:
    hashcheck(obs['tree_snapshot'],obs['sha256'])
    tree=json.loads(gzip.decompress(Path(obs['tree_snapshot']).read_bytes()))
    require(obs['complete_tree'] and not tree.get('truncated',False),'incomplete tree')
    recorded=obs['target_named_formalization_paths']
    def target_path(path):
        path=path.lower()
        return ('mi-28' in path or 'mi28' in path) and ('lean' in path or 'formalization' in path)
    rescanned=[{'path':r['path'],'sha':r['sha'],'type':r['type']} for r in tree['tree'] if target_path(r['path'])]
    require(rescanned==recorded,'public ID/path rescan differs')
    for hit in recorded:
        require(any(row['path']==hit['path'] and row['sha']==hit['sha'] and row['type']==hit['type'] for row in tree['tree']),'reported public path missing')
        require(hit['path'].startswith('matrix-functions-and-stability/MF-07/lean/sources/upstream/matrix-inequalities-and-norms/MI-28'),'unexpected public target path')
        if hit['type']=='blob':
            require(hit['path'].endswith('/README.md') and hit['sha']==public['canonical_git_blob_sha1'],'unexpected formalization match')
    if recorded:
        matched.append([obs['repository'],obs['commit'],recorded])
require(matched==audit['matches'] and len(matched)==17,'public classification mismatch')
classification=read(public['public_branch_audit']['classification_origin'])
require(classification['audit_sha256']==sha(ap/'AUDIT.json') and classification['MI28_Lean_source_or_formalization_yaml_found'] is False,'classification binding')
checks.append('Recorded public queries, 15 repositories / 271 heads / 225 complete immutable tree hashes and 17 classified matches; no new network/Git queries')

for p in D.rglob('*'):
    if p.is_file():
        text=p.read_text()
        require(re.search(r'[A-Za-z0-9_.+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}',text) is None,'contact address in '+str(p))
for filename in ['README.md','PROOF-REVIEWER-MAP.md']:
    fenced=False
    for line in (D/filename).read_text().splitlines():
        if line.startswith('```'):
            fenced=not fenced
        elif not fenced:
            prose=re.sub(r'\$`[^`]*`\$', '', line)
            require(chr(92) not in prose,'bare LaTeX outside protected GitHub math in '+filename)
state=read(D/'STATE.json')
require(state['GitHub_Comparator']=='NOT RUN' and state['standalone_Lake_execution']=='NOT RUN','execution status')
require(state['accepted_Lean_verification_count_change']==state['new_mathematical_resolution_count_change']==0,'count status')
print(json.dumps({'verdict':'PASS','scope':'Documentation schema and read-only byte/evidence audit; no compiler, kernel, Comparator, Git or network execution.',
    'manifest_sha256':sha(doc_manifest),'checker_sha256':sha(__file__), 'payload_files':payload_count,
    'payload_bytes_including_manifest':payload_bytes, 'external_inputs':len(scope['external_inputs_sha256']),
    'checks':checks,'proof_source_edits':0,'Lean_Lake_Comparator_executions':0,'accepted_count_change':0},indent=2))
