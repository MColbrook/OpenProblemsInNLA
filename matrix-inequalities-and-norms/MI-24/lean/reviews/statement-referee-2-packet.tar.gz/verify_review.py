#!/usr/bin/env python3
"""Check this follow-up's exact bindings; no subprocess/network/Lean execution."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def require(ok, message):
    if not ok:
        raise SystemExit("FAIL: " + message)


b = load(HERE / "BINDINGS.json")
p, d, old = (Path(b[key]) for key in ["packet_path", "draft_path", "prior_review_path"])
for directory, digest in [(p, b["packet_manifest_sha256"]),
                          (d, b["draft_manifest_sha256"]),
                          (old, b["prior_review_manifest_sha256"])]:
    require(sha(directory / "MANIFEST.json") == digest, "bound manifest changed")
    files = load(directory / "MANIFEST.json")["files"]
    entries = files.items() if isinstance(files, dict) else ((x["path"], x["sha256"]) for x in files)
    for rel, digest in entries:
        require(sha(directory / rel) == digest, "bound payload changed: " + rel)
for rel in ["candidate/NLA/MI24/Definitions.lean", "candidate/Challenge.lean", "candidate/comparator.json"]:
    require((p / rel).read_bytes() == (d / rel).read_bytes(), "reviewed candidate bytes differ")

receipt = load(p / "run/RECEIPT.json")
require(sha(p / "ASSEMBLY-289.json") == receipt["assembly_sha256"], "assembly receipt binding")
require(sha(p / "run/RECEIPT.json") == load(p / "ELABORATION.json")["actual_receipt_sha256"], "receipt binding")
require(receipt["completed_modules"] == 2 and not receipt["failed_modules"] and not receipt["blocked_modules"], "root receipt failures")
require(receipt["max_compiler_processes"] == receipt["threads"] == 1 and receipt["memory_cap_mib"] == 4096, "recorded local limits")
commands = receipt["commands"]
require([c["module"] for c in commands] == ["NLA.MI24.Definitions", "NLA.MI24.Challenge"], "command scope")
for c, rel in zip(commands, ["candidate/NLA/MI24/Definitions.lean", "candidate/Challenge.lean"]):
    require(c["exit_code"] == 0 and c["source_sha256"] == sha(p / rel), "root exit/source binding")
    require(c["log_sha256"] == sha(p / ("run/" + c["module"] + ".log")), "root log binding")
require(commands[1]["dependency_olean_sha256"]["NLA.MI24.Definitions"] == commands[0]["output_sha256"], "compiled dependency binding")
log = (p / "run/NLA.MI24.Challenge.log").read_text()
require(len(log.strip().splitlines()) == log.count("warning: declaration uses `sorry`") == 22, "unexpected Challenge log")
require((p / "run/NLA.MI24.Definitions.log").read_bytes() == b"", "unexpected Definitions log")
source = (p / "candidate/Challenge.lean").read_text()
names = re.findall(r"^theorem\s+(\w+)", source, re.M)
require(len(names) == 22, "header count")
require(load(p / "candidate/comparator.json")["theorem_names"] == ["NLA.MI24." + n for n in names], "configuration coverage")

verdict = load(HERE / "VERDICT.json")
require(verdict["verdict"] == "APPROVE_EXACT_ELABORATED_STATEMENT_BOUNDARY", "verdict scope changed")
require(verdict["own_Lean_executions"] == verdict["own_Comparator_executions"] == 0, "own execution claim")
require(not verdict["proof_approval"] and not verdict["publication_approval"], "scope expanded")
own = load(HERE / "MANIFEST.json")["files"]
require({x["path"] for x in own} == {str(f.relative_to(HERE)) for f in HERE.rglob("*") if f.is_file() and f.name != "MANIFEST.json" and "__pycache__" not in f.parts}, "review inventory changed")
for x in own:
    require(sha(HERE / x["path"]) == x["sha256"], "review payload changed")
print(json.dumps({"result": "PASS", "scope": "Exact source and root elaboration receipt bindings; not an independent compiler run or proof check.", "review_manifest_sha256": sha(HERE / "MANIFEST.json"), "packet_manifest_sha256": b["packet_manifest_sha256"], "headers": 22, "root_recorded_successful_commands": 2, "own_Lean_executions": 0, "own_Comparator_executions": 0, "count_change": 0}, indent=2))
