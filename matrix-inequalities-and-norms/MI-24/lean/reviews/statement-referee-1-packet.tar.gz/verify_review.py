from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((r/'VERDICT.json').read_text());p=Path(v['packet'])
assert h(p/'MANIFEST.json')==v['packet_manifest_sha256']
m=json.loads((p/'MANIFEST.json').read_text())
for rel,dig in m['files'].items():assert h(p/rel)==dig,rel
rec=json.loads((p/'run/RECEIPT.json').read_text());assert 'end' in rec and not rec['failed_modules'] and not rec['blocked_modules']
for mod in ['NLA.MI24.Definitions','NLA.MI24.Challenge']:
 c=next(x for x in rec['commands'] if x['module']==mod);assert c['exit_code']==0
assert (p/'candidate/Challenge.lean').read_text().count('  sorry')==22
print(json.dumps({'result':'PASS','scope':'Exact root statement-review bindings and actual local receipt only; not a rerun of Lean','payloads':len(m['files']),'contracts':22,'proof_count':0}))
