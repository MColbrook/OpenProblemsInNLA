#!/usr/bin/env python3
"""Integrity audit of a source review and existing local receipts. Never runs Lean.

This is not a mathematical proof checker, Comparator, or an independent compiler
rerun. --outputs additionally checks the retained original compiled artifacts.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
EXPECTED_SNAPSHOT = '68d81b42a0cd7fe090b31e53b4079cfdb3ca60f143eb82f09b78bbaa2d1969b5'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def strip_comments(text):
    # Lean block comments nest; strings are left intact for option checks.
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        if depth:
            if text.startswith('/-', i): depth += 1; i += 2
            elif text.startswith('-/', i): depth -= 1; i += 2
            else:
                if text[i] == '\n': out.append('\n')
                i += 1
        elif string:
            out.append(text[i])
            if text[i] == '\\' and i + 1 < len(text):
                i += 1; out.append(text[i])
            elif text[i] == '"': string = False
            i += 1
        elif text.startswith('/-', i): depth = 1; i += 2
        elif text.startswith('--', i):
            j = text.find('\n', i)
            i = len(text) if j < 0 else j
        else:
            if text[i] == '"': string = True
            out.append(text[i]); i += 1
    assert not depth
    return ''.join(out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--outputs', action='store_true')
    args = parser.parse_args()
    checked = 0
    if (HERE / 'MANIFEST.json').exists():
        for item in read(HERE / 'MANIFEST.json')['files']:
            path = HERE / item['path']
            assert path.stat().st_size == item['bytes'], str(path)
            assert sha(path) == item['sha256'], str(path)
            checked += 1
    bindings = read(HERE / 'BINDINGS.json')
    for item in bindings['files']:
        assert sha(item['path']) == item['sha256'], item['path']
        checked += 1
    snapshot = Path(bindings['snapshot'])
    assert sha(snapshot / 'MANIFEST.json') == EXPECTED_SNAPSHOT
    manifest = read(snapshot / 'MANIFEST.json')
    for item in manifest['files']:
        path = snapshot / item['path']
        assert path.stat().st_size == item['bytes']
        assert sha(path) == item['sha256'], item['path']
        checked += 1
    candidate = snapshot / 'candidate'
    record = read(snapshot / 'MI24-LOCAL-COMPLETE-325.json')
    assert sha(record['receipt']) == record['receipt_sha256']
    assert sha(record['assembly']) == record['assembly_sha256']
    receipt = read(record['receipt'])
    assembly = read(record['assembly'])
    assert receipt['end'] and not receipt['failed_modules'] and not receipt['blocked_modules']
    assert receipt['assembly_sha256'] == record['assembly_sha256']
    local = Path('/private/tmp/nla-lean-local-shared-20260916')
    environment = read(local / 'LOCAL-ENVIRONMENT.json')
    assert sha(local / 'serial_compile_v3.py') == receipt['runner_sha256']
    assert sha(environment['compiler']) == receipt['compiler_sha256']
    assert environment['compiler'].endswith('/leanprover--lean4---v4.33.1/bin/lean')
    assert (candidate / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.33.1'
    package_pins = {p['name'].lower(): p['rev'] for p in read(candidate / 'lake-manifest.json')['packages']}
    environment_pins = {p['package'].lower(): p['commit'] for p in environment['dependencies']}
    assert package_pins == environment_pins
    assert package_pins['mathlib'] == '0df444a360eaa60ab8c11dca51a86af692955474'
    assert package_pins['leancert'] == '621a43d7cf21f87872392a01e874f2f1dbddc926'
    api_record = read('/private/tmp/nla-lean-next-20260915/next-statements/MI24-full-20260918/sources/API-SOURCE-HASHES.json')
    for item in api_record['files']:
        assert sha(item['path']) == item['sha256'], item['path']
        checked += 1
    assert record['actual_local_closure_modules'] == 34 and record['exact_contracts'] == 22
    assert record['count_change'] == 0
    freeze = read(snapshot / 'MI24-STATEMENT-FREEZE-local289.json')
    for rel, digest in freeze['frozen_files'].items():
        assert sha(candidate / rel) == digest
        checked += 1
    assert not freeze['proof_implementation_started_before_gate']
    cfg = read(candidate / 'comparator.json')
    names = cfg['theorem_names']
    assert names == freeze['contract_names'] and len(names) == 22
    permitted = {'propext', 'Classical.choice', 'Quot.sound'}
    assert set(cfg['permitted_axioms']) == permitted and not cfg.get('definition_names')
    texts = {rel: (candidate / rel).read_text() for rel in record['sources']}
    assert len(texts) == 34
    for rel, text in texts.items():
        assert sha(candidate / rel) == record['sources'][rel]
        code = strip_comments(text)
        assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide)\b', code), rel
        assert not re.search(r'^\s*(elab|macro|syntax|initialize|#eval)\b', code, re.M), rel
        assert not re.search(r'^\s*import\s+.*Challenge', code, re.M), rel
        assert not re.search(r'set_option\s+(maxHeartbeats|maxRecDepth)', code), rel
        checked += 1
    challenge = (candidate / 'Challenge.lean').read_text()
    assert len(re.findall(r'^\s+sorry\s*$', strip_comments(challenge), re.M)) == 22
    for name in names:
        regex = r'^theorem\s+' + re.escape(name.split('.')[-1]) + r'\b[\s\S]*?(?=\s*:=\s*by)'
        target = re.search(regex, challenge, re.M)
        actual = [m.group().rstrip() for text in texts.values()
                  if (m := re.search(regex, text, re.M))]
        assert target and actual == [target.group().rstrip()], name
        checked += 1
    solution = texts['Solution.lean']
    assert re.findall(r'^#assert_trust kernel (\S+)', solution, re.M) == names
    assert re.findall(r'^#print axioms (\S+)', solution, re.M) == names
    numerical = texts['NLA/MI24/Numerical.lean']
    assert numerical.count('certify_bound (trust := kernel)') == 2
    assert 'set_option leancert.trust "kernel"' in numerical
    assert 'young_weight_interval (youngWeight p)' in numerical
    assert '(youngWeight_complement_bounds p hp).1' in texts['NLA/MI24/TraceYoung.lean']
    assert 'scalar_young_half' in texts['NLA/MI24/TraceYoung.lean']
    assert 'trace_young_half hn P Q' in texts['NLA/MI24/HeronTrace.lean']

    module_rel = {'NLA.MI24.Solution': 'Solution.lean'}
    module_rel.update({rel[:-5].replace('/', '.'): rel for rel in texts if rel != 'Solution.lean'})
    graph, closures, active = {}, {}, set()
    for module, rel in module_rel.items():
        imports = re.findall(r'^import\s+(\S+)', strip_comments(texts[rel]), re.M)
        assert all(i.startswith(('NLA.MI24.', 'Mathlib.', 'LeanCert.')) for i in imports)
        graph[module] = [i for i in imports if i.startswith('NLA.')]
        assert all(i in module_rel for i in graph[module])

    def closure(module):
        if module in closures: return closures[module]
        assert module not in active, ('import cycle', module)
        active.add(module)
        result = {module}
        for dep in graph[module]: result |= closure(dep)
        active.remove(module)
        closures[module] = result
        return result

    assert closure('NLA.MI24.Solution') == set(module_rel)
    origins = {o['module']: o for o in record['commands_and_successful_origins']}
    assert set(origins) == set(module_rel)
    latest = {c['module']: c for c in receipt['commands']}
    for module, origin in origins.items():
        rel = module_rel[module]
        digest = record['sources'][rel]
        local_rel = module.replace('.', '/') + '.lean'
        assert assembly['sources'][local_rel]['sha256'] == digest
        assert receipt['source_inputs'][local_rel] == digest
        assert origin['source_sha256'] == digest
        assert origin['canonical_source_path'] == rel
        previous_command = None
        chain = origin['reuse_chain']
        assert chain[0]['receipt'] == record['receipt']
        assert chain[-1]['receipt'] == origin['success_origin_receipt']
        assert origin['historical_reuse_hops_authenticated'] == len(chain) - 1
        for item in chain:
            path = Path(item['receipt'])
            assert sha(path) == item['sha256']
            node = read(path)
            assert node['end'] and node['platform'] == 'darwin'
            assert node['threads'] == node['max_compiler_processes'] == 1
            assert 0 < node['memory_cap_mib'] <= 4096
            command = next(c for c in node['commands'] if c['module'] == module)
            assert command['source_sha256'] == digest
            assert command['output_sha256'] == latest[module]['output_sha256']
            for dep in closure(module):
                value = node['source_inputs'][dep.replace('.', '/') + '.lean']
                assert value == record['sources'][module_rel[dep]], (module, dep, path)
                checked += 1
            if previous_command is not None:
                assert previous_command['prior_receipt'] == str(path)
                assert previous_command['prior_receipt_sha256'] == item['sha256']
            previous_command = command
        command = previous_command
        assert command == origin['command']
        assert command['exit_code'] == 0
        assert '--threads=1' in command['argv'] and '--memory=4096' in command['argv']
        assert command['argv'][-1] == local_rel
        assert command['cwd'] == '/private/tmp/nla-lean-local-shared-20260916'
        assert set(command['dependency_olean_sha256']) == set(graph[module])
        for dep, digest_olean in command['dependency_olean_sha256'].items():
            assert digest_olean == origins[dep]['command']['output_sha256'], (module, dep)
            checked += 1
        log = Path(origin['success_origin_receipt']).parent / (module + '.log')
        assert sha(log) == command['log_sha256']
        assert not re.search(r'\berror:|\bsorryAx\b|PANIC|uncaught exception', log.read_text())
        checked += 1
    aggregate_log = Path(record['receipt']).parent / 'NLA.MI24.Solution.log'
    observed = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", aggregate_log.read_text(), re.M)
    assert [name for name, _ in observed] == names
    assert all(set(a.strip() for a in axioms.split(',')) <= permitted for _, axioms in observed)
    assert record['observed_axioms'] == {name: [a.strip() for a in ax.split(',')] for name, ax in observed}
    output_count = 0
    if args.outputs:
        for item in bindings['original_outputs']:
            candidates = [Path(p) for p in item['locations']]
            matches = [p for p in candidates if p.is_file() and sha(p) == item['sha256']]
            assert matches, ('original output unavailable', item['module'], candidates)
            output_count += 1; checked += 1
    print(json.dumps({'status': 'PASS', 'checks': checked, 'source_modules': len(texts),
                      'exact_frozen_contracts': len(names), 'actual_original_outputs_rehashed': output_count,
                      'source_review_integrity': True, 'recorded_local_run': 325,
                      'reviewer_ran_Lean': False, 'reviewer_ran_Comparator': False,
                      'mathematical_verdict': read(HERE / 'VERDICT.json')['overall']}, indent=2))


if __name__ == '__main__':
    main()
