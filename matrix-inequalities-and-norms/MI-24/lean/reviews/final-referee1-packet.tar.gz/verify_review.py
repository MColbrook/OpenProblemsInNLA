#!/usr/bin/env python3
"""Read-only integrity replay of the MI-24 local332 review continuation.

Authenticates the immutable full325 review, exact successor delta, retained root
local332 evidence DAG, and actual root local333 type/body diagnostics. No Lean,
Lake, Comparator, Git, shell, network, or compiler subprocess is invoked. This
does not replace the source assessment or the pending real Linux Comparator.
The checker execution receipt is outside this directory's sealed manifest.
"""
from __future__ import annotations

from collections import deque
from contextlib import redirect_stdout
from pathlib import Path
import difflib
import hashlib
import io
import json
import re
import runpy

HERE = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
BASE = B / 'reviews/MI24-final-referee1-local325'
BASE_MANIFEST = 'aef78d73b98b6762ec52585f8b00bf5d3d3adfe2f0023e7f3e3945d738182bef'
BASE_CHECK = 'b6af46024d526d86c5c777570f4a69f6b19ea2bb7f9431a2859820bcc66622b0'
SNAPSHOT_MANIFEST = 'eb766a3dee52c2a694b0bb9d006619295fee4271ee7aa925dc9895e4998562f3'
COMPLETE_SHA = 'a1f478c2918460ddcde421bedf6139f6a4693b59ccca6d5f1148530b67ff4e24'
CLEANUP_MANIFEST = '8bed3d681489d29ba1f76828f798cc09cbd9471e63ab21a3fa37883831ca0b3a'
COMPARISON_SHA = 'e3c76907ad179ae3dba0258b9a20baf6fb74f2dcea2347667bdf4087f0da10f3'
PERMITTED = {'propext', 'Classical.choice', 'Quot.sound'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def auth(path, expected, size=None):
    path = Path(path)
    assert path.is_file() and sha(path) == expected, f'hash mismatch: {path}'
    if size is not None:
        assert path.stat().st_size == size, f'size mismatch: {path}'


def manifest(path):
    path = Path(path)
    entries = read(path)['files']
    if isinstance(entries, dict):
        entries = [dict(path=k, **(v if isinstance(v, dict) else {'sha256': v}))
                   for k, v in entries.items()]
    seen = set()
    for e in entries:
        rel = e['path']
        assert rel not in seen and not Path(rel).is_absolute() and '..' not in Path(rel).parts
        seen.add(rel)
        auth(path.parent / rel, e['sha256'], e.get('bytes'))
    return seen


# Replay the pinned, previously reviewed read-only checker without a subprocess.
# Its full source/evidence scope and original request-changes verdict stay intact.
auth(BASE / 'MANIFEST.json', BASE_MANIFEST)
manifest(BASE / 'MANIFEST.json')
auth(BASE.with_name(BASE.name + '-CHECK.json'), BASE_CHECK)
base_capture = io.StringIO()
with redirect_stdout(base_capture):
    base = runpy.run_path(str(BASE / 'verify_review.py'))
base_summary = json.loads(base_capture.getvalue())
assert base_summary['status'] == 'PASS_READ_ONLY_INTEGRITY'
assert base_summary['review_verdict'] == 'request_changes'
strip_comments = base['strip_comments']
local_imports = base['local_imports']
canonical_code = lambda t: ''.join(strip_comments(t).split())

bindings = read(HERE / 'BINDINGS.json')
verdict = read(HERE / 'VERDICT.json')
assert manifest(HERE / 'MANIFEST.json') == {'REVIEW.md', 'VERDICT.json', 'BINDINGS.json', 'verify_review.py'}
assert bindings['baseline_manifest_sha256'] == BASE_MANIFEST
assert verdict['overall'] == 'approve_source_scope_continuation'
assert verdict['reviewer'] == '/root/mi24_full_referee1'
assert verdict['snapshot_manifest_sha256'] == bindings['snapshot_manifest_sha256'] == SNAPSHOT_MANIFEST
assert verdict['own_Lean_executions'] == verdict['own_Lake_executions'] == verdict['own_Comparator_executions'] == 0
assert verdict['count_changes'] == {'mathematical_resolutions': 0, 'complete_Lean_verifications': 0}
assert verdict['publication_approval'] is False
assert set(verdict['resolved_findings']) == {'R1', 'R2', 'Q1', 'E1'}

S = Path(bindings['snapshot'])
auth(S / 'MANIFEST.json', SNAPSHOT_MANIFEST)
snapshot_files = manifest(S / 'MANIFEST.json')
assert len(snapshot_files) == 46
assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()} == snapshot_files | {'MANIFEST.json'}
auth(S / 'MI24-LOCAL-COMPLETE-332.json', COMPLETE_SHA)
complete = read(S / 'MI24-LOCAL-COMPLETE-332.json')
P = S / 'candidate'
sources = complete['sources']
assert sources == bindings['source_hashes']
assert len(sources) == complete['actual_local_closure_modules'] == 34
assert set(sources) == set(base['source_hashes'])
texts = {}
modules = {}
for rel, h in sources.items():
    auth(P / rel, h)
    texts[rel] = (P / rel).read_text()
    modules['NLA.MI24.Solution' if rel == 'Solution.lean' else rel[:-5].replace('/', '.')] = rel
assert {str(p.relative_to(P)) for p in P.rglob('*.lean')} == set(sources) | {'Challenge.lean'}
freeze = read(S / 'MI24-STATEMENT-FREEZE-local289.json')
assert freeze == base['freeze']
for rel, h in freeze['frozen_files'].items():
    auth(P / rel, h)
config = read(P / 'comparator.json')
assert config == base['config']
names = config['theorem_names']
assert len(names) == complete['exact_contracts'] == 22
assert bindings['frozen_files'] == freeze['frozen_files']
assert bindings['frozen_contracts'] == names

# This continuation covers every baseline source byte: ten unchanged files,
# twenty-two comment-only changes, and two explicitly constrained code changes.
C = B / 'MI24-source-history/referee-cleanup-local330'
auth(C / 'MANIFEST.json', CLEANUP_MANIFEST)
manifest(C / 'MANIFEST.json')
auth(C / 'CHANGES.json', '677e05f15f120d90d038fc3480175016d6c5cd0ec260ceb504d1bf87544e4f7d')
changes = read(C / 'CHANGES.json')
bp = read(C / 'BASE-PACKET.json')
CB = (C / bp['relative_directory']).resolve()
auth(CB / 'MANIFEST.json', bp['manifest_sha256'])
manifest(CB / 'MANIFEST.json')
changed = {rel for rel in sources if sources[rel] != base['source_hashes'][rel]}
assert len(changed) == 24 and changed == set(changes['changed_files'])
delta = ''
code_changes = []
for rel in sorted(changed):
    record = changes['changed_files'][rel]
    assert record['before_sha256'] == base['source_hashes'][rel]
    assert record['after_sha256'] == sources[rel]
    auth(CB / 'before' / Path(rel).name, record['before_sha256'], record['before_bytes'])
    auth(P / rel, record['after_sha256'], record['after_bytes'])
    old, new = base['texts'][rel], texts[rel]
    delta += ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                        fromfile='before/' + rel, tofile='after/' + rel))
    if canonical_code(old) != canonical_code(new):
        code_changes.append(rel)
assert delta == (C / 'cleanup.diff').read_text()
assert code_changes == ['NLA/MI24/CompoundSpectral.lean', 'NLA/MI24/DiagonalPowers.lean']
diagonal = 'NLA/MI24/DiagonalPowers.lean'
old_body = '''apply continuous_pi
  intro i
  apply continuous_pi
  intro j
  by_cases hij : i = j
  · subst j
    simp only [Matrix.diagonal_apply_eq]
    fun_prop
  · simp only [Matrix.diagonal_apply_ne _ hij]
    fun_prop'''
new_body = 'exact (continuous_id : Continuous (fun v : Fin n → ℂ => v)).matrix_diagonal'
old_norm = canonical_code(base['texts'][diagonal])
assert old_norm.count(canonical_code(old_body)) == 1
assert old_norm.replace(canonical_code(old_body), canonical_code(new_body)) == canonical_code(texts[diagonal])
compound = 'NLA/MI24/CompoundSpectral.lean'
alias = '''lemma compoundMatrix_conjTranspose {n : ℕ} (k : ℕ) (A : Mat n) :
    compoundMatrix k Aᴴ = (compoundMatrix k A)ᴴ := compoundMatrix_star k A'''
old_norm = canonical_code(base['texts'][compound])
assert old_norm.count(canonical_code(alias)) == 1
old_norm = old_norm.replace(canonical_code(alias), '')
assert old_norm.count('compoundMatrix_conjTranspose') == 1
assert old_norm.replace('compoundMatrix_conjTranspose', canonical_code('← Matrix.star_eq_conjTranspose, compoundMatrix_star')) == canonical_code(texts[compound])
assert all('compoundMatrix_conjTranspose' not in strip_comments(t) for t in texts.values())

comment_sites = read(CB / 'COMMENTS.json')['sites']
base_sites = [x for group in base['bindings']['proof_quality_sites'].values() for x in group]
expected_sites = {(Path(x['path']).stem, str(x['line'])): x for x in base_sites}
assert set(expected_sites) == {(stem, line) for stem, ss in comment_sites.items() for line in ss}
assert len(expected_sites) == changes['comment_sites'] == 61
resolved_sites = []
for (stem, line), oldsite in expected_sites.items():
    rel = oldsite['path']
    assert base['texts'][rel].splitlines()[int(line) - 1] == oldsite['source_line']
    comments = comment_sites[stem][line]
    lines = texts[rel].splitlines()
    hits = [i for i in range(len(lines))
            if [v.strip() for v in lines[i:i + len(comments)]] == ['-- ' + v for v in comments]]
    assert len(hits) == 1, (stem, line)
    i = hits[0] + len(comments)
    assert lines[i] == oldsite['source_line'], (stem, line)
    resolved_sites.append({'path': rel, 'old_line': int(line), 'new_line': i + 1,
                           'comment_start_line': hits[0] + 1, 'comment_lines': comments})
assert sorted(resolved_sites, key=lambda x: (x['path'], x['old_line'])) == bindings['resolved_comment_sites']
assert len(bindings['source_coverage']) == 34
for row in bindings['source_coverage']:
    rel = row['path']
    assert row['baseline_sha256'] == base['source_hashes'][rel]
    assert row['successor_sha256'] == sources[rel]
    assert row['baseline_read_in_full'] is True
    assert row['baseline_lines'] == [1, len(base['texts'][rel].splitlines())]
    assert row['successor_lines'] == [1, len(texts[rel].splitlines())]
    assert row['successor_read_mode'] == ('reread_in_full' if rel in code_changes else
        'full_delta_and_context_read' if rel in changed else 'byte_identical_full_read_carried_forward')

imports = {m: local_imports(texts[r]) for m, r in modules.items()}
assert imports == base['imports']
closures = {}
visiting = set()


def closure(module):
    if module not in closures:
        assert module not in visiting and module in modules
        visiting.add(module)
        deps = {module}
        for d in imports[module]:
            deps |= closure(d)
        visiting.remove(module)
        closures[module] = deps
    return closures[module]


assert closure('NLA.MI24.Solution') == set(modules)
for rel, t in texts.items():
    code = strip_comments(t)
    assert not re.search(r'\b(sorry|admit|sorryAx|native_decide|unsafe|axiom|implemented_by)\b', code), rel
    assert not re.search(r'(?m)^\s*(#eval|#reduce|run_elab|initialize|elab|macro|syntax|opaque|variable)\b', code), rel
    assert 'import Challenge' not in code and 'import NLA.MI24.Challenge' not in code
challenge = (P / 'Challenge.lean').read_text()
for name in names:
    pattern = r'^theorem\s+' + re.escape(name.split('.')[-1]) + r'\b[\s\S]*?(?=\s*:=\s*by)'
    assert [m.rstrip() for t in texts.values() for m in re.findall(pattern, t, re.M)] == re.findall(pattern, challenge, re.M)
solution = texts['Solution.lean']
assert re.findall(r'^#print axioms (\S+)$', solution, re.M) == names
assert re.findall(r'^#assert_trust kernel (\S+)$', solution, re.M) == names
assert 'set_option leancert.trust "kernel"' in solution
assert texts['NLA/MI24/Numerical.lean'] == base['texts']['NLA/MI24/Numerical.lean']

# Root local332 compilation/reuse DAG. Check every source closure at every hop,
# actual successful log, and direct dependency output-hash edge, independently
# of the complete-record booleans. Mutable current oleans are not prerequisites.
retained = complete['retained_original_evidence']
assert retained == bindings['local_evidence_hashes']
for path, h in retained.items():
    auth(path, h)
auth(complete['receipt'], complete['receipt_sha256'])
auth(complete['assembly'], complete['assembly_sha256'])
entry = read(complete['receipt'])
L = Path(complete['receipt']).parents[2]
env = read(L / 'LOCAL-ENVIRONMENT.json')
auth(L / 'serial_compile_v3.py', entry['runner_sha256'])
auth(env['compiler'], entry['compiler_sha256'])
auth(S / 'capture_full_local_completion_v2.py', complete['audit_script_sha256'])
assert entry.get('end') and not entry['failed_modules'] and not entry['blocked_modules']
assert entry['completed_modules'] == len(entry['commands']) == len(entry['module_order']) == 72
assert set(modules) <= set(entry['module_order'])
outside_scope = set(entry['module_order']) - set(modules)
assert len(outside_scope) == 38 and all(m.startswith('NLA.MF18.') for m in outside_scope)
assert entry['assembly_sha256'] == complete['assembly_sha256']
assert entry['runner_sha256'] == base['entry']['runner_sha256']
assert entry['compiler_sha256'] == base['entry']['compiler_sha256']
assert (P / 'lake-manifest.json').read_bytes() == (base['candidate'] / 'lake-manifest.json').read_bytes()
assert (P / 'lean-toolchain').read_bytes() == (base['candidate'] / 'lean-toolchain').read_bytes()
origins = {o['module']: o for o in complete['commands_and_successful_origins']}
assert set(origins) == set(modules) and len(origins) == 34
receipts, logs, assemblies = set(), set(), set()
hops = 0
for module, origin in origins.items():
    rel = modules[module]
    local_rel = module.replace('.', '/') + '.lean'
    assert origin['canonical_source_path'] == rel and origin['source_sha256'] == sources[rel]
    chain = origin['reuse_chain']
    assert chain and chain[0] == {'receipt': complete['receipt'], 'sha256': complete['receipt_sha256']}
    assert len({p['receipt'] for p in chain}) == len(chain)
    assert origin['historical_reuse_hops_authenticated'] == len(chain) - 1
    hops += len(chain) - 1
    for i, hop in enumerate(chain):
        path = Path(hop['receipt'])
        auth(path, hop['sha256'])
        assert retained[str(path)] == hop['sha256']
        node = read(path)
        assert node.get('end') and node['platform'] == 'darwin'
        assert node['threads'] == node['max_compiler_processes'] == 1
        assert node['memory_cap_mib'] == 4096
        assert node['runner_sha256'] == entry['runner_sha256']
        assert node['compiler_sha256'] == entry['compiler_sha256']
        assembly = L / ('ASSEMBLY-' + path.parent.name.removeprefix('development-') + '.json')
        auth(assembly, node['assembly_sha256'])
        assert {p: e['sha256'] for p, e in read(assembly)['sources'].items()} == node['source_inputs']
        assemblies.add(str(assembly))
        receipts.add(str(path))
        commands = [c for c in node['commands'] if c['module'] == module]
        assert len(commands) == 1
        command = commands[0]
        assert command['source_sha256'] == sources[rel]
        assert command['output_sha256'] == origin['command']['output_sha256']
        for dep in closure(module):
            assert node['source_inputs'][dep.replace('.', '/') + '.lean'] == sources[modules[dep]]
        if i + 1 < len(chain):
            assert command['status'] == 'reused_exact_successful_local_output'
            assert command['prior_receipt'] == chain[i + 1]['receipt']
            assert command['prior_receipt_sha256'] == chain[i + 1]['sha256']
            if 'transitive_source_hashes' in command:
                assert command['transitive_source_hashes'] == {d.replace('.', '/') + '.lean': sources[modules[d]] for d in closure(module)}
        else:
            assert str(path) == origin['success_origin_receipt']
            assert sha(path) == origin['receipt_sha256']
            assert command == origin['command'] and command['exit_code'] == 0
            assert command['cwd'] == str(L)
            assert command['argv'] == [env['compiler'], '--threads=1', '--memory=4096', '-o',
                str(L / '.lake/build/lib/lean' / (local_rel[:-5] + '.olean')), local_rel]
            assert command['end'] >= command['start'] and command['elapsed_seconds'] >= 0
            assert set(command['dependency_olean_sha256']) == set(imports[module])
            for dep, h in command['dependency_olean_sha256'].items():
                assert h == origins[dep]['command']['output_sha256'], (module, dep)
            log = path.parent / (module + '.log')
            auth(log, command['log_sha256'])
            assert retained[str(log)] == command['log_sha256']
            assert 'error:' not in log.read_text() and 'sorryAx' not in log.read_text()
            logs.add(str(log))
assert receipts | logs == set(retained)
entry_mi24 = [c for c in entry['commands'] if c['module'] in modules]
fresh = sum(c.get('exit_code') == 0 for c in entry_mi24)
assert len(entry_mi24) == 34 and fresh == 8 and len(entry_mi24) - fresh == 26
assert origins['NLA.MI24.Solution']['success_origin_receipt'] == complete['receipt']
solution_log = Path(complete['receipt']).parent / 'NLA.MI24.Solution.log'
axioms = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", solution_log.read_text(), re.M)
assert [n for n, _ in axioms] == names
observed = {n: [a.strip() for a in ax.split(',')] for n, ax in axioms}
assert observed == complete['observed_axioms']
assert all(set(ax) <= PERMITTED for ax in observed.values())
assert complete['source_filename_mapping'] == {'local': 'NLA/MI24/Solution.lean',
    'canonical': 'Solution.lean', 'sha256': sources['Solution.lean']}

# The failed330 archive is history, not a pass. Only successful per-module330
# origins above are reused; repaired CompoundSpectral and final Solution are332.
failed = read(C / 'failed/RECEIPT.json')
assert 'NLA.MI24.CompoundSpectral' in failed['failed_modules']
assert 'error:' in (C / 'failed/NLA.MI24.CompoundSpectral.log').read_text()
assert Path(origins['NLA.MI24.CompoundSpectral']['success_origin_receipt']).parent.name == 'development-332'

# Actual root local333 diagnostics: bind diagnostic sources and dependency
# oleans to the successful332 closure, then recompute all comparisons/routes.
D = B / 'MI24-type-diagnostics-333'
auth(D / 'COMPARISON.json', COMPARISON_SHA)
comparison = read(D / 'COMPARISON.json')
assert comparison['source_complete_record_sha256'] == COMPLETE_SHA
auth(comparison['source_complete_record'], COMPLETE_SHA)
auth(comparison['receipt'], comparison['receipt_sha256'])
dr = read(comparison['receipt'])
auth(L / 'ASSEMBLY-333.json', comparison['assembly_sha256'])
assert dr['assembly_sha256'] == comparison['assembly_sha256']
da = read(L / 'ASSEMBLY-333.json')
assert {p: e['sha256'] for p, e in da['sources'].items()} == dr['source_inputs']
assert dr.get('end') and not dr['failed_modules'] and not dr['blocked_modules']
assert dr['platform'] == 'darwin' and dr['threads'] == dr['max_compiler_processes'] == 1
assert dr['memory_cap_mib'] == 4096
assert dr['compiler_sha256'] == entry['compiler_sha256'] and dr['runner_sha256'] == entry['runner_sha256']
dc = {c['module']: c for c in dr['commands']}
for module, rel in modules.items():
    assert dr['source_inputs'][module.replace('.', '/') + '.lean'] == sources[rel]
    c = dc[module]
    assert c['status'] == 'reused_exact_successful_local_output'
    assert c['prior_receipt'] == complete['receipt'] and c['prior_receipt_sha256'] == complete['receipt_sha256']
    assert c['output_sha256'] == origins[module]['command']['output_sha256']
    assert c['transitive_source_hashes'] == {d.replace('.', '/') + '.lean': sources[modules[d]] for d in closure(module)}
diagnostic_modules = {'NLA.MI24Diagnostics.ChallengeTypes333', 'NLA.MI24Diagnostics.SolutionTypes333'}
assert set(dc) == set(modules) | diagnostic_modules
assert dr['completed_modules'] == 36
assert {c['module'] for c in comparison['diagnostic_commands']} == diagnostic_modules
for c in comparison['diagnostic_commands']:
    module = c['module']
    rel = module.replace('.', '/') + '.lean'
    assert c == dc[module] and c['exit_code'] == 0
    auth(D / 'sources' / rel, c['source_sha256'])
    assert dr['source_inputs'][rel] == c['source_sha256']
    assert c['argv'] == [env['compiler'], '--threads=1', '--memory=4096', '-o',
        str(L / '.lake/build/lib/lean' / (rel[:-5] + '.olean')), rel]
    assert c['cwd'] == str(L)
    log = Path(comparison['receipt']).parent / (module + '.log')
    auth(log, c['log_sha256'])
    assert 'error:' not in log.read_text()
    dep = 'NLA.MI24.Definitions' if 'ChallengeTypes' in module else 'NLA.MI24.Solution'
    assert c['dependency_olean_sha256'] == {dep: origins[dep]['command']['output_sha256']}
challenge_diag = (D / 'sources/NLA/MI24Diagnostics/ChallengeTypes333.lean').read_text()
assert challenge_diag.startswith(challenge.replace('import NLA.MI24.Definitions\n', 'import NLA.MI24.Definitions\nimport Lean\n') + '\n')
assert challenge_diag.count('sorry') == challenge.count('sorry')
solution_diag = (D / 'sources/NLA/MI24Diagnostics/SolutionTypes333.lean').read_text()
assert solution_diag.startswith('import NLA.MI24.Solution\nimport Lean\n')
normalizer_start = 'private def diagnosticEraseBinderNames'
normalizer_end = 'open Lean in\nrun_cmd do'
normalizer = lambda t: t.split(normalizer_start, 1)[1].split(normalizer_end, 1)[0]
assert normalizer(challenge_diag) == normalizer(solution_diag)
assert 'let ci ← getConstInfo name' in solution_diag
assert 'ci.value? (allowOpaque := true)' in solution_diag and 'body.getUsedConstants' in solution_diag
auth(D / 'challenge-types.json', comparison['challenge_dump_sha256'])
auth(D / 'solution-types.json', comparison['solution_dump_sha256'])
auth(D / 'certificate-body-route.json', comparison['body_graph_sha256'])
challenge_types, solution_types = read(D / 'challenge-types.json'), read(D / 'solution-types.json')
assert [r['name'] for r in challenge_types] == [r['name'] for r in solution_types] == names
assert challenge_types == solution_types  # Here even raw types/binder names match.
results = [{'name': c['name'], 'same_universes': c['levelParams'] == s['levelParams'],
            'same_binder_normalized_type': c['binderNormalizedType'] == s['binderNormalizedType']}
           for c, s in zip(challenge_types, solution_types)]
assert results == comparison['results'] and all(r['same_universes'] and r['same_binder_normalized_type'] for r in results)
rows = read(D / 'certificate-body-route.json')
graph = {r['name']: r for r in rows}
assert len(rows) == len(graph) == comparison['body_graph_nodes'] == 237
assert all(graph[n]['hasBody'] for n in names)


def route(target):
    todo = deque([['NLA.MI24.schattenComplementConjecture']])
    seen = set()
    while todo:
        path = todo.popleft()
        last = path[-1]
        if last == target:
            return path
        if last in seen:
            continue
        seen.add(last)
        if last in graph:
            assert graph[last]['hasBody']
            todo.extend(path + [n] for n in graph[last]['bodyConstants'] if n not in seen)
    raise AssertionError(('missing proof-body route', target))


routes = {'final_to_frozen_certificate': route('NLA.MI24.young_weight_interval')}
for direction in ('lower', 'upper'):
    key = f'final_to_{direction}_kernel_checked_bound'
    routes[key] = route(f'LeanCert.Validity.verify_{direction}_bound_dyadic_checked')
    assert f'_private.NLA.MI24.Numerical.0.NLA.MI24.young_complement_{direction}_box' in routes[key]
assert routes == comparison['actual_elaborated_body_routes']
assert comparison['all22_match'] is True and comparison['Comparator_executed'] is False
auth(B / 'compare_mi24_diagnostics.py', comparison['comparison_script_sha256'])
for e in bindings['additional_evidence']:
    auth(e['path'], e['sha256'], e['bytes'])
assert bindings['diagnostic_comparison_sha256'] == COMPARISON_SHA

print(json.dumps({
    'status': 'PASS_READ_ONLY_INTEGRITY',
    'review_verdict': verdict['overall'],
    'baseline_manifest_sha256': BASE_MANIFEST,
    'baseline_integrity_replayed': base_summary,
    'successor_snapshot_manifest_sha256': SNAPSHOT_MANIFEST,
    'successor_snapshot_files_authenticated': len(snapshot_files),
    'successor_source_closure_modules_authenticated': len(modules),
    'unchanged_source_files': 34 - len(changed),
    'edited_source_files': len(changed),
    'comment_only_edited_source_files': len(changed) - len(code_changes),
    'substantive_cleanup_files': code_changes,
    'resolved_comment_sites_authenticated': len(resolved_sites),
    'frozen_contract_headers_identical': len(names),
    'root_local332_fresh_modules': fresh,
    'root_local332_authenticated_reused_modules': 34 - fresh,
    'root_local332_total_selected_modules': len(entry['module_order']),
    'root_local332_selected_modules_outside_review_scope': len(outside_scope),
    'local_receipts_authenticated': len(receipts),
    'successful_origin_logs_authenticated': len(logs),
    'local_assemblies_authenticated': len(assemblies),
    'source_matched_reuse_hops_authenticated': hops,
    'final_logged_axiom_reports': len(axioms),
    'final_source_kernel_assertions': len(names),
    'actual_root_diagnostic_run': 333,
    'diagnostic_commands_authenticated': len(diagnostic_modules),
    'elaborated_type_pairs_equal': len(results),
    'actual_body_graph_nodes': len(rows),
    'actual_body_routes_to_certificate_and_two_checked_bounds': len(routes),
    'display_path_mapping_corrected': True,
    'reviewer_Lean_runs': 0, 'reviewer_Lake_runs': 0, 'reviewer_Comparator_runs': 0,
    'scope': 'Source-scope continuation and retained root local evidence only; no Linux Comparator, publication, metadata or count approval.'
}, indent=2))
