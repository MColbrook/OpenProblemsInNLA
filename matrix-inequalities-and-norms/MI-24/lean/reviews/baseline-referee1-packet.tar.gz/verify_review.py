#!/usr/bin/env python3
"""Read-only integrity replay for the MI-24 local325 independent source review.

This script hashes retained files, authenticates the local compiler receipt DAG,
and compares frozen source signatures. It does not invoke Lean, Lake, Comparator,
Git, a shell, a compiler subprocess, or any network operation. It proves neither
Lean kernel soundness nor semantic faithfulness; the accompanying review records
the separate human-readable source assessment. Its own run receipt lives outside
this directory's sealed manifest, avoiding a self-hash cycle.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
SNAPSHOT_MANIFEST_SHA256 = "68d81b42a0cd7fe090b31e53b4079cfdb3ca60f143eb82f09b78bbaa2d1969b5"
COMPLETE_SHA256 = "499beaeef51d1abc09537258d14442085443ffe50f4f649205d6eb9846981ada"
PERMITTED = {"propext", "Classical.choice", "Quot.sound"}


def sha(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path: Path | str):
    return json.loads(Path(path).read_text())


def authenticate(path: Path | str, expected: str, size: int | None = None):
    path = Path(path)
    assert path.is_file(), f"missing file: {path}"
    assert sha(path) == expected, f"hash mismatch: {path}"
    if size is not None:
        assert path.stat().st_size == size, f"size mismatch: {path}"


def manifest_files(path: Path):
    m = read(path)
    entries = m["files"]
    if isinstance(entries, dict):
        entries = [{"path": name, "sha256": h} for name, h in entries.items()]
    seen = set()
    for item in entries:
        name = item["path"]
        assert name not in seen and not Path(name).is_absolute() and ".." not in Path(name).parts
        seen.add(name)
        authenticate(path.parent / name, item["sha256"], item.get("bytes"))
    return seen


def strip_comments(text: str) -> str:
    # Lean permits nested block comments. Preserve line numbers and code strings.
    out = []
    i = depth = 0
    line_comment = quoted = False
    while i < len(text):
        pair = text[i:i + 2]
        ch = text[i]
        if line_comment:
            out.append("\n" if ch == "\n" else " ")
            if ch == "\n":
                line_comment = False
            i += 1
        elif depth:
            if pair == "/-":
                depth += 1
                out.append("  ")
                i += 2
            elif pair == "-/":
                depth -= 1
                out.append("  ")
                i += 2
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
        elif quoted:
            out.append(ch)
            i += 1
            if ch == "\\" and i < len(text):
                out.append(text[i])
                i += 1
            elif ch == '"':
                quoted = False
        elif pair == "/-":
            depth = 1
            out.append("  ")
            i += 2
        elif pair == "--":
            line_comment = True
            out.append("  ")
            i += 2
        else:
            quoted = ch == '"'
            out.append(ch)
            i += 1
    assert depth == 0 and not quoted, "unbalanced comments or strings"
    return "".join(out)


def local_imports(text: str):
    code = strip_comments(text)
    return [name for row in re.findall(r"^import\s+([^\n]+)", code, re.M)
            for name in row.split() if name.startswith("NLA.")]


bindings = read(HERE / "BINDINGS.json")
verdict = read(HERE / "VERDICT.json")
review_files = manifest_files(HERE / "MANIFEST.json")
assert review_files == {"REVIEW.md", "VERDICT.json", "BINDINGS.json", "verify_review.py"}
assert verdict["snapshot_manifest_sha256"] == SNAPSHOT_MANIFEST_SHA256
assert verdict["reviewer"] == "/root/mi24_full_referee1"
assert verdict["own_Lean_executions"] == verdict["own_Lake_executions"] == verdict["own_Comparator_executions"] == 0
assert verdict["count_changes"] == {"mathematical_resolutions": 0, "complete_Lean_verifications": 0}
assert verdict["overall"] == "request_changes"

snapshot = Path(bindings["snapshot"])
authenticate(snapshot / "MANIFEST.json", SNAPSHOT_MANIFEST_SHA256)
snapshot_files = manifest_files(snapshot / "MANIFEST.json")
assert len(snapshot_files) == 46
assert {str(p.relative_to(snapshot)) for p in snapshot.rglob("*") if p.is_file()} == snapshot_files | {"MANIFEST.json"}
authenticate(snapshot / "MI24-LOCAL-COMPLETE-325.json", COMPLETE_SHA256)
complete = read(snapshot / "MI24-LOCAL-COMPLETE-325.json")
freeze = read(snapshot / "MI24-STATEMENT-FREEZE-local289.json")
candidate = snapshot / "candidate"
config = read(candidate / "comparator.json")
names = config["theorem_names"]
assert len(names) == len(set(names)) == 22
assert names == freeze["contract_names"] == bindings["frozen_contracts"]
assert set(config["permitted_axioms"]) == PERMITTED
assert config["definition_names"] == []
assert config["challenge_module"] == "Challenge" and config["solution_module"] == "Solution"
for path, h in freeze["frozen_files"].items():
    authenticate(candidate / path, h)
assert bindings["frozen_files"] == freeze["frozen_files"]

source_hashes = complete["sources"]
assert source_hashes == bindings["source_hashes"]
assert len(source_hashes) == complete["actual_local_closure_modules"] == 34
assert complete["exact_contracts"] == 22
texts = {}
modules = {}
for rel, h in source_hashes.items():
    authenticate(candidate / rel, h)
    texts[rel] = (candidate / rel).read_text()
    name = "NLA.MI24.Solution" if rel == "Solution.lean" else rel[:-5].replace("/", ".")
    modules[name] = rel
assert {str(p.relative_to(candidate)) for p in candidate.rglob("*.lean")} == set(source_hashes) | {"Challenge.lean"}
imports = {name: local_imports(texts[rel]) for name, rel in modules.items()}
assert all(dep in modules for deps in imports.values() for dep in deps)
closures = {}
visiting = set()


def closure(name):
    if name not in closures:
        assert name not in visiting, f"import cycle: {name}"
        visiting.add(name)
        ans = {name}
        for dep in imports[name]:
            ans |= closure(dep)
        visiting.remove(name)
        closures[name] = ans
    return closures[name]


assert closure("NLA.MI24.Solution") == set(modules)
for rel, text in texts.items():
    code = strip_comments(text)
    # Static supplemental hygiene only; the logged axiom report is checked below.
    assert not re.search(r"\b(sorry|admit|sorryAx|native_decide|unsafe|axiom|implemented_by)\b", code), rel
    assert not re.search(r"(?m)^\s*(#eval|#reduce|run_elab|initialize|elab|macro|syntax|opaque|variable)\b", code), rel
    assert "import Challenge" not in code and "import NLA.MI24.Challenge" not in code, rel

challenge = (candidate / "Challenge.lean").read_text()
assert len(re.findall(r"\bsorry\b", strip_comments(challenge))) == 22
for name in names:
    pattern = r"^theorem\s+" + re.escape(name.split(".")[-1]) + r"\b[\s\S]*?(?=\s*:=\s*by)"
    expected = re.findall(pattern, challenge, re.M)
    found = [m.rstrip() for text in texts.values() for m in re.findall(pattern, text, re.M)]
    assert len(expected) == 1 and found == [expected[0].rstrip()], f"frozen header mismatch: {name}"
solution = texts["Solution.lean"]
assert re.findall(r"^#print axioms (\S+)$", solution, re.M) == names
assert re.findall(r"^#assert_trust kernel (\S+)$", solution, re.M) == names
assert 'set_option leancert.trust "kernel"' in solution
numerical = texts["NLA/MI24/Numerical.lean"]
assert numerical.count("certify_bound (trust := kernel)") == 2
assert 'set_option leancert.trust "kernel"' in numerical
assert "youngWeight_complement_bounds p hp" in texts["NLA/MI24/TraceYoung.lean"]
assert "trace_young_half hn P Q hP hQ p hp" in texts["NLA/MI24/HeronTrace.lean"]

coverage = bindings["full_source_read_coverage"]
assert {x["path"] for x in coverage} == set(source_hashes) | {"Challenge.lean"}
for item in coverage:
    file = candidate / item["path"]
    authenticate(file, item["sha256"])
    assert item["read_lines"] == [1, len(file.read_text().splitlines())]
    assert item["read_in_full"] is True

retained = complete["retained_original_evidence"]
assert retained == bindings["local_evidence_hashes"]
for path, h in retained.items():
    authenticate(path, h)
local_root = Path(complete["receipt"]).parents[2]
authenticate(complete["receipt"], complete["receipt_sha256"])
authenticate(complete["assembly"], complete["assembly_sha256"])
entry = read(complete["receipt"])
assert entry["end"] and not entry["failed_modules"] and not entry["blocked_modules"]
assert entry["assembly_sha256"] == complete["assembly_sha256"]
authenticate(local_root / "serial_compile_v3.py", entry["runner_sha256"])
authenticate(snapshot / "capture_mi24_local_completion.py", complete["audit_script_sha256"])
env = read(local_root / "LOCAL-ENVIRONMENT.json")
authenticate(env["compiler"], entry["compiler_sha256"])
manifest = read(candidate / "lake-manifest.json")
pins = {p["name"]: p["rev"] for p in manifest["packages"]}
assert pins == {p["package"]: p["commit"] for p in env["dependencies"]}
assert (candidate / "lean-toolchain").read_text().strip() == "leanprover/lean4:v4.33.1"
assert pins["mathlib"] == "0df444a360eaa60ab8c11dca51a86af692955474"
assert pins["leancert"] == "621a43d7cf21f87872392a01e874f2f1dbddc926"
for dep in ("mathlib", "leancert"):
    dotgit = local_root / ".lake/packages" / dep / ".git"
    head = (dotgit / "HEAD").read_text().strip()
    if head.startswith("ref: "):
        head = (dotgit / head[5:]).read_text().strip()
    assert head == pins[dep]

origins = {o["module"]: o for o in complete["commands_and_successful_origins"]}
assert len(origins) == 34 and set(origins) == set(modules)
authenticated_receipts = set()
authenticated_logs = set()
authenticated_assemblies = set()
total_reuse_hops = 0
for module, origin in origins.items():
    rel = modules[module]
    local_rel = module.replace(".", "/") + ".lean"
    assert origin["canonical_source_path"] == rel and origin["source_sha256"] == source_hashes[rel]
    chain = origin["reuse_chain"]
    assert chain and chain[0] == {"receipt": complete["receipt"], "sha256": complete["receipt_sha256"]}
    assert len({h["receipt"] for h in chain}) == len(chain)
    assert origin["historical_reuse_hops_authenticated"] == len(chain) - 1
    total_reuse_hops += len(chain) - 1
    for i, hop in enumerate(chain):
        path = Path(hop["receipt"])
        authenticate(path, hop["sha256"])
        assert retained[str(path)] == hop["sha256"]
        node = read(path)
        assert node.get("end") and node["platform"] == "darwin"
        assert node["threads"] == node["max_compiler_processes"] == 1
        assert 0 < node["memory_cap_mib"] <= 4096
        assert node["runner_sha256"] == entry["runner_sha256"]
        assert node["compiler_sha256"] == entry["compiler_sha256"]
        assembly = local_root / ("ASSEMBLY-" + path.parent.name.removeprefix("development-") + ".json")
        authenticate(assembly, node["assembly_sha256"])
        assembly_sources = read(assembly)["sources"]
        assert {p: item["sha256"] for p, item in assembly_sources.items()} == node["source_inputs"]
        authenticated_assemblies.add(str(assembly))
        authenticated_receipts.add(str(path))
        commands = [c for c in node["commands"] if c["module"] == module]
        assert len(commands) == 1
        command = commands[0]
        assert command["source_sha256"] == source_hashes[rel]
        assert command["output_sha256"] == origin["command"]["output_sha256"]
        for dep in closure(module):
            dep_rel = dep.replace(".", "/") + ".lean"
            assert node["source_inputs"][dep_rel] == source_hashes[modules[dep]], (module, dep, path)
        if i + 1 < len(chain):
            assert command["status"] == "reused_exact_successful_local_output"
            assert command["prior_receipt"] == chain[i + 1]["receipt"]
            assert command["prior_receipt_sha256"] == chain[i + 1]["sha256"]
            transitive = command.get("transitive_source_hashes")
            if transitive is not None:
                assert transitive == {dep.replace(".", "/") + ".lean": source_hashes[modules[dep]] for dep in closure(module)}
        else:
            assert str(path) == origin["success_origin_receipt"]
            assert sha(path) == origin["receipt_sha256"]
            assert command == origin["command"] and command["exit_code"] == 0
            assert command["cwd"] == str(local_root)
            expected_argv = [env["compiler"], "--threads=1", "--memory=4096", "-o",
                             str(local_root / ".lake/build/lib/lean" / (local_rel[:-5] + ".olean")), local_rel]
            assert command["argv"] == expected_argv
            assert command["end"] >= command["start"] and command["elapsed_seconds"] >= 0
            assert set(command["dependency_olean_sha256"]) == set(imports[module])
            for dep, h in command["dependency_olean_sha256"].items():
                assert h == origins[dep]["command"]["output_sha256"], (module, dep)
            log = path.parent / (module + ".log")
            authenticate(log, command["log_sha256"])
            assert retained[str(log)] == command["log_sha256"]
            assert "error:" not in log.read_text() and "sorryAx" not in log.read_text()
            authenticated_logs.add(str(log))

assert authenticated_receipts | authenticated_logs == set(retained)
assert len(authenticated_receipts) == 25 and len(authenticated_logs) == 34
solution_origin = origins["NLA.MI24.Solution"]
entry_log = Path(solution_origin["success_origin_receipt"]).parent / "NLA.MI24.Solution.log"
observed = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", entry_log.read_text(), re.M)
assert [name for name, _ in observed] == names
observed_axioms = {name: [a.strip() for a in value.split(",")] for name, value in observed}
assert observed_axioms == complete["observed_axioms"]
assert all(set(ax) <= PERMITTED for ax in observed_axioms.values())
num_origin = origins["NLA.MI24.Numerical"]
num_log = Path(num_origin["success_origin_receipt"]).parent / "NLA.MI24.Numerical.log"
assert "'NLA.MI24.young_weight_interval' depends on axioms: [propext, Classical.choice, Quot.sound]" in num_log.read_text()
assert "'NLA.MI24.youngWeight_complement_bounds' depends on axioms: [propext, Classical.choice, Quot.sound]" in num_log.read_text()

# The record has a harmless display-path typo, retained verbatim and disclosed.
assert complete["source_filename_mapping"] == {
    "local": "NLA.MI24.Solution.lean", "canonical": "Solution.lean",
    "sha256": source_hashes["Solution.lean"]}
assert bindings["source_filename_mapping_correction"]["actual_local_source_path"] == "NLA/MI24/Solution.lean"
assert solution_origin["command"]["argv"][-1] == "NLA/MI24/Solution.lean"

statement_packet = Path(freeze["packet"])
authenticate(statement_packet / "MANIFEST.json", freeze["packet_manifest_sha256"])
manifest_files(statement_packet / "MANIFEST.json")
authenticate(statement_packet / "run/RECEIPT.json", freeze["local_statement_receipt_sha256"])
for rel, h in freeze["frozen_files"].items():
    authenticate(statement_packet / "candidate" / rel, h)
for reviewer in freeze["reviewers"]:
    path = Path(reviewer["manifest"])
    authenticate(path, reviewer["manifest_sha256"])
    manifest_files(path)
    rv = read(path.parent / "VERDICT.json")
    assert rv["packet_manifest_sha256"] == freeze["packet_manifest_sha256"]
    assert "APPROVE" in rv["verdict"]

for item in bindings["references"]:
    authenticate(item["path"], item["sha256"], item["bytes"])
standards_root = Path(bindings["standards_root"])
standards = read(standards_root / "STANDARD-BINDINGS.json")
for standard in standards["standards"]:
    authenticate(standards_root / standard["path"], standard["sha256"], standard.get("bytes"))
    if "TauCetiReview" in standard["path"]:
        assert standard["upstream"]["commit"] == "afb424eda89e8ac96d9eb69f6a88972055a4cd1b"

print(json.dumps({
    "status": "PASS_READ_ONLY_INTEGRITY",
    "review_verdict": verdict["overall"],
    "snapshot_manifest_sha256": SNAPSHOT_MANIFEST_SHA256,
    "snapshot_files_authenticated": len(snapshot_files),
    "full_source_modules_authenticated": len(modules),
    "frozen_contract_headers_identical": len(names),
    "statement_review_manifests_authenticated": len(freeze["reviewers"]),
    "local_receipts_authenticated": len(authenticated_receipts),
    "successful_origin_logs_authenticated": len(authenticated_logs),
    "local_assemblies_authenticated": len(authenticated_assemblies),
    "source_matched_reuse_hops_authenticated": total_reuse_hops,
    "final_logged_axiom_reports": len(observed),
    "final_source_kernel_assertions": len(names),
    "numerical_origin_run": 293,
    "solution_origin_run": 325,
    "known_display_path_typo_authenticated_and_disclosed": True,
    "read_only_checker_Lean_runs": 0,
    "read_only_checker_Comparator_runs": 0,
    "scope": "Source and retained root-run evidence integrity only; no local recompilation, Linux Comparator, publication, or count approval."
}, indent=2))
