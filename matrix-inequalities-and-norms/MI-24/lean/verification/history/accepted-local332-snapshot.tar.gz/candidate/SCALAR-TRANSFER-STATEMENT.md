# Scalar bridge statement, before proof implementation

Scope: auxiliary lemma for already frozen MI-24 C08. It does not alter any
canonical statement or frozen definition. Authoring scope: root, independent
of the compound-matrix source author.

For every natural n and a,b : Fin n → ℝ, assume a and b are strictly positive,
a is antitone, and for every k ≤ n,

    (∏ i : Fin k, a (Fin.castLE hk i)) ≤
    (∏ i : Fin k, b (Fin.castLE hk i)).

Prove (∑ i, a i) ≤ (∑ i, b i). No sorting hypothesis on b is needed.
The n=0 and k=0 cases are included. No numerical experiment is involved.

Analytic justification checked before implementation: put δ=log a−log b.
The prefix sums of δ are nonpositive by positivity and logarithms of products.
The inequality log(b/a)≤b/a−1 gives a−b≤aδ pointwise. A finite Abel argument
with nonnegative descending weights a gives ∑aδ≤0. The latter is proved by
subtracting the final weight and inducting on the prefix, rather than importing
majorization machinery. This uses exact real arithmetic and avoids interval
subdivision or numerical eigenvalue evaluation.

This helper statement has been discussed with the compound proof author.
No complete proof or independent final review is claimed by this document.
