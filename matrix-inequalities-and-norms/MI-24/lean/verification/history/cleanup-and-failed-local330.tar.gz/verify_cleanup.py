#!/usr/bin/env python3
"""Read-only source-scope checker; does not invoke Lean, Lake, or Comparator."""
from pathlib import Path
import argparse,hashlib,json,re,difflib
ap=argparse.ArgumentParser()
ap.add_argument('--candidate',type=Path,default=Path('/private/tmp/nla-lean-next-20260915/next-proofs/MI-24'))
ap.add_argument('--snapshot',type=Path,default=Path('/private/tmp/nla-lean-next-20260915/MI24-local325-source-snapshot'))
a=ap.parse_args();O=Path(__file__).resolve().parent;P=a.candidate;S=a.snapshot
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((O/'BASE-PACKET.json').read_text());BASE=(O/base['relative_directory']).resolve();assert h(BASE/'MANIFEST.json')==base['manifest_sha256']
for key,rec in json.loads((BASE/'MANIFEST.json').read_text())['files'].items():
 assert h(BASE/key)==rec['sha256'],key
before=json.loads((BASE/'BEFORE.json').read_text());changes=json.loads((O/'CHANGES.json').read_text());checks=0
assert changes['comment_sites']==61
sm=json.loads((S/'MANIFEST.json').read_text())
for f in sm['files']:
 p=S/f['path'];assert p.stat().st_size==f['bytes'] and h(p)==f['sha256'],f['path'];checks+=1
for f,sha in before['frozen'].items():
 assert h(P/f)==sha==h(S/'candidate'/f),f;checks+=1
heads=lambda t:{m[1]:''.join(m[0].split()) for m in re.findall(r'(?m)^((?:private\s+)?(?:lemma|theorem)\s+(\S+)\b[\s\S]*?)(?=\s*:=)',t)}
stripline=lambda t:'\n'.join(l for l in t.splitlines() if not l.lstrip().startswith('--'))
removed=[];codechanged=[];diff=''
for f,rec in changes['changed_files'].items():
 p=P/f;b=BASE/'before'/p.name;assert h(b)==rec['before_sha256']==h(S/'candidate'/f),f;assert h(p)==rec['after_sha256'],f
 bs=b.read_text();ps=p.read_text();bh=heads(bs);ph=heads(ps)
 assert all(ph[k]==v for k,v in bh.items() if k in ph),f
 assert not(ph.keys()-bh.keys()),f
 removed.extend(bh.keys()-ph.keys())
 if stripline(bs)!=stripline(ps):codechanged.append(p.name)
 diff+=''.join(difflib.unified_diff(bs.splitlines(keepends=True),ps.splitlines(keepends=True),fromfile='before/'+f,tofile='after/'+f));checks+=4
assert removed==['compoundMatrix_conjTranspose'],removed
assert sorted(codechanged)==['CompoundSpectral.lean','DiagonalPowers.lean'],codechanged
assert diff==(O/'cleanup.diff').read_text()
texts={str(p.relative_to(P)):p.read_text() for p in (P/'NLA/MI24').glob('*.lean')}
assert all('compoundMatrix_conjTranspose' not in t for t in texts.values())
ch=(P/'Challenge.lean').read_text();names=json.loads((P/'comparator.json').read_text())['theorem_names']
for qual in names:
 name=qual.rsplit('.',1)[-1];pat=r'(?m)^theorem\s+'+re.escape(name)+r'\b[\s\S]*?(?=\s*:=)';expected=re.search(pat,ch);found=[m.group() for t in texts.values() for m in re.finditer(pat,t)]
 assert expected is not None and len(found)==1 and ''.join(expected.group().split())==''.join(found[0].split()),qual;checks+=1
print(json.dumps({'result':'PASS','scope':'Read-only source integrity and cleanup scope; no Lean or Comparator execution.','checks':checks,'snapshot_payloads_checked':len(sm['files']),'edited_files':len(changes['changed_files']),'comment_sites':61,'selected_headers':len(names),'code_changed_files':sorted(codechanged),'removed_alias':removed[0],'snapshot_manifest_sha256':h(S/'MANIFEST.json')},indent=2))
