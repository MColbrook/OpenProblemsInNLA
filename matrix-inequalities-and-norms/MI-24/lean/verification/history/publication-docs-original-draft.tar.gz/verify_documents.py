#!/usr/bin/env python3
"""Read-only documentation checks. Never invokes Lean, Lake, Comparator or Git."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import jsonschema

parser = argparse.ArgumentParser()
parser.add_argument("--campaign-root", type=Path)
parser.add_argument("--require-sealed", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent
checks = 0


def check(value, label):
    global checks
    if not value:
        raise AssertionError(label)
    checks += 1


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((root / name).read_text())


schema_path = root / "source-inputs/standards/v0.4.schema.json"
check(digest(schema_path) == "25ff6b25ca4511635aff4443cf20480c15e59dddf19591c730950b442ea54fce", "pinned schema")
metadata = read("formalization.yaml")
check(metadata["version"] == "v0.4", "repository schema-version spelling")
jsonschema.Draft7Validator(json.loads(schema_path.read_text())).validate(metadata)
checks += 1
state = read("STATE.json")
mapping = read("IMPLEMENTATION-MAP.json")
scope = read("DOCUMENT-SCOPE.json")
rows = mapping["contracts"]
results = metadata["status"]["main_results"]
check(len(rows) == len(results) == 22, "22 contracts")
check(len(mapping["proof_closure_sources"]) == 34, "34-module proof closure")
check([x["contract"] for x in rows] == [f"C{i:02d}" for i in range(1, 23)], "all frozen IDs")
check([x["declaration"] for x in rows] == [x["declaration"] for x in results], "complete metadata coverage")
check(len({x["declaration"] for x in rows}) == 22, "distinct exports")
for row, result in zip(rows, results):
    check(row["file"] == result["file"], "matching declaration file")
    check(row["file_sha256"] == result["source_sha256"], "matching declaration source hash")
    check(result["comparator_config"] == "comparator.json", "comparator config")
    check(result["sorry_count"] == 0, "proof sorry count")
    check(result["axioms"] == ["propext", "Classical.choice", "Quot.sound"], "actual permitted axioms")
    check(result["literature_dependencies"] == [], "no literature theorem admitted")
check(state["local_proof"]["run"] == "development-332", "current local proof scope")
check(state["local_type_diagnostic"]["run"] == "development-333", "current diagnostic scope")
check(state["Linux_Comparator"]["status"] == "not-run", "Linux still pending")
check(state["Linux_Comparator"]["run_id"] is None, "no invented run")
check(not state["ready_to_publish_as_verified"], "no publication approval")
check(state["formalization_count_increment"] == 0, "no count increment")
check(state["canonical_status_to_retain"] == "Solved", "canonical status retained")
check("pending" in state["review"]["final_current_source_status"], "final successor reviews pending")
check(metadata["status"]["sorry_count"] == metadata["status"]["sorry_in_definitions"] == 0, "proof counts")
check(metadata["status"]["deliberate_challenge_placeholders"] == 22, "intentional contracts distinguished")
check(scope["Lean_Lake_Comparator_executions_by_this_task"] == 0, "no compiler claim")
check(scope["not_independent_review"], "author role acknowledged")
check('defaultTargets = ["Solution"]' in (root / "lakefile.toml").read_text(), "staged default proof target")
check(read("lake-manifest.json")["name"] == "NLAMI24", "correct project manifest name")
check("bootstrap.sh" in (root / "README.md").read_text(), "checker bootstrap instructions")
check("verify.sh" in (root / "README.md").read_text(), "checker verification instructions")
for path in root.rglob("*"):
    if path.is_file():
        check(not path.is_symlink(), "no staged symlink")
        check(path.suffix not in {".pdf", ".olean", ".ilean", ".zip"}, "compact document payload")
        body = path.read_text()
        check(not re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", body), "no published email")

if args.campaign_root:
    base = args.campaign_root.resolve()
    project = base / "next-proofs/MI-24"
    for rel, expected in scope["observed_external_evidence"].items():
        check(digest(base / rel) == expected, "external evidence identity: " + rel)
    complete = json.loads((base / "MI24-LOCAL-COMPLETE-332.json").read_text())
    check(complete["sources"] == mapping["proof_closure_sources"], "actual332 full source map")
    for rel, expected in complete["sources"].items():
        check(digest(project / rel) == expected, "current proof source: " + rel)
    frozen = json.loads((base / "MI24-STATEMENT-FREEZE-local289.json").read_text())["frozen_files"]
    check(frozen == scope["expected_frozen_files"], "exact frozen metadata")
    for rel, info in frozen.items():
        expected = info if isinstance(info, str) else info["sha256"]
        check(digest(project / rel) == expected, "frozen input: " + rel)
    comparator = json.loads((project / "comparator.json").read_text())
    check(comparator["theorem_names"] == [x["declaration"] for x in rows], "actual comparator names")
    check(comparator["definition_names"] == [], "no substituted definitions")
    diag = json.loads((base / "MI24-type-diagnostics-333/COMPARISON.json").read_text())
    check(diag["all22_match"] and not diag["Comparator_executed"], "actual local diagnostic scope")
    check(diag["actual_elaborated_body_routes"] == mapping["consumed_LeanCert_routes"], "actual certificate routes")
    for row in rows:
        check(complete["observed_axioms"][row["declaration"]] == row["actual_axioms"], "actual axiom observation")
    before = (project / "lakefile.toml").read_text()
    check((root / "lakefile.toml").read_text() == before.replace('defaultTargets = ["Challenge"]', 'defaultTargets = ["Solution"]'), "only default-target Lake edit")
    before_manifest = json.loads((project / "lake-manifest.json").read_text())
    check(before_manifest["name"] == "NLAMI22", "historical root name preserved")
    before_manifest["name"] = "NLAMI24"
    check(read("lake-manifest.json") == before_manifest, "only manifest-root-name semantic edit")
    canonical = base / "next-statements/MI24-full-20260918/sources/current"
    for name in ["README.md", "solution.md"]:
        check((root / "source-inputs/canonical" / name).read_bytes() == (canonical / name).read_bytes(), "canonical source retained")

manifest_path = root / "MANIFEST.json"
if args.require_sealed:
    check(manifest_path.exists(), "sealed manifest exists")
if manifest_path.exists():
    manifest = read("MANIFEST.json")
    listed = {row["path"] for row in manifest["files"]}
    actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p != manifest_path}
    check(listed == actual, "complete document manifest coverage")
    for row in manifest["files"]:
        path = root / row["path"]
        check(digest(path) == row["sha256"], "sealed payload hash: " + row["path"])
        check(path.stat().st_size == row["bytes"], "sealed payload size")

print(json.dumps({"status": "PASS", "checks": checks,
                  "scope": "Documentation schema, coverage, hashes, privacy and packaging edits only; not Lean, Comparator or independent proof review",
                  "external_live_hashes_checked": bool(args.campaign_root),
                  "python": sys.executable, "jsonschema": jsonschema.__file__,
                  "compiler_executions": 0, "count_increment": 0}, indent=2))
