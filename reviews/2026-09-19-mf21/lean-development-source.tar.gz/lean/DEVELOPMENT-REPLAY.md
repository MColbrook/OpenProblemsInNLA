# Fresh local source replay

`replay_development.py` is a portable developer check. It does **not** replace the repository's pinned Linux Comparator protocol in [`tools/lean/HARNESS.md`](../../../tools/lean/HARNESS.md), and it does not establish that a Lean statement matches the intended mathematics.

Run it with the exact Lean executable and the external dependency caches for the committed manifest:

```sh
python3 replay_development.py \
  --lean /absolute/path/to/lean-4.33.1/bin/lean \
  --packages /absolute/path/to/external/.lake/packages \
  --output /absolute/path/to/a-new-replay-directory \
  --jobs 2
```

The output directory must not exist and must be outside this source tree. No host-specific path is embedded in the script. Python 3.10 or newer is required. Each run:

1. Reads the local import graph, including all vendored `MF21Transcendence` modules, and freezes source files in a new directory. Files whose names contain `Probe` are excluded. Any further exclusions must be listed explicitly with `--exclude ModuleName`; a dependency on an excluded module is an error.
2. Compiles the graph in dependency order with `lean --trust=0`. Its `LEAN_PATH` contains only the new output directory and manifest-listed external dependency cache directories. Existing project, `.lake`, and private development oleans are never searched.
3. Retains every compiler log, including all existing `#print axioms` outputs. Compilation errors, timeout, reported `sorry`, and nonstandard printed axioms fail the replay.
4. Compiles a generated audit that enumerates **every declaration** in the selected local module tables, including private and generated declarations, and checks each transitive axiom closure against exactly `propext`, `Classical.choice`, and `Quot.sound`. An unused custom axiom therefore fails too.
5. Records source, tool, compiler-log, output-olean, generated-audit and manifest SHA256 hashes, platform and compiler version, external dependency locations and revision observations in `result.json`. Changes to the original source after the snapshot produce a distinct non-success status.

External dependency oleans and the Lean executable remain trusted inputs. The runner compares an external checkout's Git revision with the manifest when checkout metadata is available. If metadata is absent, it records that fact explicitly; it does not claim to have reconstructed or authenticated those cache files from their source revision. A missing unused external cache is recorded; any import that needs it fails normally. This matters for the September 20 developer run, whose existing package caches survived temporary-directory cleanup while their `.git` metadata did not.

The runner was checked with a positive fixture and a negative fixture containing an otherwise unused custom axiom. The positive fixture passed; the negative fixture compiled its declaration but failed the generated closure audit as intended. These are developer controls, not substitutes for the Comparator harness's sandbox and negative controls.

# Authoritative Linux check

The repository harness requires a non-root Linux user, Python 3, Git, elan, Go ≥1.24, a C compiler, `/usr/bin/bwrap`, usable unprivileged user/mount namespaces, and a working user systemd session. A generic container without that session is insufficient. Its own sandbox probe, kernel replay controls, Comparator controls and axiom controls must all pass unchanged.

The project must be a committed, unchanged, self-contained project with a TOML Lakefile and exact Git dependency manifest. Local path dependencies and compiled artifacts are rejected. A local commit is sufficient; pushing or opening a GitHub PR is unnecessary. The candidate's `Challenge`, final theorem selection and statement equality require separate review.

On this Apple Silicon host, a local ARM Linux VM is a viable route. Tart's official documentation provides a standalone release archive, headless Ubuntu images and a `TART_HOME` override. A task-specific `/private/tmp` directory can contain the executable, VM and caches, with no host directory mounts or shared clipboard. Provisioning packages and a non-root verification user changes only the guest. Once the VM's actual systemd, namespace and sandbox prerequisites pass, use the unchanged `bootstrap.sh`, `selftest.sh`, and `verify.sh` commands in `HARNESS.md`. Downloaded public inputs, VM image digest and tool hashes should be retained in the verification receipt.

Sources: [Tart quick start](https://github.com/openai/tart/blob/main/docs/quick-start.md), [Tart VM storage and Linux notes](https://tart.run/faq/). This describes a route, not a successful Linux verification result.
