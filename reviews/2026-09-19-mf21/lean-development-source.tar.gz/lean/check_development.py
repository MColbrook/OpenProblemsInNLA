from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parent
packages=Path('/private/tmp/nla-formalization-campaign-20260915/linear-systems-and-elimination/IE-15/lean/.lake/packages')
env=os.environ.copy()
env['LEAN_PATH']=os.pathsep.join([str(root)]+[str(x/'.lake/build/lib/lean') for x in packages.iterdir() if x.is_dir()])
filename=sys.argv[1]
command=['/private/tmp/nla-campaign-toolchain/lean-4.33.1-darwin_aarch64/bin/lean']
if '--raw' in sys.argv: command+=['--trust=0']
command+=['-o',str(Path(filename).with_suffix('.olean')),filename]
r=subprocess.run(command,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(r.stdout,end='')
(root/'verification'/(Path(filename).stem+'-development.log')).write_text(r.stdout)
raise SystemExit(r.returncode)
