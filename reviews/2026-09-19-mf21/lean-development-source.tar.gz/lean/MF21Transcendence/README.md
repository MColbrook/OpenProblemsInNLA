# Provenance and verification of the pi-transcendence input

The six Lean source files in this directory are adapted from Trevor Morris's
[lean-formalizations repository](https://github.com/gotrevor/lean-formalizations/tree/3a24a73416f83c32b4d4a2ac09588524c6291650/src/LeanFormalizations/NumberTheory/Transcendence),
commit `3a24a73416f83c32b4d4a2ac09588524c6291650`, under the accompanying
Apache-2.0 [LICENSE](LICENSE). Original AI-assistance disclosures and theorem
provenance are retained in the source comments. The original repository
targets Lean/mathlib v4.31.0. This copy has been checked with Lean 4.33.1 and
mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474`.

The dependency chain closes the Lindemann proof at the actual real constant
`Real.pi`; it does not introduce transcendence as an axiom or hypothesis.
The file `PiTranscendental.lean` assembles the earlier analytic approximation
theorem, integer nonvanishing, conjugate-polynomial construction, and
symmetric-polynomial lemmas. Its exact conclusion is
`Transcendental ℚ Real.pi`.

Changes from the upstream snapshot are limited to local import prefixes and
one compatibility fix: explicitly supplying
`Multiset.powersetCard_zero_right` in the empty/successor case of
`ringHom_map_multiset_esymm`. No mathematical statement was altered.
Original and adapted SHA-256 hashes are recorded in
[provenance.json](provenance.json).

Run `python3 ../verify_transcendence.py --lean LEAN_BINARY --packages PACKAGES_DIRECTORY`
from any working directory, supplying the pinned toolchain and dependency
cache when they are not the defaults. The script recompiles the full
six-file closure, then `MF21Transcendence.lean`, `MF21TraceSeries.lean`, and
`FiniteTraceObstruction.lean`, using
`--trust=0`. Its output certificate is
`../verification/transcendence-result.json`. The fourteen exported
arithmetic theorems' checked axiom footprints contain only `propext`,
`Classical.choice`, and `Quot.sound`.

The source was located through the public
[mathlib documentation PR #43144](https://github.com/leanprover-community/mathlib4/pull/43144).
The alternative [mathlib Lindemann–Weierstrass PR #28013](https://github.com/leanprover-community/mathlib4/pull/28013)
was also inspected at commit `5a0057ccc26b13a4e361f503f5f765bf56a8d353`;
it needs newer supporting mathlib modules and was not imported here.

`MF21TraceSeries.lean` also proves the exact shifted-series evaluations and
the irrationality of the actual model trace for every integer `m ≥ 3`, with
no rationality, tail-evaluation, or transcendence hypotheses.

`FiniteTraceObstruction.lean` proves the abstract eventual finite-head
separation and its transfer to the original remainder scale. Its actual
spectral trace, majorant, and approximation-limit inputs still need to be
instantiated for the Toeplitz problem.

This closes the trace-arithmetic dependency of MF-21. It does not establish
Toeplitz asymptotics, the Green-kernel trace limit, or the full MF-21 theorem.
