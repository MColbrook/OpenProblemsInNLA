#!/usr/bin/env python3
"""Replay only the MF-21 audit components; never certifies the Toeplitz theorem."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lean', default='lean', help='Lean 4.33.1 executable')
parser.add_argument('--packages', type=Path, default=Path(__file__).parent / '.lake/packages',
                    help='directory containing pinned Mathlib and its compiled dependencies')
args = parser.parse_args()
root = Path(__file__).resolve().parent
packages = args.packages.resolve()
output = root / 'verification'
output.mkdir(exist_ok=True)
version = subprocess.check_output([args.lean, '--version'], text=True).strip()
if 'version 4.33.1,' not in version:
    raise SystemExit('Wrong Lean version: ' + version)
mathlib = packages / 'mathlib'
commit = subprocess.check_output(['git', '-C', str(mathlib), 'rev-parse', 'HEAD'], text=True).strip()
expected = '0df444a360eaa60ab8c11dca51a86af692955474'
if commit != expected:
    raise SystemExit('Wrong Mathlib commit: ' + commit)
dirty = subprocess.check_output(['git', '-C', str(mathlib), 'status', '--porcelain', '--untracked-files=no'], text=True)
if dirty:
    raise SystemExit('Mathlib tracked files are modified: ' + dirty)
env = os.environ.copy()
env['LEAN_PATH'] = os.pathsep.join(str(p / '.lake/build/lib/lean')
                                  for p in sorted(packages.iterdir()) if p.is_dir())
records = []
allowed_axioms = {'propext', 'Classical.choice', 'Quot.sound'}
for filename, expected_count in [('TraceArithmetic.lean', 4), ('CoefficientUniqueness.lean', 3), ('Challenge.lean', 1)]:
    source = root / filename
    command = [args.lean, '--trust=0', filename]
    proc = subprocess.run(command, cwd=root, env=env, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / (source.stem + '.log')).write_text(proc.stdout)
    axioms = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", proc.stdout)
    valid_axioms = len(axioms) == expected_count and all(
        {a.strip() for a in values.split(',') if a.strip()} <= allowed_axioms
        for _, values in axioms)
    record = {'file': filename, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'command': command, 'returncode': proc.returncode,
              'axiom_lists': {name: [a.strip() for a in vals.split(',') if a.strip()]
                             for name, vals in axioms},
              'expected_axiom_lists_present_and_allowed': valid_axioms}
    records.append(record)
    print(proc.stdout, end='', flush=True)
    if proc.returncode or not valid_axioms:
        print('CHECK FAILED', filename, flush=True)
        break
report = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Partial MF-21 audit components; NOT full MF-21 verification',
          'lean_version': version, 'mathlib_commit': commit,
          'mathlib_tracked_files_clean': not dirty, 'packages_cache': str(packages),
          'trust_level': 0, 'files': records,
          'success': len(records) == 3 and all(r['returncode'] == 0 and
                    r['expected_axiom_lists_present_and_allowed'] for r in records)}
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if report['success'] else 1)
