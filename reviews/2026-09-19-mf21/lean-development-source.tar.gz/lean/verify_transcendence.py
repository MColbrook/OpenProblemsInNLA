#!/usr/bin/env python3
"""Rebuild the trace arithmetic and finite-head transfer lemmas; inspect axioms."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lean', default='lean')
parser.add_argument('--packages', type=Path,
                    default=Path(__file__).parent / '.lake/packages')
args = parser.parse_args()
root = Path(__file__).resolve().parent
packages = args.packages.resolve()
version = subprocess.check_output([args.lean, '--version'], text=True).strip()
if 'version 4.33.1,' not in version:
    raise SystemExit('Unexpected Lean version: ' + version)
mathlib = packages / 'mathlib'
commit = subprocess.check_output(['git', '-C', str(mathlib), 'rev-parse', 'HEAD'],
                                 text=True).strip()
if commit != '0df444a360eaa60ab8c11dca51a86af692955474':
    raise SystemExit('Unexpected mathlib commit: ' + commit)
if subprocess.check_output(['git', '-C', str(mathlib), 'status', '--porcelain',
                            '--untracked-files=no'], text=True):
    raise SystemExit('Tracked mathlib source modifications detected')
build = root / '.lake/build/lib/lean'
(build / 'MF21Transcendence').mkdir(parents=True, exist_ok=True)
logs = root / 'verification'
logs.mkdir(exist_ok=True)
env = os.environ.copy()
env['LEAN_PATH'] = os.pathsep.join([str(build)] + [
    str(p / '.lake/build/lib/lean') for p in sorted(packages.iterdir()) if p.is_dir()])
files = ['MF21Transcendence/' + x + '.lean' for x in [
    'ETranscendental', 'HermiteLindemann', 'PiLindemann', 'MonicRootSums',
    'SubsetSumEsymm', 'PiTranscendental']] + [
        'MF21Transcendence.lean', 'MF21TraceSeries.lean', 'FiniteTraceObstruction.lean']
records = []
axiom_lists = {}
expected_axiom_counts = {'MF21Transcendence.lean': 4, 'MF21TraceSeries.lean': 5,
                         'FiniteTraceObstruction.lean': 5}
for filename in files:
    output = build / Path(filename).with_suffix('.olean')
    command = [args.lean, '--trust=0', '-o', str(output), filename]
    proc = subprocess.run(command, cwd=root, env=env, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (logs / ('Transcendence-' + Path(filename).stem + '.log')).write_text(proc.stdout)
    print(filename, proc.returncode, proc.stdout, flush=True)
    found = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", proc.stdout)
    current_axioms = {name: [a.strip() for a in values.split(',') if a.strip()]
                      for name, values in found}
    axiom_lists.update(current_axioms)
    records.append({'file': filename,
                    'sha256': hashlib.sha256((root / filename).read_bytes()).hexdigest(),
                    'command': command, 'returncode': proc.returncode,
                    'axiom_count_correct': len(current_axioms) == expected_axiom_counts.get(filename, 0)})
    if proc.returncode:
        break
valid = len(axiom_lists) == sum(expected_axiom_counts.values()) and all(set(x) <= {
    'propext', 'Classical.choice', 'Quot.sound'} for x in axiom_lists.values())
report = {'scope': 'Unconditional pi transcendence, actual MF-21 model series irrationality, and abstract eventual finite-head trace obstruction; not the full Toeplitz theorem',
          'lean_version': version, 'mathlib_commit': commit, 'trust_level': 0,
          'files': records, 'axiom_lists': axiom_lists,
          'success': len(records) == len(files) and all(x['returncode'] == 0 and x['axiom_count_correct'] for x in records)
                     and valid}
(logs / 'transcendence-result.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if report['success'] else 1)
