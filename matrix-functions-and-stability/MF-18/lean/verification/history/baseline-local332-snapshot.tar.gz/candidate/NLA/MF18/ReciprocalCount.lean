/-
Copyright (c) 2026 George Stepaniants. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: George Stepaniants
Department of Computing and Mathematical Sciences, California Institute of Technology.
Substantial OpenAI Codex assistance.

Reciprocal conjugation is counted with complete algebraic multiplicities.
The proof explicitly accounts for roots at zero and lost leading degree;
there is no generic nonsingularity or absence-of-unit-roots assumption.
-/
import NLA.MF18.ReflectedRoots
import Lean.Elab.Tactic.Omega

set_option autoImplicit false

noncomputable section
namespace NLA.MF18

theorem conjugate_zero_multiplicity (p : CPoly) :
    (p.map (starRingEnd ℂ)).rootMultiplicity 0 = p.rootMultiplicity 0 := by
  simpa only [map_zero] using
    (Polynomial.eq_rootMultiplicity_map (p := p) (f := starRingEnd ℂ) star_injective (0 : ℂ)).symm

theorem conjugate_disk_count (p : CPoly) :
    diskRootCount (p.map (starRingEnd ℂ)) = diskRootCount p := by
  classical
  have hr := Polynomial.roots_map_of_injective_of_card_eq_natDegree
    (p := p) (f := starRingEnd ℂ) star_injective (IsAlgClosed.card_roots_eq_natDegree (p := p))
  unfold diskRootCount
  rw [← hr, Multiset.filter_map, Multiset.card_map]
  congr 1
  apply Multiset.filter_congr
  intro z _
  simp only [Function.comp_apply, starRingEnd_apply, norm_star]

theorem norm_partition_card (s : Multiset ℂ) :
    (s.filter (fun z => ‖z‖ < 1)).card + (s.filter (fun z => ‖z‖ = 1)).card +
      (s.filter (fun z => 1 < ‖z‖)).card = s.card := by
  classical
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons z s ih =>
    rcases lt_trichotomy ‖z‖ 1 with h | h | h
    · have hne : ‖z‖ ≠ 1 := ne_of_lt h
      have hnot : ¬1 < ‖z‖ := not_lt_of_ge h.le
      simp only [Multiset.filter_cons, h, hne, hnot, if_true, if_false,
        Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega
    · simp only [Multiset.filter_cons, h, lt_self_iff_false, if_false,
        if_true, Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega
    · have hne : ‖z‖ ≠ 1 := ne_of_gt h
      have hnot : ¬‖z‖ < 1 := not_lt_of_ge h.le
      simp only [Multiset.filter_cons, h, hne, hnot, if_true, if_false,
        Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega

theorem reciprocal_count_identity {n : ℕ} (C R : Mat n)
    (hR : R.IsHermitian) (hreg : unregularizedPolynomial C R ≠ 0) :
    (unregularizedPolynomial C R).natDegree +
      (unregularizedPolynomial C R).rootMultiplicity 0 = 2 * n ∧
    2 * diskRootCount (unregularizedPolynomial C R) +
      circleRootCount (unregularizedPolynomial C R) = 2 * n := by
  have hd : (unregularizedPolynomial C R).natDegree ≤ 2 * n :=
    pencil_degree_bound C C.conjTranspose R
  have hc := reflected_zero_and_disk_count (2 * n) (unregularizedPolynomial C R) hreg hd
  rw [unregularized_reflection C R hR, conjugate_zero_multiplicity, conjugate_disk_count] at hc
  have hp := norm_partition_card (unregularizedPolynomial C R).roots
  rw [IsAlgClosed.card_roots_eq_natDegree] at hp
  change diskRootCount (unregularizedPolynomial C R) +
    circleRootCount (unregularizedPolynomial C R) +
    ((unregularizedPolynomial C R).roots.filter (fun z : ℂ => 1 < ‖z‖)).card =
    (unregularizedPolynomial C R).natDegree at hp
  constructor <;> omega

#print axioms reciprocal_count_identity

end NLA.MF18
