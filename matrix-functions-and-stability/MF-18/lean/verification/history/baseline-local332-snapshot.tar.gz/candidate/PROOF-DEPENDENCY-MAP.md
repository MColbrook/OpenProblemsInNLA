# MF-18 proof and review map

Author-prepared navigation aid by George Stepaniants, Department of Computing
and Mathematical Sciences, California Institute of Technology, with substantial
OpenAI Codex assistance. This is neither an independent review nor evidence of
an executed Lean, kernel-trust, or Comparator run. Exact compilation receipts,
source inventories, statement approvals, and final independent proof reviews
must be retained separately.

The target is the full complex Green-function rank equality in the canonical
MF-18 README and George Stepaniants's complete `solution.md`, not the earlier
real auxiliary theorem. Guo, Kuo, and Lin retain attribution for the original
problem and prior results; the auxiliary theorem retains its separate credit.

`Definitions.lean`, `Challenge.lean`, and `comparator.json` were approved and
frozen before proof implementation. The 25 selected declarations preserve their
frozen headers. `Solution.lean` imports the full 38-module local proof closure
through `CanonicalRank` and `StabilitySemantics`, then requests axiom and
kernel-trust checks on each selected declaration. These commands and the source
call paths below do not themselves prove that a check has run.

| Frozen contracts | Source modules and role | Points requiring full-target review |
| --- | --- | --- |
| C01 | `Numerical`: kernel LeanCert proof of `0 < 1/2 < 1`. | The certificate is consumed in C05; numerical computation is reduced to this constant scalar bound. |
| C02 | `StabilitySemantics`: characteristic roots agree with the original spectral-radius premise. | All dimensions `n >= 1`; ordinary complex spectrum, not an encoded substitute. |
| C03-C04, C12 | `PencilAlgebra`: determinant evaluation, fixed `2n` degree bound, exact nonlinear-equation factorization. | `B_eta = C* + i eta D*` is not replaced by `A_eta*`; singular coefficient matrices remain allowed. |
| C05-C06 | `Positivity`, `PairingAlgebra`, `BoundaryNonvanishing`: positive averaging and no unit-circle roots in the regularized homotopy. | Full Hermitian complex model; both homotopy endpoints and `lambda = +/-1`. |
| C07-C10 | `CayleyAlgebra`, `CayleyBoundary`, `CayleyCount`, `RootEnumeration`, `RootProductLimits`, `RootCountLimits`, `HalfPlaneHomotopy`, `CoefficientContinuity`, `DiskHomotopy`. | The Cayley grade is fixed at `N` even if degree drops. Extra roots at `-1` are accounted for. Compact root tuples and coefficient continuity prove homotopy count constancy without an argument-principle premise. |
| C11-C15 | `RegularizedCount`, `SolutionPolynomial`, `ComplementaryStability`, `StabilityLimits`, `LimitingEquation`. | The regularized count is `n`. Both selected and complementary matrices have weakly stable limits. The given one-sided limit is used through an explicit positive sequence; no continuous eigenvector selection or nonsingularity of `C,D` is assumed. |
| C16 | `ReflectionAlgebra`, `ReflectedRoots`, `ReciprocalCount`. | Fixed-grade reciprocal reflection counts algebraic multiplicities, zero roots, and lost leading degree. It proves both `degree(p)+mult_0(p)=2n` and `2 diskCount(p)+circleCount(p)=2n`, including dimension zero in this algebraic lemma. |
| C17 | `WeakComplement`, `SelectedCount`. | The complementary determinant has no strictly interior root under weak stability, with its value at zero treated separately. The exact factorization then proves the selected counts and transfers only the required unit-root simplicity. |
| C18 | `SteinIdentity`. | Correct adjoints and order of products in `H = S* H S`. |
| C19 | `UnregularizedFactorization`, `UnitPencilKernel`, `SimpleEigenfunctional`, `SimpleUnitPairing`. | An alternative to adjugate differentiation: a simple pencil root forces an invertible left factor and a simple characteristic root. Its nonzero left eigenfunctional cannot annihilate the right eigenvector. This proves the exact frozen pairing conclusion. |
| C20-C23 | `PairingVectors`, `GeneralizedStein`, `StableDimension`, `StableKernel`, `SteinRankLower`. | Arbitrary interior Jordan chains use full maximal generalized eigenspaces. The rank lower bound uses independent images with diagonal nonzero unit-root pairings; it permits an empty unit spectrum. |
| C24-C25 | `CanonicalRank`. | Stable-subspace dimension plus rank-nullity gives the upper bound; C19 and C23 give the lower bound. The stronger theorem does not require uniqueness; the canonical wrapper retains that hypothesis verbatim. |

Source-level consumption path for LeanCert is
`canonical_full_complex_rank -> full_complex_rank -> limiting_equation_and_spectra
-> complementary_stability -> regularized_root_count -> homotopy_boundary_nonvanishing
-> positive_average_and_sign -> certified_half`.
A final elaborated-body dependency diagnostic should independently check that
path rather than treating this author description as machine evidence.

Review the definitions and final theorem together: matrices and rank are the
standard Mathlib complex objects, roots are literal polynomial-root multisets,
simplicity is algebraic multiplicity one, and the limit is the right-sided
filter at zero. `GreenAssumptions` contains only the original model assumptions,
not any rank, root-selection, or count conclusion. The final theorem includes
singular `C,D`, simple roots at `+/-1`, `m=0`, and arbitrary interior Jordan
structure. The nonzero limiting determinant, polynomial regularity, and simple
unit roots remain explicit original assumptions. No limit-existence theorem
or classification beyond that target is claimed.

Two nonauthor final referees must assess the complete unchanged target and
actual import closure. Statement approval, an author source-text comparison,
local elaboration, local trust assertions, Linux Comparator execution, and
human peer review are different scopes; none should be reported as another.
