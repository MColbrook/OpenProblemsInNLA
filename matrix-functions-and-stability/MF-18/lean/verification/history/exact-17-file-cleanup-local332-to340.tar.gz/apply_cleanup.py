"""Apply the bounded, referee-requested MF18 source cleanup; never runs Lean."""
from pathlib import Path
import hashlib
import json
import shutil

B = Path('/private/tmp/nla-lean-next-20260915')
P = B / 'next-proofs/MF-18'
H = Path(__file__).parent

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

before = json.loads((H / 'BEFORE.json').read_text())
for rel in ['NLA/MF18/RootEnumeration.lean', 'NLA/MF18/StableDimension.lean']:
    target = H / 'before' / rel
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(P / rel, target)
    before['before_files'].append({'path': rel, 'sha256': sha(P / rel),
                                 'bytes': (P / rel).stat().st_size})
before['before_files'].sort(key=lambda x: x['path'])
(H / 'BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')

def replace(name, old, new):
    f = P / 'NLA/MF18' / (name + '.lean')
    text = f.read_text()
    assert text.count(old) == 1, (name, old, text.count(old))
    f.write_text(text.replace(old, new))

# Reuse the pinned Hermitian sum theorem, eliminating two inventoried `change`s.
replace('BoundaryNonvanishing', '''  have hstarinv : star (lam⁻¹) = lam := by rw [← hstar, star_star]
  have hcross : (lam • C.conjTranspose + lam⁻¹ • C).IsHermitian := by
    change (lam • C.conjTranspose + lam⁻¹ • C).conjTranspose = _
    rw [Matrix.conjTranspose_add, Matrix.conjTranspose_smul,
      Matrix.conjTranspose_smul, Matrix.conjTranspose_conjTranspose, hstar, hstarinv]
    exact add_comm _ _''', '''  have hcross : (lam • C.conjTranspose + lam⁻¹ • C).IsHermitian := by
    simpa only [Matrix.conjTranspose_smul, Matrix.conjTranspose_conjTranspose, hstar]
      using Matrix.isHermitian_add_transpose_self (lam • C.conjTranspose)''')
replace('UnitPencilKernel', '''  have hstarinv : star (lam⁻¹) = lam := by rw [← hstar, star_star]
  let F : Mat n := lam • C.conjTranspose + lam⁻¹ • C - R
  have hF : F.IsHermitian := by
    apply Matrix.IsHermitian.sub _ hR
    change (lam • C.conjTranspose + lam⁻¹ • C).conjTranspose = _
    rw [Matrix.conjTranspose_add, Matrix.conjTranspose_smul,
      Matrix.conjTranspose_smul, Matrix.conjTranspose_conjTranspose, hstar, hstarinv]
    exact add_comm _ _''', '''  let F : Mat n := lam • C.conjTranspose + lam⁻¹ • C - R
  have hF : F.IsHermitian := by
    apply Matrix.IsHermitian.sub _ hR
    simpa only [Matrix.conjTranspose_smul, Matrix.conjTranspose_conjTranspose, hstar]
      using Matrix.isHermitian_add_transpose_self (lam • C.conjTranspose)''')

# The common identities use only invertibility and the matrix equation.
generic_matrix = '''/-- Algebraic pencil factorization shared by the regularized and limiting equations. -/
theorem pencil_factorization {n : ℕ} (A B Q X : Mat n)
    (hX : X.det ≠ 0) (heq : X + B * X⁻¹ * A = Q) (lam : ℂ) :
    pencilValue A B Q lam =
      (lam • (B * X⁻¹) - 1) * X * (lam • (1 : Mat n) - X⁻¹ * A) := by
  have hu : IsUnit X.det := isUnit_iff_ne_zero.mpr hX
  have hleft : X⁻¹ * X = 1 := Matrix.nonsing_inv_mul X hu
  have hright : X * (X⁻¹ * A) = A := Matrix.mul_nonsing_inv_cancel_left X A hu
  unfold pencilValue
  rw [← heq]
  simp only [smul_add, smul_sub, sub_mul, mul_sub, smul_mul_assoc, mul_smul_comm,
    smul_smul, Matrix.mul_assoc, Matrix.mul_one, Matrix.one_mul, hleft, hright,
    pow_two]
  abel

'''
replace('PencilAlgebra', 'theorem solution_factorization', generic_matrix + 'theorem solution_factorization')
replace('PencilAlgebra', '''  have hu : IsUnit X.det := isUnit_iff_ne_zero.mpr h.1
  have hleft : X⁻¹ * X = 1 := Matrix.nonsing_inv_mul X hu
  have hright : X * (X⁻¹ * regularizedA C D η) = regularizedA C D η :=
    Matrix.mul_nonsing_inv_cancel_left X (regularizedA C D η) hu
  unfold pencilValue
  rw [← h.2.1]
  simp only [smul_add, smul_sub, sub_mul, mul_sub, smul_mul_assoc, mul_smul_comm,
    smul_smul, Matrix.mul_assoc, Matrix.mul_one, Matrix.one_mul, hleft, hright,
    pow_two]
  abel''', '''  exact pencil_factorization (regularizedA C D η) (regularizedB C D η)
    (regularizedQ R P η) X h.1 h.2.1 lam''')
replace('PencilAlgebra', '#print axioms solution_factorization',
        '#print axioms pencil_factorization\n#print axioms solution_factorization')
replace('UnregularizedFactorization', '''  have hu : IsUnit X.det := isUnit_iff_ne_zero.mpr hX
  have hleft : X⁻¹ * X = 1 := Matrix.nonsing_inv_mul X hu
  have hright : X * (X⁻¹ * C) = C := Matrix.mul_nonsing_inv_cancel_left X C hu
  unfold pencilValue
  rw [← heq]
  simp only [smul_add, smul_sub, sub_mul, mul_sub, smul_mul_assoc, mul_smul_comm,
    smul_smul, Matrix.mul_assoc, Matrix.mul_one, Matrix.one_mul, hleft, hright, pow_two]
  abel''', '''  exact pencil_factorization C C.conjTranspose R X hX heq z''')

generic_polynomial = '''/-- Taking determinants in the common pencil factorization preserves the full polynomial. -/
theorem pencil_polynomial_factorization {n : ℕ} (A B Q X : Mat n)
    (hX : X.det ≠ 0) (heq : X + B * X⁻¹ * A = Q) :
    scalarPencil A B Q =
      Polynomial.C X.det * (complementaryPolynomial B X * (X⁻¹ * A).charpoly) := by
  apply Polynomial.funext
  intro z
  rw [pencil_evaluation, pencil_factorization A B Q X hX heq z]
  simp only [Matrix.det_mul, Polynomial.eval_mul, Polynomial.eval_C,
    complementary_evaluation, eval_charpoly_smul]
  ring

'''
replace('SolutionPolynomial', 'theorem solution_polynomial_factorization',
        generic_polynomial + 'theorem solution_polynomial_factorization')
replace('SolutionPolynomial', '''  apply Polynomial.funext
  intro z
  rw [regularizedPolynomial, pencil_evaluation,
    solution_factorization C D R P η X h z]
  simp only [Matrix.det_mul, Polynomial.eval_mul, Polynomial.eval_C,
    complementary_evaluation, eval_charpoly_smul]
  ring''', '''  exact pencil_polynomial_factorization (regularizedA C D η) (regularizedB C D η)
    (regularizedQ R P η) X h.1 h.2.1''')
replace('SolutionPolynomial', '#print axioms solution_polynomial_factorization',
        '#print axioms pencil_polynomial_factorization\n#print axioms solution_polynomial_factorization')
replace('UnregularizedFactorization', '''  apply Polynomial.funext
  intro z
  rw [unregularizedPolynomial, pencil_evaluation, unregularized_factorization C R X hX heq z]
  simp only [Matrix.det_mul, Polynomial.eval_mul, Polynomial.eval_C,
    complementary_evaluation, eval_charpoly_smul]
  ring''', '''  exact pencil_polynomial_factorization C C.conjTranspose R X hX heq''')

# Additional second-referee reuse requests, independently read in pinned Mathlib.
replace('SteinIdentity', '''    have hleft (A : Mat n) : X₀ * (X₀⁻¹ * A) = A := by
      rw [← Matrix.mul_assoc, hxi, Matrix.one_mul]
''', '')
replace('SteinIdentity', 'simp only [Matrix.mul_assoc, hleft, hstarleft]',
        'simp only [Matrix.mul_assoc, Matrix.mul_nonsing_inv_cancel_left X₀ C hu, hstarleft]')
old_partition = '''  induction s using Multiset.induction_on with
  | empty => simp
  | @cons z s ih =>
    rcases lt_trichotomy ‖z‖ 1 with h | h | h
    · have hne : ‖z‖ ≠ 1 := ne_of_lt h
      have hnot : ¬1 < ‖z‖ := not_lt_of_ge h.le
      simp only [Multiset.filter_cons, h, hne, hnot, if_true, if_false,
        Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega
    · simp only [Multiset.filter_cons, h, lt_self_iff_false, if_false,
        if_true, Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega
    · have hne : ‖z‖ ≠ 1 := ne_of_gt h
      have hnot : ¬‖z‖ < 1 := not_lt_of_ge h.le
      simp only [Multiset.filter_cons, h, hne, hnot, if_true, if_false,
        Multiset.card_cons, Multiset.card_add, Multiset.card_singleton,
        Multiset.card_zero, zero_add, add_zero]
      omega'''
new_partition = '''  have hsplit := congrArg Multiset.card
    (Multiset.filter_add_not (fun z : ℂ => ‖z‖ < 1) s)
  have hrest := congrArg Multiset.card
    (Multiset.filter_add_not (fun z : ℂ => ‖z‖ = 1)
      (s.filter (fun z : ℂ => ¬‖z‖ < 1)))
  have hequal : (s.filter (fun z : ℂ => ¬‖z‖ < 1)).filter (fun z => ‖z‖ = 1) =
      s.filter (fun z => ‖z‖ = 1) := by
    rw [Multiset.filter_filter]
    apply Multiset.filter_congr
    intro z _
    exact ⟨And.left, fun h => ⟨h, not_lt_of_ge h.ge⟩⟩
  have hgreater : (s.filter (fun z : ℂ => ¬‖z‖ < 1)).filter (fun z => ¬‖z‖ = 1) =
      s.filter (fun z => 1 < ‖z‖) := by
    rw [Multiset.filter_filter]
    apply Multiset.filter_congr
    intro z _
    constructor
    · intro h
      exact lt_of_le_of_ne (le_of_not_gt h.2) (Ne.symm h.1)
    · intro h
      exact ⟨ne_of_gt h, not_lt_of_ge h.le⟩
  rw [Multiset.card_add] at hsplit hrest
  rw [hequal, hgreater] at hrest
  omega'''
replace('ReciprocalCount', old_partition, new_partition)
replace('RootEnumeration', '''theorem exists_fin_multiset_enumeration (s : Multiset ℂ) (N : ℕ) (hc : s.card = N) :
    ∃ r : Fin N → ℂ, Finset.univ.val.map r = s := by''', '''theorem exists_fin_multiset_enumeration {α : Type*} (s : Multiset α) (N : ℕ)
    (hc : s.card = N) : ∃ r : Fin N → α, Finset.univ.val.map r = s := by''')
replace('StableDimension', '''theorem independent_finset_sup_finrank {n : ℕ} {ι : Type*}
    (W : ι → Submodule ℂ (Vec n)) (hW : iSupIndep W) (s : Finset ι) :
    Module.finrank ℂ (s.sup W : Submodule ℂ (Vec n)) = ∑ i ∈ s, Module.finrank ℂ (W i) := by''', '''theorem independent_finset_sup_finrank {K : Type*} {V : Type*} {ι : Type*}
    [DivisionRing K] [AddCommGroup V] [Module K V] [FiniteDimensional K V]
    (W : ι → Submodule K V) (hW : iSupIndep W) (s : Finset ι) :
    Module.finrank K (s.sup W : Submodule K V) = ∑ i ∈ s, Module.finrank K (W i) := by''')

# Each comment names the particular reducible wrapper, coordinate coercion, or
# arithmetic normalization at that site. The two Hermitian sites were removed.
comments = [
('CanonicalRank', '      change (unregularizedPolynomial C R).eval lam = 0',
 '      -- Expose IsRoot as evaluation at lam being zero, so the polynomial factorization rewrites it.'),
('CayleyAlgebra', '  · change (Polynomial.C ((p.eval 1)⁻¹) * cayleyPolynomial N p).leadingCoeff = 1',
 '  · -- Unfold Monic and the normalized Cayley wrapper to their leading-coefficient equality.'),
('CayleyCount', '  change z ≠ (-1 : ℂ) at hz',
 '  -- Membership in the complement of {-1} is precisely the denominator exclusion z ≠ -1.'),
('CayleyCount', '  change (monicCayleyPolynomial N p).eval z = _',
 '  -- Expose membership in the set of evaluation-agreement points as the evaluation equality.'),
('PencilAlgebra', '  change (matrixPolynomial A B Q i j).eval lam = (pencilValue A B Q lam) i j',
 '  -- At entry (i,j), the mapped evaluation ring hom is ordinary polynomial evaluation.'),
('ReciprocalCount', '  change diskRootCount (unregularizedPolynomial C R) +',
 '  -- Name the interior and circle filtered cardinalities by the frozen root-count definitions.'),
('ReflectedRoots', '  change (Finset.univ.filter (fun i : Fin d => 1 < ‖r i‖)).card = _',
 '  -- A finset cardinal is the cardinal of its underlying multiset; expose the filtered index finset.'),
('ReflectedRoots', '    change q.eval 0 ≠ 0',
 '    -- The non-root premise unfolds to nonzero evaluation at zero, already computed by hqeval.'),
('ReflectedRoots', '  change p.reflect N = Polynomial.C p.leadingCoeff *',
 '  -- Fold only the local abbreviation q for the reciprocal-factor product in the factorization.'),
('ReflectedRoots', '    change diskRootCount (∏ i : Fin p.natDegree,',
 '    -- Expand q back to its finite product so diskRootCount_prod applies to its actual factors.'),
('ReflectionAlgebra', '    rw [show d * (s.card + 1) = d + d * s.card by ring,',
 '    -- Split the inserted product grade into d and d * s.card, the grades required by reflect_mul.'),
('ReflectionAlgebra', '  change M.det.reflect (d * n) = N.det',
 '  -- Name the entrywise-reflected matrix by N so det_apply receives an explicitly typed matrix.'),
('ReflectionAlgebra', '    simpa only [pow_one, show Polynomial.revAt 2 1 = 1 by decide] using',
 '    -- Reversing the degree-one monomial at fixed grade two leaves its exponent equal to one.'),
('ReflectionAlgebra', '    change (matrixPolynomial C C.conjTranspose R i j).reflect 2 =',
 '    -- Expose the (i,j) entry of the reflected matrix and the (j,i) entry of its coefficient conjugate.'),
('ReflectionAlgebra', '  change M.det.reflect (2 * n) = M.det.map (starRingEnd ℂ)',
 '  -- UnregularizedPolynomial is the determinant of the local polynomial matrix M on both sides.'),
('RegularizedCount', '    change ContinuousOn (fun t : ℝ => (t : ℂ) * regularizedA C D η i j) s',
 '    -- Evaluate the homotopy A matrix at (i,j); its complex scalar action is ordinary multiplication.'),
('RegularizedCount', '    change ContinuousOn (fun t : ℝ => (t : ℂ) * regularizedB C D η i j) s',
 '    -- Evaluate the homotopy B matrix at (i,j), retaining the explicit real-to-complex scalar cast.'),
('RegularizedCount', '    change ContinuousOn (fun t : ℝ => (t : ℂ) * R i j +',
 '    -- Evaluate the homotopy Q entry: t multiplies R, while the imaginary regularizer is constant.'),
('SimpleUnitPairing', '    change f (lam • w - (X₀⁻¹ * C).mulVec w) = 0 at hh',
 '    -- Fold the local linear functional f, whose value is pairing A v with its vector argument.'),
('SimpleUnitPairing', '      change f (A⁻¹.mulVec v) = 0',
 '      -- The pairing is exactly f evaluated at A⁻¹v, allowing the assumed zero linear map to rewrite.'),
('SimpleUnitPairing', '    change pairing (lam • C.conjTranspose - X₀) v v = _',
 '    -- Unfold the local functional f and its matrix A before expanding the sesquilinear pairing.'),
('SolutionPolynomial', '  change (Polynomial.evalRingHom z) M.det = _',
 '  -- Expose complementaryPolynomial as det M and polynomial evaluation as its ring homomorphism.'),
('SolutionPolynomial', '      change (Polynomial.C ((B * X⁻¹) i j) * Polynomial.X -',
 '      -- At (i,j), unfold M and matrix mapping into evaluation of the displayed linear polynomial.'),
('StableKernel', "  change (((S - lam • (1 : Mat n)) ^ k).toLin') v = 0",
 "  -- Matrix.toLin' applies by mulVec; expose the linear map so its algebra-hom power rules apply."),
('StableKernel', '  change H.mulVec v = 0',
 "  -- Membership in ker H.toLin' unfolds to the zero matrix-vector product required by separation."),
('StableKernel', '        change pairing H (w₁ + w₂) v = 0',
 '        -- Unfold membership in the declared carrier of W for the sum of its two vectors.'),
('StableKernel', '        change pairing H (a • w) v = 0',
 '        -- Unfold the same carrier for scalar closure; the conjugate scalar still multiplies zero.'),
('StableKernel', '    change pairing H w v = 0',
 '    -- Membership in W is the annihilating-pairing condition to prove on each generalized eigenspace.'),
('SteinIdentity', '  · change (hermitianImaginaryPart X₀).conjTranspose = hermitianImaginaryPart X₀',
 '  · -- IsHermitian is equality with conjugate transpose; expose it for the scalar-adjoint calculation.'),
]
records = []
for name, line, comment in comments:
    if line.startswith('  · '):
        new = comment + '\n    ' + line[len('  · '):]
    else:
        new = comment + '\n' + line
    replace(name, line, new)
    records.append({'file': 'NLA/MF18/' + name + '.lean', 'site': line.strip(),
                    'comment': comment.strip(), 'kind': 'locally explanatory comment'})
(H / 'COMMENTS.json').write_text(json.dumps({'count': len(records), 'sites': records},
                                           indent=2, ensure_ascii=False) + '\n')
print('Applied requested cleanup to 17 files; 29 local bridge comments; no compiler invoked.')
