# MF18 bounded cleanup after local332

This is an author-prepared source patch, not an independent review. The immutable local332 snapshot remains unchanged. Both independent referees approved mathematical/source meaning but requested the bounded changes below. Their exact manifests are bound in CHANGES.json.

- The unit-circle Hermitian sums in BoundaryNonvanishing and UnitPencilKernel now use Mathlib Matrix.isHermitian_add_transpose_self and the already-proved unit-circle scalar conjugation identity. This removes two undocumented change steps.
- PencilAlgebra proves one generic matrix factorization under precisely det X != 0 and X + B X^-1 A = Q. SolutionPolynomial derives its determinant polynomial factorization. Regularized and unregularized wrappers specialize these identities, so no stability premise is used at the limit. Existing wrapper headers are unchanged.
- SteinIdentity uses Matrix.mul_nonsing_inv_cancel_left directly at the cancellation site instead of reproving the local hleft.
- ReciprocalCount uses two Multiset.filter_add_not partitions, filter_filter/filter_congr, and cardinality additivity. The remaining predicate equivalence follows from linear-order inequalities; the old multiset induction is removed.
- The finite multiset enumeration helper is generalized to arbitrary element types; the independent finite-sup dimension helper is generalized to finite-dimensional modules over a division ring. Their existing proof bodies are byte-identical. Neither helper is a frozen contract.
- COMMENTS.json records 29 adjacent site-specific explanations. The pre-existing SelectedCount explanation is preserved. The two Hermitian changes are eliminated, accounting for all 31 requests and the complete 32-site baseline inventory.

There are 17 changed Lean files: eight contain only comments, two only helper signature generalizations, and seven contain the requested proof reuse (and applicable comments). All 25 selected headers and all three frozen files remain unchanged. There are exactly two new helper declarations. No imports, extra primitives, assumptions, numerical bounds, or target definitions were added or changed.

The retained Tau Ceti proof-quality and reuse rubrics were read. REUSE-SEARCHES.json records bounded searches and exact named Mathlib APIs; it does not claim a search of an unavailable full external TauCeti library. The two generic pencil helpers add reusable content beyond the standard determinant and inverse APIs.

Run `python3 verify_cleanup.py --candidate /path/to/MF-18` for a read-only source/inventory replay. It checks the sealed archive, original snapshot, exact before/after bytes, unaffected candidate files, unchanged imports, comment-only edits, the two helper generalizations, all prior/selected headers, comment coverage, and the exact unified diff. This script is not Lean, kernel checking, or Comparator. The cleanup still requires root-owned serial compilation, current body/type diagnostics as appropriate, and both independent successor reviews before acceptance.

No Git, shared-compiler file edit, Lean/Lake, Comparator, workflow, publication, or count change was performed by this author agent.
