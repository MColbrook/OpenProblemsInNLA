#!/usr/bin/env python3
"""Read-only source/inventory check. This does not invoke Lean or Comparator."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import re

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--candidate', type=Path,
                default=Path('/private/tmp/nla-lean-next-20260915/next-proofs/MF-18'))
args = ap.parse_args()
H = Path(__file__).resolve().parent
P = args.candidate.resolve()
checks = 0

def check(ok, what):
    global checks
    if not ok:
        raise AssertionError(what)
    checks += 1

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def headers(text):
    return {m.group(2): m.group(0) for m in re.finditer(
        r'^(?:(?:private|protected)\s+)?(theorem|lemma)\s+(\w+)\b[\s\S]*?:=',
        text, flags=re.M)}

def code(text):
    text = re.sub(r'/\-[\s\S]*?\-/', '', text)
    text = re.sub(r'--[^\n]*', '', text)
    return ' '.join(text.split())

manifest = json.loads((H / 'MANIFEST.json').read_text())
files = {x['path'] for x in manifest['files']}
actual = {str(p.relative_to(H)) for p in H.rglob('*')
          if p.is_file() and p.name != 'MANIFEST.json'}
check(actual == files, 'cleanup inventory')
for x in manifest['files']:
    f = H / x['path']
    check(f.stat().st_size == x['bytes'] and sha(f) == x['sha256'], x['path'])

before = json.loads((H / 'BEFORE.json').read_text())
changes = json.loads((H / 'CHANGES.json').read_text())
base_manifest = Path(before['baseline_manifest']['path'])
check(sha(base_manifest) == before['baseline_manifest']['sha256'], 'baseline manifest')
S = base_manifest.parent
base = json.loads(base_manifest.read_text())
for x in base['files']:
    f = S / x['path']
    check(f.stat().st_size == x['bytes'] and sha(f) == x['sha256'], 'baseline ' + x['path'])
for x in changes['review_manifests']:
    check(sha(Path(x['path'])) == x['sha256'], 'review manifest ' + x['path'])
for x in before['frozen_files']:
    check(sha(P / x['path']) == x['sha256'], 'frozen ' + x['path'])

changed = {x['path']: x for x in changes['changed_files']}
base_candidate = S / 'candidate'
base_paths = {str(p.relative_to(base_candidate)) for p in base_candidate.rglob('*') if p.is_file()}
for rel in sorted(base_paths):
    check((P / rel).exists(), 'candidate file ' + rel)
    if rel in changed:
        check(sha(H / 'before' / rel) == sha(base_candidate / rel), 'before ' + rel)
        check(sha(P / rel) == changed[rel]['after_sha256'] == sha(H / 'after' / rel),
              'after ' + rel)
    else:
        check(sha(P / rel) == sha(base_candidate / rel), 'unchanged ' + rel)

all_old = {}
all_new = {}
for f in sorted((base_candidate / 'NLA/MF18').glob('*.lean')):
    rel = f.relative_to(base_candidate)
    old = f.read_text()
    new = (P / rel).read_text()
    old_h, new_h = headers(old), headers(new)
    all_old.update(old_h)
    all_new.update(new_h)
    if str(rel) in changed:
        check(re.findall(r'^import .*$', old, re.M) == re.findall(r'^import .*$', new, re.M),
              'unchanged imports ' + str(rel))
        if changed[str(rel)]['kind'] == 'comments only':
            check(code(old) == code(new), 'comment-only tokens ' + str(rel))
        if changed[str(rel)]['kind'] == 'helper signature generalization only':
            reconstructed = new
            for name in changes['generalized_helper_names']:
                if name in new_h:
                    reconstructed = reconstructed.replace(new_h[name], old_h[name], 1)
            check(reconstructed == old, 'generalization-only ' + str(rel))
for name, header in all_old.items():
    if name not in changes['generalized_helper_names']:
        check(all_new.get(name) == header, 'unchanged existing header ' + name)
check(set(all_new) - set(all_old) == set(changes['new_helper_names']), 'new helper inventory')
selected = json.loads((P / 'comparator.json').read_text())['theorem_names']
for name in selected:
    short = name.rsplit('.', 1)[1]
    check(all_old[short] == all_new[short], 'selected literal header ' + name)

comments = json.loads((H / 'COMMENTS.json').read_text())
check(comments['count'] == len(comments['sites']) == 29, '29 local comments')
for site in comments['sites']:
    text = (P / site['file']).read_text()
    check(site['comment'] in text and site['site'].lstrip('· ') in text,
          'local comment ' + site['file'] + ': ' + site['site'])
diff = ''
for rel in sorted(changed):
    diff += ''.join(difflib.unified_diff(
        (H / 'before' / rel).read_text().splitlines(True),
        (P / rel).read_text().splitlines(True),
        fromfile='local332/' + rel, tofile='candidate/' + rel))
check(diff == (H / 'cleanup.diff').read_text(), 'exact unified diff')
print(json.dumps({'status': 'PASS', 'source_integrity_checks': checks,
                  'changed_files': len(changed), 'selected_literal_headers': len(selected),
                  'local_bridge_comments': comments['count'],
                  'execution_scope': 'Python source/integrity only; no Lean or Comparator'}))
