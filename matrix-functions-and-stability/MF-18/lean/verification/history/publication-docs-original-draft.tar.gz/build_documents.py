#!/usr/bin/env python3
"""Build the MF18 documentation draft only; never compile or mutate proof sources."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import shutil

B = Path('/private/tmp/nla-lean-next-20260915')
OUT = Path(__file__).resolve().parent
SNAP = B / 'MF18-local340-source-snapshot'
P = SNAP / 'candidate'
PREP = B / 'next-statements/MF18-full-20260918'
STD = B / 'MF05-canonical-package-local141'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def copy(src, dst):
    dest = OUT / dst
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
complete = read(B / 'MF18-LOCAL-COMPLETE-340.json')
diag = read(B / 'MF18-type-diagnostics-341/COMPARISON.json')
freeze = read(B / 'MF18-STATEMENT-FREEZE-local288.json')
assert sha(SNAP / 'MANIFEST.json') == '2fac074199230b44fbcb4b16d083f6e08067447200627f17f667fb9225c195ea'
assert sha(B / 'MF18-LOCAL-COMPLETE-340.json') == 'e756d376820b92a92ca1b1c9b61bb9b508779a2546f51d29e66e7856769b1df4'
assert sha(B / 'MF18-type-diagnostics-341/COMPARISON.json') == '6a1faf5e104e7f7a0c3bb66bbba92a72c7225145c823f46f37587b94bc443710'

for name in ['lakefile.toml', 'lake-manifest.json', 'lean-toolchain']:
    copy(P / name, name)
for name in ['README.md', 'solution.md']:
    copy(PREP / 'sources/upstream/matrix-functions-and-stability/MF-18' / name,
         'source-inputs/canonical/' + name)
copy(STD / 'sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json',
     'source-inputs/standards/v0.4.schema.json')

roles = [
    'Exact kernel-mode certificate 0 < 1/2 < 1; the positive half is used in matrix averaging.',
    'Equivalence of characteristic-root stability and the concrete spectral radius inequalities.',
    'Evaluation of the determinant polynomial equals the determinant of the matrix pencil.',
    'The scalar determinant pencil has degree at most 2n, without invertible leading coefficient.',
    'Circle positivity implies positivity of P and the sign needed for homotopy nonvanishing.',
    'The regularized homotopy pencil is nonzero at every unit-circle point.',
    'The fixed-grade Cayley transform has the required degree and transports root counts.',
    'Nonvanishing transfers from the circle to the half-plane boundary.',
    'A monic fixed-degree continuous polynomial homotopy preserves half-plane root count.',
    'The bounded-degree disk-count homotopy theorem, including changes of actual polynomial degree.',
    'The regularized determinant pencil has exactly n roots in the open disk.',
    'Ordered matrix and determinant factorization around a stabilizing solution.',
    'The complementary factor has no closed-disk roots for positive regularization.',
    'Limits of strict-stability matrices are weakly stable, by characteristic-root continuity.',
    'The limiting matrix equation holds and both limiting spectral factors are weakly stable.',
    'Reciprocal polynomial identity transports roots with their algebraic multiplicities.',
    'Selection count: the limiting stabilizing factor has m circle roots and n-m disk roots.',
    'The limiting matrix equation yields the exact Stein identity for the Hermitian imaginary part.',
    'A simple unit-circle root has a nonzero Hermitian pairing, without positive semidefiniteness.',
    'Stein pairings vanish on generalized eigenspaces when the eigenvalue product is not one.',
    'The stable generalized eigenspace dimension equals the disk root count with multiplicity.',
    'The whole stable generalized eigenspace lies in the imaginary-part kernel.',
    'The unit-circle pairings imply the complementary lower rank bound.',
    'Full complex rank equality from rank-nullity and both bounds; uniqueness is unnecessary here.',
    'The exact canonical theorem retains the original uniqueness premise and all original assumptions.'
]
contracts = []
challenge = (P / 'Challenge.lean').read_text()
for i, (name, role) in enumerate(zip(freeze['contract_names'], roles), 1):
    short = name.split('.')[-1]
    pat = re.compile(r'^theorem\s+' + re.escape(short) + r'\b[\s\S]*?(?=\s*:=\s*by)', re.M)
    frozen = pat.search(challenge)
    found = [(rel, pat.search((P / rel).read_text())) for rel in complete['sources']]
    found = [(rel, m) for rel, m in found if m]
    assert len(found) == 1 and frozen
    rel, m = found[0]
    assert m.group().rstrip() == frozen.group().rstrip()
    contracts.append({
        'contract': f'C{i:02}', 'declaration': name, 'file': rel,
        'line': (P / rel).read_text()[:m.start()].count('\n') + 1,
        'file_sha256': complete['sources'][rel],
        'frozen_header_sha256': hashlib.sha256(frozen.group().rstrip().encode()).hexdigest(),
        'header_hash_convention': 'UTF-8 from theorem keyword up to but excluding := by, trailing whitespace removed',
        'role': role, 'local_source_verification': 'development-340: passed',
        'local_type_verification': 'development-341: universes and binder-name-normalized elaborated types agree',
        'actual_axioms': complete['observed_axioms'][name], 'comparator_status': 'not-run',
        'literature_dependencies_assumed': []})
imports = {r: re.findall(r'^import\s+([^\s]+)', (P/r).read_text(), re.M) for r in complete['sources']}
authorship = {
    'mathematical_resolution_and_formalization_credit': 'George Stepaniants',
    'affiliation': 'Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA',
    'assistance': 'Substantial ChatGPT/Codex assistance',
    'principal_MF18_proof_and_cleanup_agent': '/root/mf06_final_referee2',
    'compiler_evidence_and_packaging_agent': '/root',
    'independent_nonauthor_proof_reviewers': ['/root/nm04_final_referee1', '/root/mi24_full_referee1'],
    'publication_documentation_agent': '/root/mi24_full_referee1',
    'role_separation': 'Both proof reviews were sealed before this documentation task. The documentation author did not author MF18 proof code. This draft is author-prepared metadata, not an independent review of its own metadata.'}
write('IMPLEMENTATION-MAP.json', {
    'scope': 'Author-prepared documentation and navigation; the independent reviews are separately sealed.',
    'canonical_target': 'Complete original complex MF-18 limiting Green-function imaginary-part rank equality',
    'freeze_record_sha256': sha(B/'MF18-STATEMENT-FREEZE-local288.json'),
    'snapshot_manifest_sha256': sha(SNAP/'MANIFEST.json'),
    'local_complete_record_sha256': sha(B/'MF18-LOCAL-COMPLETE-340.json'),
    'type_diagnostic_record_sha256': sha(B/'MF18-type-diagnostics-341/COMPARISON.json'),
    'contracts': contracts, 'proof_closure_sources': complete['sources'], 'imports': imports,
    'consumed_LeanCert_routes': diag['actual_elaborated_body_routes'], 'source_authorship': authorship})

review_specs = [
    ('statement-root', '/root', 'MF18-root-statements-local288', 'statement-first approval', 288),
    ('statement-nm04', '/root/nm04_final_referee1', 'MF18-statement-referee2-local288-20260918', 'statement-first approval', 288),
    ('proof-nm04-baseline', '/root/nm04_final_referee1', 'MF18-final-referee-nm04-local332', 'request_changes; mathematically approves; retained unchanged', 332),
    ('proof-referee2-baseline', '/root/mi24_full_referee1', 'MF18-final-referee2-local332', 'request_changes; mathematically approves; retained unchanged', 332),
    ('proof-nm04-successor', '/root/nm04_final_referee1', 'MF18-final-referee-nm04-local340', 'approve source scope; no open findings', 340),
    ('proof-referee2-successor', '/root/mi24_full_referee1', 'MF18-final-referee2-successor340', 'approve_source_scope_continuation; no remaining source findings', 340)]
review_rows = []
for ident, agent, folder, disposition, run in review_specs:
    path = B / 'reviews' / folder
    row = {'id': ident, 'agent': agent, 'source_run': run, 'disposition': disposition,
           'original_directory': str(path), 'package_directory': 'reviews/' + folder,
           'manifest_sha256': sha(path/'MANIFEST.json'), 'reviewer_is_MF18_proof_author': False,
           'review_kind': 'AI-agent review; not external human peer review or Tau Ceti service execution'}
    for f in ['VERDICT.json', 'REVIEW.md', 'CHECK.json']:
        if (path/f).exists(): row[f.replace('.', '_')+'_sha256'] = sha(path/f)
    if ident == 'proof-referee2-successor':
        receipt = B/'reviews/MF18-final-referee2-successor340-CHECK.json'
        row['readonly_execution_receipt'] = {'original_path': str(receipt), 'sha256': sha(receipt)}
    review_rows.append(row)
write('REVIEW-INDEX.json', {
    'scope': 'Source and statement reviews only. Standalone assembled package, current metadata and Linux acceptance require separate checks.',
    'standards_revision': 'afb424eda89e8ac96d9eb69f6a88972055a4cd1b',
    'statement_first_frozen_before_implementation': True,
    'both_final_proof_reviewers_are_nonauthors': True, 'current_source_review_status': 'approved',
    'current_source_snapshot_manifest_sha256': sha(SNAP/'MANIFEST.json'),
    'source_continuation': 'Full local332 closure read by each reviewer, plus independently inspected exact 17-file delta to local340; not a fresh full reread claim for the successor.',
    'reviews': review_rows, 'role_separation': authorship['role_separation'],
    'Linux_Comparator_status': 'not-run', 'count_increment': 0})

audit_path = B/'MI24-MF18-current-public-audit-v2-20260918/AUDIT.json'
pr_path = B/'MI24-MF18-PR-REFRESH-20260918.json'
audit = read(audit_path)
pr = read(pr_path)
pr_obs = next(r for r in pr['observations'] if r['target'] == 'MF-18')
prs = json.loads(pr_obs['stdout'])
write('PUBLIC-SCOPE.json', {
    'scope': 'Documentation of retained dated observations; this documentation task made no network query or independent semantic inspection of every tree or PR.',
    'tree_audit': {'original_path': str(audit_path), 'sha256': sha(audit_path),
        'observed_at_utc': audit['time'], 'scope': audit['scope'],
        'repository_count': audit['repository_count'], 'branch_head_count': audit['branch_head_count'],
        'unique_commit_count': audit['unique_commit_count'], 'fresh_tree_count': audit['fresh_tree_count'],
        'immutable_tree_reuse_count': sum(r['immutable_cache_reused'] for r in audit['observations']),
        'all_223_recorded_trees_complete': all(r['complete_tree'] for r in audit['observations']),
        'target_named_formalization_matches': audit['matches']},
    'upstream_PR_search': {'original_path': str(pr_path), 'sha256': sha(pr_path),
        'observed_at_utc': pr['time'], 'scope': pr['scope'], 'argv': pr_obs['argv'],
        'exit_code': pr_obs['exit_code'], 'result_count': len(prs), 'results': prs},
    'interpretation': 'The retained ID/path tree scan reports no target-named formalization path. The four MF-18-text PR results include the already merged complete mathematical solution #116, earlier auxiliary contribution #47, and other-topic results #283 and #110. No complete MF18 Lean formalization is identified by these records. This is bounded search evidence, not a universal novelty or priority claim.',
    'limitations': ['Public upstream and visible direct forks only; private, deleted, unpublished and differently named work may be absent.',
        'The PR search is exact problem-ID text, not a full semantic review of every PR body or diff.',
        'The observation timestamps are retained; no continuously current or newly executed search is claimed.']})

standard_rows = []
for row in read(STD/'STANDARD-BINDINGS.json')['standards']:
    u = row['upstream']
    standard_rows.append({'retained_original_path': str(STD/row['path']), 'sha256': row['sha256'],
        'repository': 'https://github.com/' + u['project'], 'revision': u['commit'],
        'url': f"https://github.com/{u['project']}/blob/{u['commit']}/{u['path']}",
        'use': 'Pinned guidance or metadata standard; reading it does not execute a review service or Comparator.'})
pattern_rows = []
for name, repo, rev in [
    ('Forsythe-Challenge.lean.txt', 'sgstepaniants/Forsythe', '8d1b0c0545a77b40245e84705aa7d273e6c81e62'),
    ('Forsythe-NUMERICAL_TARGETS.md', 'sgstepaniants/Forsythe', '8d1b0c0545a77b40245e84705aa7d273e6c81e62'),
    ('Schiffer-Challenge.lean.txt', 'jaumededios/Schiffer', '2938e277969c329caf154e48a3d8823f3635c7f1')]:
    src = PREP/'sources/patterns'/name
    pattern_rows.append({'retained_original_path': str(src), 'sha256': sha(src),
        'repository': 'https://github.com/'+repo, 'revision': rev,
        'use': 'Challenge separation and exact numerical-target documentation pattern; no mathematical theorem from this project is imported.'})
source_bindings = read(PREP/'SOURCE-BINDINGS.json')
mf05 = B/'next-statements/MI24-full-20260918/sources/reuse/NLA/MF05/Numerical.lean.txt'
assert sha(mf05) == '62c4363848f529e48d064c875d8897d55cb6959037af8df517c88287758e55ff'
pattern_rows.append({'retained_original_path': str(mf05), 'sha256': sha(mf05),
    'repository': 'https://github.com/sgstepaniants/OpenProblemsInNLA',
    'revision': '1b9f12661b90f40561e255293e11b2a08d79351e',
    'use': 'MF05 kernel-mode LeanCert idiom by George Stepaniants. That project credits its separate local-neighborhood argument to Matthew J. Colbrook. No MF05 theorem is a premise of MF18.'})
source_entries = [
    {'title': 'MF-18: complete complex Green-function imaginary-part rank proof',
     'authors': ['George Stepaniants'], 'id': 'https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/e7519c46fd249a6a033bfe5d11c66bf47f7f8885/matrix-functions-and-stability/MF-18/solution.md',
     'type': 'repository manuscript', 'location': 'Theorem 1 and Sections 1–4', 'relationship': 'formalizes',
     'author_endorsement': 'participated', 'note': 'Complete complex target. Developed with substantial ChatGPT/Codex assistance; independently reviewed by agents.'},
    {'title': 'Numerical solution of nonlinear matrix equations arising from Green’s function calculations in nano research',
     'authors': ['Chun-Hua Guo', 'Yueh-Cheng Kuo', 'Wen-Wei Lin'], 'id': 'https://doi.org/10.1016/j.cam.2012.05.012',
     'type': 'article', 'location': 'JCAM 236 (2012), 4166–4180; equation (1), Theorems 3 and 5, conjecture p. 4172',
     'relationship': 'background', 'author_endorsement': 'not-contacted',
     'note': 'Original problem and upper bound. Source reviewers inspected the relevant primary-source sections. No literature result is assumed as an axiom.'},
    {'title': 'On a nonlinear matrix equation arising in nano research',
     'authors': ['Chun-Hua Guo', 'Yueh-Cheng Kuo', 'Wen-Wei Lin'], 'id': 'https://doi.org/10.1137/100814706',
     'type': 'article', 'location': 'SIMAX 33 (2012), 235–262, Section 3', 'relationship': 'background',
     'author_endorsement': 'not-contacted', 'note': 'Earlier real-coefficient case; its restricted setting is not substituted for the canonical complex problem.'},
    {'title': 'MF-18 real-coefficient scalar-regularization auxiliary theorem',
     'authors': ['Matthew J. Colbrook'], 'id': 'https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/e7519c46fd249a6a033bfe5d11c66bf47f7f8885/references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-18.tex',
     'type': 'repository manuscript', 'location': 'Theorem 1, Corollary 3, Section 8',
     'relationship': 'background', 'author_endorsement': 'not-contacted',
     'note': 'Separate contribution including defective unit-circle behavior for real coefficients and scalar regularization. It is not a premise of this full complex proof and is not newly claimed here.'}]
write('SOURCE-ATTRIBUTION.json', {
    'canonical_revision': source_bindings['canonical_commit'],
    'canonical_path': 'matrix-functions-and-stability/MF-18/README.md',
    'canonical_inputs': {n: sha(OUT/'source-inputs/canonical'/n) for n in ['README.md', 'solution.md']},
    'authorship': authorship, 'mathematical_sources': source_entries,
    'additional_attribution': [
        {'name': 'Matthew J. Colbrook', 'affiliation': 'Department of Applied Mathematics and Theoretical Physics, University of Cambridge', 'scope': 'Earlier separate auxiliary theorem and MF05 local-neighborhood argument, as specified above.'},
        {'name': 'Yakov Pechersky', 'scope': 'Mathlib determinant-polynomial degree proof adaptation credited in NLA/MF18/PencilAlgebra.lean; preserve the source comment.'},
        {'name': 'Mathlib and LeanCert contributors', 'scope': 'Pinned libraries and existing APIs; code authorship remains with the respective sources.'}],
    'pins': {'lean': 'leanprover/lean4:v4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'leancert': '621a43d7cf21f87872392a01e874f2f1dbddc926'},
    'standards': standard_rows, 'patterns': pattern_rows,
    'checker_source_lock': {'retained_original_path': str(STD/'sources/standards/repository-checker-source-lock.json'),
        'sha256': sha(STD/'sources/standards/repository-checker-source-lock.json'),
        'repository': 'https://github.com/sgstepaniants/Forsythe', 'revision': '8d1b0c0545a77b40245e84705aa7d273e6c81e62',
        'file_count': 58, 'execution_status': 'Final Linux execution not-run; this is a source pin, not a success receipt.'},
    'reuse_audit_scope': 'Pinned Mathlib, LeanCert and available campaign sources; no exhaustive search of a separately pinned mathematical Tau Ceti repository is claimed.',
    'copyright_and_privacy': 'Retain canonical repository Markdown and bibliographic references. No bulk third-party paper PDF or extracted text is included; no email addresses are included.'})

lake_hashes = {n: sha(OUT/n) for n in ['lakefile.toml', 'lake-manifest.json', 'lean-toolchain']}
write('PACKAGING-CHANGES.json', {'scope': 'Documentation only; exact snapshot Lake files copied unchanged.',
    'changes': [], 'copied_configuration_sha256': lake_hashes,
    'proof_source_changes': 0, 'frozen_file_changes': 0, 'standalone_Lake_build_executed': False})
write('LAKE-CONFIGURATION.json', {'scope': 'Standalone pinned Lake configuration evidence, not standalone Lake build evidence.',
    'source_snapshot_manifest_sha256': sha(SNAP/'MANIFEST.json'), 'files_sha256': lake_hashes,
    'project_name': 'NLAMF18', 'default_targets': ['Solution'],
    'toolchain': (OUT/'lean-toolchain').read_text().strip(),
    'packages': [{'name': r['name'], 'url': r['url'], 'rev': r['rev']} for r in read(OUT/'lake-manifest.json')['packages']],
    'actual_campaign_build': 'Direct serial Lean compilation by root, --threads=1 --memory=4096; not a Lake build invocation.',
    'standalone_Lake_build_executed': False, 'Linux_Comparator_executed': False})

write('STATE.json', {
    'as_of_utc': now, 'problem': 'MF-18', 'canonical_status': 'Solved (existing mathematical resolution)',
    'complete_original_complex_target': True, 'proof_sources_locally_complete': True,
    'mathematical_resolutions_count_increment': 0, 'complete_Lean_verifications_count_increment': 0,
    'ready_to_publish_as_verified': False,
    'statement_freeze': {'run': 288, 'sha256': sha(B/'MF18-STATEMENT-FREEZE-local288.json'), 'contracts': 25, 'two_nonauthor_statement_reviews': True},
    'local_proof': {'run': 340, 'platform': 'macOS', 'success': True, 'closure_modules': 38, 'fresh_modules': 28,
        'source_matched_reused_modules': 10, 'contracts': 25, 'record_sha256': sha(B/'MF18-LOCAL-COMPLETE-340.json'),
        'scope': 'Actual root serial Lean commands and authenticated prior success origins; no reviewer compiler rerun.'},
    'local_type_diagnostics': {'run': 341, 'success': True, 'contracts': 25, 'binder_normalized_types_and_universes_match': True,
        'actual_proof_body_graph_nodes': 193, 'LeanCert_certificate_body_routes': 4,
        'record_sha256': sha(B/'MF18-type-diagnostics-341/COMPARISON.json'), 'Comparator_executed': False},
    'source_review': {'status': 'approved by both nonauthor AI-agent reviewers',
        'snapshot_manifest_sha256': sha(SNAP/'MANIFEST.json'),
        'successor_manifests': {r['agent']: r['manifest_sha256'] for r in review_rows if r['source_run'] == 340},
        'scope': 'Full baseline source read plus exact bounded successor delta; no publication acceptance.'},
    'documentation': {'status': 'author-prepared draft; run verify_documents.py for schema/integrity',
        'author_agent': '/root/mi24_full_referee1', 'independent_metadata_review': False,
        'configuration_changes': 0, 'standalone_full_package_assembled_here': False},
    'final_Linux_Comparator': {'status': 'not-run', 'run_id': None, 'publication_commit': None,
        'required_checks': ['real Comparator on all 25 contracts', 'default kernel verification', 'non-root sandbox', 'harness regression and rejection controls']},
    'remaining_gates': ['Root standalone assembly and integrity/privacy/metadata review', 'Actual final Linux run at the exact publication commit', 'Root acceptance and separate upstream PR'],
    'public_audit': {'tree_observation_utc': audit['time'], 'PR_search_observation_utc': pr['time'], 'record': 'PUBLIC-SCOPE.json', 'new_network_query_by_docs_task': False}})

formal = {
    'version': 'v0.4',
    'project': {'name': 'MF-18: full complex limiting Green-function rank equality',
        'description': 'For every complex matrix dimension n≥1 under the original positivity, unique stabilizing family, nonsingular right-limit, regular-pencil and simple-unit-root assumptions, the Hermitian imaginary-part rank equals half the unit-circle root count.',
        'authors': ['George Stepaniants'], 'responsible_maintainers': ['George Stepaniants'], 'license': 'Apache-2.0',
        'affiliation': authorship['affiliation'], 'contribution_note': 'Substantial ChatGPT/Codex assistance; detailed source, code, review and documentation roles are in SOURCE-ATTRIBUTION.json.'},
    'repository': {'role': 'substantive-development'}, 'sources': source_entries,
    'related_formalizations': [
        {'id': r['repository'] + '/tree/' + r['revision'], 'relationship': 'adapts', 'note': r['use']} for r in pattern_rows],
    'automation': {'methods': [{'method': 'agent', 'framework': 'OpenAI Codex',
        'tool_setup': 'Statement-first frozen Challenge/Definitions, pinned Mathlib and LeanCert; root alone ran one local Lean process with one thread and a 4096 MiB limit. Two other agents reviewed the proof without compiling.',
        'prompting_notes': 'Preserve the complete original target and exact source hashes; minimize numerical computation; use kernel-mode LeanCert; separate local compilation from final Linux Comparator.'}],
        'notes': 'Proof author, compiler, independent reviewers and documentation roles are recorded. No cost or runtime model-version estimate is invented. This docs task ran only Python and source reads.'},
    'status': {'scope': 'Complete MF18 original complex rank target; locally proved and independently agent source-reviewed. Standalone packaging and final Linux acceptance are pending.',
        'sorry_count': 0, 'sorry_in_definitions': 0, 'axioms': ['propext', 'Classical.choice', 'Quot.sound'],
        'main_results': [{'declaration': c['declaration'], 'file': c['file'], 'sorry_count': 0,
            'axioms': c['actual_axioms'], 'comparator_config': 'comparator.json', 'literature_dependencies': [],
            'source_sha256': c['file_sha256'], 'contract': c['contract'],
            'verification_status': 'Root local340 proof and local341 type/body diagnostics passed; both nonauthor source continuations approved; final Linux Comparator not-run.'} for c in contracts],
        'deliberate_challenge_placeholders': 25,
        'local_proof': {'run': 'development-340', 'record': 'verification/local340/LOCAL-COMPLETE.json',
            'record_sha256': sha(B/'MF18-LOCAL-COMPLETE-340.json'), 'modules': 38, 'fresh_modules': 28,
            'source_matched_reused_modules': 10, 'contracts': 25, 'platform': 'macOS',
            'compiler_owner': '/root; one process, --threads=1 --memory=4096', 'success': True,
            'source_sha256': complete['sources'],
            'execution_lineage': 'The original completion record binds 38 successful source origins, command lines, logs, dependencies and reuse chains. Documentation and independent reviewers did not rerun Lean.'},
        'local_type_diagnostic': {'run': 'development-341', 'record': 'verification/type-diagnostics-341/COMPARISON.json',
            'record_sha256': sha(B/'MF18-type-diagnostics-341/COMPARISON.json'), 'matched_contracts': 25,
            'binder_normalized_types_and_universes_match': True, 'LeanCert_certificate_consumed': True,
            'Comparator_executed': False, 'scope': 'Separate actual elaboration of frozen Challenge and Solution; binder names erased only. Actual proof bodies reach the frozen certificate and checked LeanCert declarations.'},
        'final_Linux_status': 'not-run'},
    'fidelity': {'divergences': 'No weakening of the original target. Fin n with NeZero n models arbitrary n≥1 over ℂ. Root counts are multiset counts with algebraic multiplicity; C02 proves spectral-radius semantics. The canonical export retains uniqueness, although C24 proves the stronger result without it. Fixed-grade Cayley root-count homotopy, algebraic simple-root pairings and generalized Stein pairings replace informal analytic steps with proved lemmas. No invertibility of C or D, positivity of the limiting imaginary part, or interior semisimplicity is assumed. Limit existence and nonsingularity, regularity, and simple unit roots remain original assumptions. Historical preproof comments in frozen files are preserved byte-for-byte; current status is in STATE.json.'},
    'review': {'status': 'agent-reviewed (complete source scope; final publication checks pending)',
        'reviewers': ['/root/nm04_final_referee1 — independent nonauthor proof reviewer', '/root/mi24_full_referee1 — independent nonauthor proof reviewer'],
        'notes': 'Both full local332 baseline reviews requested bounded quality/reuse improvements. Both independently approved the exact local340 continuation after the 17-file cleanup and actual local340/341 evidence. The historical request-changes packets remain immutable. Two earlier nonauthor statement approvals preceded implementation. These are AI-agent reviews under pinned Tau Ceti guidance, not official Tau Ceti service execution or external human peer review. The second source reviewer subsequently prepared these docs; that is a separate role and not independent metadata review. See REVIEW-INDEX.json.'},
    'alignment': {'canonical_problem': 'MF-18', 'canonical_revision': source_bindings['canonical_commit'],
        'canonical_path': 'matrix-functions-and-stability/MF-18/README.md', 'contracts': 'IMPLEMENTATION-MAP.json',
        'frozen_statement': 'STATEMENT-FREEZE.json', 'numerical_targets': 'NUMERICAL_TARGETS.md',
        'formal_assumptions': 'NLA.MF18.GreenAssumptions', 'formal_proof': 'NLA.MF18.canonical_full_complex_rank',
        'stronger_proof_without_uniqueness': 'NLA.MF18.full_complex_rank', 'comparator': 'comparator.json',
        'extra_substantive_hypotheses': False},
    'acknowledgements': 'George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology. Preserve Guo–Kuo–Lin’s original problem and earlier results, Matthew J. Colbrook’s separate auxiliary theorem, and Mathlib/LeanCert code authorship including the credited Yakov Pechersky determinant-degree argument. Schiffer, Forsythe and MF05 are workflow/code-pattern sources as specified in SOURCE-ATTRIBUTION.json.'}
write('formalization.yaml', formal)  # JSON syntax is valid YAML 1.2.

external = {}
def bind(path):
    path = Path(path)
    external[str(path)] = sha(path)
for name in ['MF18-LOCAL-COMPLETE-340.json', 'MF18-STATEMENT-FREEZE-local288.json',
    'MF18-local340-source-snapshot/MANIFEST.json', 'MF18-type-diagnostics-341/COMPARISON.json',
    'MF18-type-diagnostics-341/challenge-types.json', 'MF18-type-diagnostics-341/solution-types.json',
    'MF18-type-diagnostics-341/certificate-body-route.json', 'MF18-source-history/referee-cleanup-local332/MANIFEST.json',
    'MF18-source-history/referee-cleanup-local332/CHANGES.json',
    'MI24-MF18-current-public-audit-v2-20260918/AUDIT.json',
    'MI24-MF18-current-public-audit-v2-20260918/REPOSITORIES.json',
    'MI24-MF18-current-public-audit-v2-20260918/FRESH-BRANCH-HEADS.json',
    'MI24-MF18-PR-REFRESH-20260918.json', 'next-statements/MF18-full-20260918/SOURCE-BINDINGS.json']:
    bind(B/name)
for row in review_rows:
    path = Path(row['original_directory'])
    bind(path/'MANIFEST.json')
    if 'readonly_execution_receipt' in row: bind(row['readonly_execution_receipt']['original_path'])
for row in standard_rows + pattern_rows: bind(row['retained_original_path'])
bind(STD/'sources/standards/repository-checker-source-lock.json')
for name in ['README.md', 'solution.md']:
    bind(PREP/'sources/upstream/matrix-functions-and-stability/MF-18'/name)
bind(complete['receipt']); bind(complete['assembly']); bind(diag['receipt'])
bind('/private/tmp/nla-lean-local-shared-20260916/ASSEMBLY-341.json')
write('DOCUMENT-SCOPE.json', {'created_at_utc': now, 'author_agent': '/root/mi24_full_referee1',
    'task': 'MF18 publication documentation and metadata only', 'not_independent_metadata_review': True,
    'Lean_Lake_Comparator_executions_by_this_task': 0, 'Git_or_network_mutations_by_this_task': 0,
    'network_queries_by_this_task': 0, 'only_write_payload_directory': str(OUT),
    'source_snapshot': str(SNAP), 'expected_current_proof_sources': complete['sources'],
    'expected_frozen_files': freeze['frozen_files'], 'external_inputs_sha256': external,
    'read_scope': 'Current canonical README and solution, Definitions, selected source semantics, complete current review reports/verdicts, diagnostic and completion records, dated audit summaries/PR rows, configuration, schema, pinned pattern files. Full mathematical source read was performed and separately sealed in the earlier proof review; this is not a new full-source review.',
    'checker_receipt_location': '../MF18-publication-docs-draft-CHECK.json',
    'checker_receipt_outside_manifest_reason': 'Avoid self-hash cycles; the receipt binds the sealed payload manifest and checker hash.',
    'source_license_note': 'No third-party primary PDF or bulk extracted paper text copied.'})
write('INTEGRATION-REQUIREMENTS.json', {
    'scope': 'Root integrates this docs draft with unchanged reviewed sources and evidence. This directory is not the full standalone proof package.',
    'canonical_publication_directory': 'matrix-functions-and-stability/MF-18/lean',
    'source_snapshot': str(SNAP), 'source_snapshot_manifest_sha256': sha(SNAP/'MANIFEST.json'),
    'preserve_all_38_proof_sources_and_three_frozen_files': True,
    'docs_to_copy': ['README.md', 'formalization.yaml', 'IMPLEMENTATION-MAP.json', 'PROOF-REVIEWER-MAP.md',
        'NUMERICAL_TARGETS.md', 'REVIEW-INDEX.md', 'REVIEW-INDEX.json', 'SOURCE-ATTRIBUTION.json',
        'STATE.json', 'PUBLIC-SCOPE.json', 'LAKE-CONFIGURATION.json', 'PACKAGING-CHANGES.json',
        'lakefile.toml', 'lake-manifest.json', 'lean-toolchain', 'source-inputs'],
    'evidence_destinations': [
        {'original': str(B/'MF18-STATEMENT-FREEZE-local288.json'), 'destination': 'STATEMENT-FREEZE.json'},
        {'original': str(B/'MF18-LOCAL-COMPLETE-340.json'), 'destination': 'verification/local340/LOCAL-COMPLETE.json'},
        {'original': str(B/'MF18-type-diagnostics-341'), 'destination': 'verification/type-diagnostics-341'},
        *[{'original': r['original_directory'], 'destination': r['package_directory']} for r in review_rows],
        {'original': str(B/'reviews/MF18-final-referee2-successor340-CHECK.json'), 'destination': 'reviews/MF18-final-referee2-successor340-CHECK.json'},
        {'original': str(B/'MF18-source-history/referee-cleanup-local332'), 'destination': 'verification/source-cleanup-local332'},
        {'original': str(audit_path), 'destination': 'verification/public-scope/AUDIT.json'},
        {'original': str(pr_path), 'destination': 'verification/public-scope/PR-REFRESH.json'}],
    'retain_exact_execution_lineage': 'Copy the original source-matched origin receipts, assembly records, argv and logs named by local340 completion, plus local341 diagnostics and statement288 evidence. Preserve original hashes and local paths as historical metadata; any portable relocation map must authenticate corresponding bytes. Do not silently edit sealed reviews to rewrite their paths.',
    'no_bulk_inputs': ['third-party primary PDFs or extracted full text', 'dependency caches', 'compiled .olean or native objects', 'bulk recursive Git/API dumps'],
    'configuration_change_required': False,
    'pending_checks': ['Final standalone file/import/hash closure and no-email/privacy check',
        'Schema validation of the integrated metadata', 'Independent metadata/package review',
        'Actual non-root Linux Comparator, default kernel, sandbox and rejection/regression controls at the exact publication commit'],
    'count_change_authorized_by_this_draft': 0,
    'post_Linux_metadata': 'Only the coordinator may append actual Linux run ID, tested commit and outcome after execution; do not convert not-run to success in advance.'})
print(json.dumps({'status': 'DRAFT_DATA_WRITTEN', 'directory': str(OUT), 'contracts': len(contracts), 'sources': len(complete['sources']), 'proof_edits': 0, 'Lean_runs': 0}, indent=2))
