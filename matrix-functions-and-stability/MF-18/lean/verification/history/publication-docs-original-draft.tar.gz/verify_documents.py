#!/usr/bin/env python3
"""Read-only draft/schema/evidence authentication. No compiler, subprocess or network."""
from pathlib import Path
import hashlib
import json
import re
import sys
try:
    import tomllib
except ModuleNotFoundError:  # The retained local Python is 3.10.
    import tomli as tomllib

import jsonschema

D = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
L = Path('/private/tmp/nla-lean-local-shared-20260916')
S = B / 'MF18-local340-source-snapshot'
P = S / 'candidate'
checks = 0

def require(condition, description):
    global checks
    checks += 1
    if not condition:
        raise AssertionError(description)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def obj(path):
    return json.loads(Path(path).read_text())

def bound(path, expected):
    require(Path(path).is_file(), f'missing {path}')
    require(sha(path) == expected, f'hash mismatch {path}')

def manifest(path, exact=False):
    data = obj(path)
    rows = data['files']
    if isinstance(rows, dict):
        rows = [{'path': k, 'sha256': v} for k, v in rows.items()]
    base = Path(path).parent
    names = []
    for row in rows:
        name = row['path']
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'relative safe manifest path')
        names.append(name)
        bound(base / name, row['sha256'])
        if 'bytes' in row:
            require((base/name).stat().st_size == row['bytes'], f'bytes: {name}')
    require(len(names) == len(set(names)), 'no duplicate manifest paths')
    if exact:
        actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
        require(actual == set(names), f'exact manifest payload at {base}')
    return len(names)

payloads = manifest(D/'MANIFEST.json', exact=True)
scope = obj(D/'DOCUMENT-SCOPE.json')
for path, digest in scope['external_inputs_sha256'].items():
    bound(path, digest)
require(scope['Lean_Lake_Comparator_executions_by_this_task'] == 0, 'docs did not compile')
require(scope['Git_or_network_mutations_by_this_task'] == 0, 'docs did not publish')
require(scope['network_queries_by_this_task'] == 0, 'retained audit, no new query')
snapshot_payloads = manifest(S/'MANIFEST.json', exact=True)
require(snapshot_payloads == 49, 'exact source snapshot count')

schema = obj(D/'source-inputs/standards/v0.4.schema.json')
bound(D/'source-inputs/standards/v0.4.schema.json', '25ff6b25ca4511635aff4443cf20480c15e59dddf19591c730950b442ea54fce')
formal = obj(D/'formalization.yaml')  # JSON is a YAML 1.2 subset.
jsonschema.validators.validator_for(schema).check_schema(schema)
jsonschema.validate(formal, schema)
require(formal['version'] == 'v0.4', 'schema version')
require(formal['project']['license'] == 'Apache-2.0', 'license')
require(formal['project']['authors'] == ['George Stepaniants'], 'authorship')
require('Department of Computing and Mathematical Sciences' in formal['project']['affiliation'], 'department credit')
require('California Institute of Technology' in formal['project']['affiliation'], 'Caltech credit')

complete = obj(B/'MF18-LOCAL-COMPLETE-340.json')
freeze = obj(B/'MF18-STATEMENT-FREEZE-local288.json')
mapping = obj(D/'IMPLEMENTATION-MAP.json')
config = obj(P/'comparator.json')
require(len(complete['sources']) == 38, '38 modules')
require(mapping['proof_closure_sources'] == complete['sources'] == scope['expected_current_proof_sources'], 'closure maps agree')
require(config['theorem_names'] == freeze['contract_names'], 'exact frozen configured names')
require(len(freeze['contract_names']) == 25 and len(mapping['contracts']) == 25, '25 contracts')
require(config['definition_names'] == [], 'no substituted definition contract')
standard_axioms = {'propext', 'Classical.choice', 'Quot.sound'}
require(set(config['permitted_axioms']) == standard_axioms, 'only standard axioms allowed')
for name, digest in complete['sources'].items():
    bound(P/name, digest)
    imports = re.findall(r'^import\s+([^\s]+)', (P/name).read_text(), re.M)
    require(imports == mapping['imports'][name], f'import map {name}')
    require('Challenge' not in imports, f'proof does not import Challenge: {name}')
    for module in imports:
        if module.startswith('NLA.MF18.'):
            imported = module.replace('.', '/') + '.lean'
            require(imported in complete['sources'], f'closed local imports: {module}')
for name, digest in freeze['frozen_files'].items():
    bound(P/name, digest)
require(scope['expected_frozen_files'] == freeze['frozen_files'], 'frozen map matches')
require(freeze['proof_implementation_started_before_gate'] is False, 'statement first')
require(formal['status']['sorry_count'] == formal['status']['sorry_in_definitions'] == 0, 'proof status')
require(formal['status']['deliberate_challenge_placeholders'] == 25, 'statement placeholders distinguished')
challenge = (P/'Challenge.lean').read_text()
require(len(re.findall(r'^\s*sorry\s*$', challenge, re.M)) == 25, 'exact intentional challenge placeholders')
solution = (P/'Solution.lean').read_text()
kernel_names = re.findall(r'^#assert_trust\s+kernel\s+(\S+)', solution, re.M)
require(len(kernel_names) == 25, '25 final kernel requests')
require(set(kernel_names) == {n.split('.')[-1] for n in freeze['contract_names']} or set(kernel_names) == set(freeze['contract_names']), 'kernel requests cover exact exports')
for i, row in enumerate(mapping['contracts']):
    name = freeze['contract_names'][i]
    require(row['contract'] == f'C{i+1:02}' and row['declaration'] == name, 'contract order')
    pat = re.compile(r'^theorem\s+' + re.escape(name.split('.')[-1]) + r'\b[\s\S]*?(?=\s*:=\s*by)', re.M)
    ch = pat.search(challenge)
    text = (P/row['file']).read_text()
    proof = pat.search(text)
    require(ch is not None and proof is not None, f'headers exist: {name}')
    require(ch.group().rstrip() == proof.group().rstrip(), f'frozen header: {name}')
    require(hashlib.sha256(ch.group().rstrip().encode()).hexdigest() == row['frozen_header_sha256'], 'header digest')
    require(text[:proof.start()].count('\n')+1 == row['line'], 'exact header line')
    require(complete['sources'][row['file']] == row['file_sha256'], 'source hash link')
    require(set(row['actual_axioms']) == standard_axioms and row['actual_axioms'] == complete['observed_axioms'][name], 'actual axioms')
    f = formal['status']['main_results'][i]
    require(f['declaration'] == name and f['file'] == row['file'] and f['source_sha256'] == row['file_sha256'], 'formal metadata declaration link')
    require(f['literature_dependencies'] == [] and row['literature_dependencies_assumed'] == [], 'no literature axioms')
    require(row['comparator_status'] == 'not-run', 'no Comparator claim')

# Authenticate original root evidence rather than treating a summary as a new execution.
receipts = {}
for path, digest in complete['retained_original_evidence'].items():
    bound(path, digest)
    if path.endswith('/RECEIPT.json'):
        rec = obj(path)
        receipts[path] = rec
        run = Path(path).parent.name.split('-')[-1]
        bound(L/f'ASSEMBLY-{run}.json', rec['assembly_sha256'])
receipt340 = obj(complete['receipt'])
bound(complete['receipt'], complete['receipt_sha256'])
bound(complete['assembly'], complete['assembly_sha256'])
require(receipt340['completed_modules'] == 38 and receipt340['failed_modules'] == [] and receipt340['blocked_modules'] == [], 'root complete run340')
require(receipt340['threads'] == receipt340['max_compiler_processes'] == 1 and receipt340['memory_cap_mib'] == 4096, 'serial resource limits')
require(receipt340['platform'] == 'darwin', 'actual platform')
fresh = [c for c in receipt340['commands'] if 'argv' in c]
require(len(fresh) == 28, '28 actual fresh root commands')
require(len(receipt340['commands']) == 38, '38 source closure records')
require(len(complete['commands_and_successful_origins']) == 38, 'all source origins')
for origin in complete['commands_and_successful_origins']:
    command = origin['command']
    require(command['exit_code'] == 0, 'successful source origin')
    require(command['source_sha256'] == origin['source_sha256'] == complete['sources'][origin['canonical_source_path']], 'origin exact source')
    require(command in obj(origin['success_origin_receipt'])['commands'], 'command exists in bound original receipt')
    bound(origin['success_origin_receipt'], origin['receipt_sha256'])
    log = Path(origin['success_origin_receipt']).parent / (origin['module'] + '.log')
    bound(log, command['log_sha256'])
    require('--threads=1' in command['argv'] and '--memory=4096' in command['argv'], 'origin serial limits')
    for hop in origin['reuse_chain']:
        bound(hop['receipt'], hop['sha256'])
origin_c01 = next(r for r in complete['commands_and_successful_origins'] if r['module'] == 'NLA.MF18.Numerical')
require(Path(origin_c01['success_origin_receipt']).parent.name == 'development-295', 'C01 actual first successful origin')
origin_solution = next(r for r in complete['commands_and_successful_origins'] if r['canonical_source_path'] == 'Solution.lean')
log_text = (Path(origin_solution['success_origin_receipt']).parent/'NLA.MF18.Solution.log').read_text()
for name in freeze['contract_names']:
    report = re.search(re.escape(name) + r"'? depends on axioms: \[([^\]]+)\]", log_text)
    require(report is not None, f'logged axiom report {name}')
    require(set(x.strip() for x in report.group(1).split(',')) == standard_axioms, 'logged permitted axioms')

diag_dir = B/'MF18-type-diagnostics-341'
comparison = obj(diag_dir/'COMPARISON.json')
bound(comparison['receipt'], comparison['receipt_sha256'])
receipt341 = obj(comparison['receipt'])
require(receipt341['completed_modules'] == 40 and not receipt341['failed_modules'] and not receipt341['blocked_modules'], 'actual root diagnostic341 success')
for command in comparison['diagnostic_commands']:
    require(command in receipt341['commands'] and command['exit_code'] == 0, 'actual successful diagnostic command')
    bound(diag_dir/'sources'/command['argv'][-1], command['source_sha256'])
    bound(Path(comparison['receipt']).parent/(command['module']+'.log'), command['log_sha256'])
require(len(comparison['diagnostic_commands']) == 2, 'two separately elaborated diagnostic modules')
bound(diag_dir/'challenge-types.json', comparison['challenge_dump_sha256'])
bound(diag_dir/'solution-types.json', comparison['solution_dump_sha256'])
bound(diag_dir/'certificate-body-route.json', comparison['body_graph_sha256'])
ct = {r['name']: r for r in obj(diag_dir/'challenge-types.json')}
st = {r['name']: r for r in obj(diag_dir/'solution-types.json')}
require(set(ct) == set(st) == set(freeze['contract_names']), 'exact elaborated names')
for name in ct:
    require(ct[name]['binderNormalizedType'] == st[name]['binderNormalizedType'], f'elaborated normalized type {name}')
    require(ct[name]['levelParams'] == st[name]['levelParams'], f'universes {name}')
graph = {r['name']: r for r in obj(diag_dir/'certificate-body-route.json')}
require(len(graph) == comparison['body_graph_nodes'] == 193, '193 actual proof-body nodes')
routes = comparison['actual_elaborated_body_routes']
require(mapping['consumed_LeanCert_routes'] == routes, 'docs exact body paths')
require(len(routes) == 4, 'four certificate paths')
for route in routes.values():
    require(route[0] == 'NLA.MF18.canonical_full_complex_rank', 'canonical path root')
    for start, end in zip(route, route[1:]):
        require(graph[start]['hasBody'] and end in graph[start]['bodyConstants'], 'actual proof-body edge')
require(routes['final_to_frozen_certificate'][-1] == 'NLA.MF18.certified_half', 'C01 consumed')
require(routes['final_to_kernel_checked_bound'][-1] == 'LeanCert.Validity.verify_strict_upper_bound_dyadic_checked', 'checked certificate endpoint')
require(comparison['Comparator_executed'] is False, 'type diagnostic not Comparator')

reviews = obj(D/'REVIEW-INDEX.json')
require(len(reviews['reviews']) == 6, 'six review stages')
for row in reviews['reviews']:
    base = Path(row['original_directory'])
    bound(base/'MANIFEST.json', row['manifest_sha256'])
    manifest(base/'MANIFEST.json')
    require(row['reviewer_is_MF18_proof_author'] is False, 'nonauthor source reviewers')
    for name in ['VERDICT.json', 'REVIEW.md', 'CHECK.json']:
        key = name.replace('.', '_') + '_sha256'
        if key in row: bound(base/name, row[key])
    if row['id'] == 'proof-nm04-successor':
        v = obj(base/'VERDICT.json')
        require(v['overall'] == 'approve' and not v['open_findings'] and v['reviewer_Lean_runs'] == v['reviewer_Comparator_runs'] == 0, 'nm04 approved source scope')
        ck = obj(base/'CHECK.json')
        require(ck['status'] == 'PASS' and ck['exit_code'] == 0 and ck['checks'] == 3062, 'nm04 actual read-only check receipt')
    if row['id'] == 'proof-referee2-successor':
        v = obj(base/'VERDICT.json')
        require(v['overall'] == 'approve_source_scope_continuation' and not v['remaining_source_findings'] and not v['publication_approval'], 'referee2 approved source scope')
        ck = obj(row['readonly_execution_receipt']['original_path'])
        bound(row['readonly_execution_receipt']['original_path'], row['readonly_execution_receipt']['sha256'])
        require(ck['exit_code'] == 0 and ck['review_manifest_sha256'] == row['manifest_sha256'], 'referee2 actual read-only execution')
        stdout = json.loads(ck['stdout'])
        require(stdout['status'] == 'PASS_READ_ONLY_INTEGRITY', 'retained checker stdout PASS')
require(reviews['current_source_snapshot_manifest_sha256'] == sha(S/'MANIFEST.json'), 'current reviewed snapshot')

attribution = obj(D/'SOURCE-ATTRIBUTION.json')
require(attribution['authorship']['publication_documentation_agent'] == '/root/mi24_full_referee1', 'separate docs role')
require(len(attribution['mathematical_sources']) == 4, 'full source attribution')
require(any(r['authors'] == ['Matthew J. Colbrook'] for r in attribution['mathematical_sources']), 'auxiliary authorship')
for row in attribution['standards'] + attribution['patterns']:
    bound(row['retained_original_path'], row['sha256'])
lock = attribution['checker_source_lock']
bound(lock['retained_original_path'], lock['sha256'])
lock_data = obj(lock['retained_original_path'])
require(len(lock_data['files']) == lock['file_count'] == 58, 'checker source lock file count')
require(lock_data['commit'] == lock['revision'] == '8d1b0c0545a77b40245e84705aa7d273e6c81e62', 'Forsythe checker pin')
for name, digest in attribution['canonical_inputs'].items():
    bound(D/'source-inputs/canonical'/name, digest)
    bound(B/'next-statements/MF18-full-20260918/sources/upstream/matrix-functions-and-stability/MF-18'/name, digest)
require(attribution['canonical_revision'] == 'e7519c46fd249a6a033bfe5d11c66bf47f7f8885', 'retained canonical revision')

lake = obj(D/'LAKE-CONFIGURATION.json')
for name, digest in lake['files_sha256'].items():
    bound(D/name, digest)
    bound(P/name, digest)
config_lake = tomllib.loads((D/'lakefile.toml').read_text())
manifest_lake = obj(D/'lake-manifest.json')
require(config_lake['name'] == manifest_lake['name'] == lake['project_name'] == 'NLAMF18', 'correct standalone name')
require(config_lake['defaultTargets'] == lake['default_targets'] == ['Solution'], 'correct default target')
require((D/'lean-toolchain').read_text().strip() == lake['toolchain'] == attribution['pins']['lean'], 'toolchain')
packages = {r['name']: r for r in manifest_lake['packages']}
require(packages['leancert']['rev'] == attribution['pins']['leancert'] and packages['mathlib']['rev'] == attribution['pins']['mathlib'], 'library pins')
require(lake['packages'] == [{'name': r['name'], 'url': r['url'], 'rev': r['rev']} for r in manifest_lake['packages']], 'all transitive pins recorded')
packaging = obj(D/'PACKAGING-CHANGES.json')
require(packaging['changes'] == [] and packaging['proof_source_changes'] == packaging['frozen_file_changes'] == 0, 'no configuration or proof change')
require(not lake['standalone_Lake_build_executed'] and not lake['Linux_Comparator_executed'], 'config evidence scope')

public = obj(D/'PUBLIC-SCOPE.json')
ta = public['tree_audit']
bound(ta['original_path'], ta['sha256'])
audit = obj(ta['original_path'])
for key in ['repository_count', 'branch_head_count', 'unique_commit_count', 'fresh_tree_count']:
    require(ta[key] == audit[key], f'audit count {key}')
require((ta['repository_count'], ta['branch_head_count'], ta['unique_commit_count'], ta['fresh_tree_count']) == (15,269,223,3), 'dated bounded audit dimensions')
require(len(audit['observations']) == 223 and sum(r['immutable_cache_reused'] for r in audit['observations']) == ta['immutable_tree_reuse_count'] == 220, 'immutable reuse count')
require(all(r['complete_tree'] for r in audit['observations']) and ta['all_223_recorded_trees_complete'], 'completeness recorded, not reaudited by this docs task')
require(ta['target_named_formalization_matches'] == audit['matches'] == [], 'retained path-scan result')
heads = obj(B/'MI24-MF18-current-public-audit-v2-20260918/FRESH-BRANCH-HEADS.json')
require(len(heads) == 15 and sum(len(v) for v in heads.values()) == 269, 'branch enumeration summary')
require(len({r['sha'] for rows in heads.values() for r in rows}) == 223, 'unique commits')
prs = public['upstream_PR_search']
bound(prs['original_path'], prs['sha256'])
pr_raw = obj(prs['original_path'])
pr_obs = next(r for r in pr_raw['observations'] if r['target'] == 'MF-18')
require(prs['results'] == json.loads(pr_obs['stdout']) and prs['argv'] == pr_obs['argv'], 'exact MF18 PR rows')
require(prs['exit_code'] == pr_obs['exit_code'] == 0 and prs['result_count'] == 4, 'actual retained PR result')
require(ta['observed_at_utc'] == audit['time'] and prs['observed_at_utc'] == pr_raw['time'], 'dated observation scope')

state = obj(D/'STATE.json')
require(state['complete_original_complex_target'] and state['proof_sources_locally_complete'], 'complete original source scope')
require(state['mathematical_resolutions_count_increment'] == state['complete_Lean_verifications_count_increment'] == 0, 'no count increment')
require(not state['ready_to_publish_as_verified'] and state['final_Linux_Comparator']['status'] == formal['status']['final_Linux_status'] == 'not-run', 'Linux remains unrun')
require(state['final_Linux_Comparator']['run_id'] is None and state['final_Linux_Comparator']['publication_commit'] is None, 'no invented run ID or commit')
require(state['local_proof']['run'] == 340 and state['local_type_diagnostics']['run'] == 341, 'actual run numbers')
require(state['local_proof']['fresh_modules'] == 28 and state['local_proof']['source_matched_reused_modules'] == 10, 'fresh/reused scope')
require(not state['documentation']['independent_metadata_review'] and not state['documentation']['standalone_full_package_assembled_here'], 'author documentation scope')
require(formal['alignment']['formal_proof'] == 'NLA.MF18.canonical_full_complex_rank' and formal['alignment']['extra_substantive_hypotheses'] is False, 'full canonical export')
require(formal['status']['local_proof']['source_sha256'] == complete['sources'], 'metadata complete source closure')
require(formal['status']['local_proof']['record_sha256'] == sha(B/'MF18-LOCAL-COMPLETE-340.json') and formal['status']['local_type_diagnostic']['record_sha256'] == sha(diag_dir/'COMPARISON.json'), 'metadata evidence records')
require(state['source_review']['successor_manifests'] == {r['agent']: r['manifest_sha256'] for r in reviews['reviews'] if r['source_run'] == 340}, 'state two exact successor approvals')
integration = obj(D/'INTEGRATION-REQUIREMENTS.json')
require(integration['source_snapshot_manifest_sha256'] == sha(S/'MANIFEST.json') and not integration['configuration_change_required'], 'integration exact source')

# Email and bulk-artifact check over only this publication draft, including copies.
email_re = re.compile(r'[A-Za-z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+')
for path in D.rglob('*'):
    if not path.is_file():
        continue
    require(path.suffix.lower() not in {'.pdf','.olean','.o','.so','.dylib','.gz','.zip','.pyc'}, f'no bulk or compiled artifact: {path.name}')
    text = path.read_text()
    require(email_re.search(text) is None, f'no email: {path.name}')

print(json.dumps({
    'status': 'PASS_READ_ONLY_DOCUMENT_INTEGRITY', 'checks': checks,
    'payload_files': payloads, 'schema': 'v0.4, pinned schema validated',
    'source_snapshot_payloads_authenticated': snapshot_payloads,
    'proof_closure_sources_authenticated': 38, 'frozen_contract_headers_authenticated': 25,
    'root_local_run': 340, 'root_fresh_compilations': 28, 'root_source_matched_reused_successes': 10,
    'root_origin_receipts_authenticated': len(receipts), 'root_successful_source_origin_logs_authenticated': 38,
    'root_diagnostic_run': 341, 'binder_normalized_types_and_universes_recompared': 25,
    'actual_body_graph_nodes_authenticated': 193, 'actual_LeanCert_routes_rechecked': 4,
    'review_packets_authenticated': 6, 'current_nonauthor_source_approvals': 2,
    'Lake_configuration_changed': False, 'standalone_Lake_build_executed_by_task': False,
    'Lean_Lake_Comparator_executions_by_task': 0, 'network_queries_by_task': 0,
    'final_Linux_Comparator_status': 'not-run', 'count_increment': 0,
    'scope': 'Author-prepared documentation/schema/integrity check against retained local evidence; not independent metadata review, a compiler rerun or publication acceptance.'
}, indent=2))
