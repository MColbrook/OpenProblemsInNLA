# MF-18 root independent statement review — preliminary semantic pass

Reviewer: `/root`, independent of the MF18 draft author agent. Read the complete
canonical README and full solution manuscript, all transparent definitions and
all 25 proposed contracts, numerical obligations and library plan. Applied the
retained Tau Ceti semantic faithfulness and generality guidance. The root
actually ran the draft integrity checker (tool1136cf, exit0), covering64 payloads,
23 source bindings,22 library bindings and25 proposed names. This checker is not
a proof or semantic checker. No Tau Ceti CLI invocation is claimed.

Preliminary conclusion: no mathematical mismatch or counterexample found.
The draft includes the full original complex target. A final exact-header
approval still requires the repaired candidate to elaborate and its bytes to be
bound; two independent approvals are required before any MF18 implementation.
The original draft's reserved lambda binder and a matrix determinant field
notation failed actual local286. The changes in local287 rename that binder and
qualify Matrix.det only; they do not alter a mathematical assumption.

## Independent correspondence and adversarial checks

The four matrices range over every complex n-by-n matrix, n positive at the
final theorem. Only R,P are Hermitian. CirclePositive uses Hermitian positive
definiteness, not entrywise inequalities or finitely many samples. The left
coefficient is C*+i eta D*, not the adjoint of C+i eta D. The transition is
X_eta^{-1}(C+i eta D), and the right limit has no assertion for eta<=0.
GreenAssumptions contains the nonlinear equation, invertibility, stability,
right limit, regularity, and simple unit roots; none of the needed count or rank
conclusions appears as an input. The original uniqueness assumption is retained
by the canonical corollary and validly omitted from the stronger result.

The target rank is over C of (X-X*)/(2i). It is not entrywise imaginary-part
rank, numerical rank, positivity, or a real-coefficient restriction. Polynomial
roots are multisets; unit simplicity uses algebraic rootMultiplicity. The
regularity hypothesis rules out the zero polynomial's artificial empty roots.
Full matrix determinant polynomials are used and their degree is only bounded
above by2n, preserving singular leading coefficients.

Contracts1–4: the exact half certificate is to be consumed in the positive
average proof; strict spectral semantics, determinant evaluation and the degree
bound are correct. A certificate or the semantic bridge has not been proved.
Contracts5–6: evaluation at opposite unit points proves positivity of P and of
the minus-sign form. The homotopy has Hermitian real part and strictly negative
Hermitian imaginary part for all t in[0,1], including both endpoints.
Contracts7–10: lambda=(z-1)/(z+1) maps the right half-plane to the open disk.
The homogeneous grade-N Cayley polynomial has leading coefficient p(1), and
extra roots caused by degree drop occur at z=-1 in the excluded half-plane.
The boundary hypotheses ensure p(1) is nonzero. N=0 and nonzero constant p
produce the monic constant1 and zero counts. Fixed-degree monic multiplicity
continuity is a required conclusion, never an assumed root-count oracle.
Contracts11–15: the homotopy starts at det(-i eta lambda P), with n disk roots.
The stated factorization has coefficients B,-(B X^{-1}A+X),A, hence is exactly
the nonlinear equation. Its last factor consumes all n disk roots. A nonzero
eigenvalue of B X^{-1} of norm>=1 would give a forbidden reciprocal root in the
closed disk. Limits of these fixed-size characteristic polynomials therefore
yield weak stability of both transition matrices, without assuming C or D
invertible or root degrees constant for the original pencil.
Contracts16–17: conjugate-reciprocal symmetry of grade2n gives degree+zero
multiplicity=2n; nonzero off-circle roots pair with identical multiplicities.
Thus2*diskCount+circleCount=2n, including zero roots and degree drops. The
factorization and weak stability select exactly n-m disk and m simple unit
roots for S. No integer division or omitted zero/infinite roots is hidden.
Contracts18–20: taking adjoints of the actual limiting equation gives H=S*HS.
On a unit eigenvector the pencil's derivative pairing is v*(X*-X)v. A simple
determinant root and the Hermitian divided pencil force this pairing nonzero;
the determinant/adjugate transversality is still an implementation obligation.
Generalized Stein nonresonance follows by induction on the two nilpotent orders;
order0 forces the relevant vector to vanish. No Hermitian assumption on H is
needed for that general pairing identity.
Contracts21–23: the stable space is the supremum of actual generalized
eigenspaces for all roots in the open disk. Primary decomposition identifies
its finrank with the multiset count. Weak stability plus nonresonance kills
all pairings against stable vectors, hence gives a kernel inclusion without
assuming semisimplicity of the stable part. Distinct unit eigenvectors have a
diagonal Gram matrix with nonzero diagonal; rank lower bounds need no positivity
of H. Stable rank-nullity and this lower bound give equality, including m=0.
Contracts24–25: these combine the original assumptions and counts into the
complete target. The second is the literal canonical uniqueness formulation.

Two independent scalar checks illustrate non-vacuity and retained degeneracies.
For C=i, R=0, D=0, P=1, take X_eta=i(eta+sqrt(eta^2+4))/2. This is stabilizing
for eta>0 and tends to i. The pencil i(1-lambda^2) has simple roots at both1
and-1, while H=1 has rank1. For C=D=0,R=P=1, take X_eta=1+i eta. The pencil
is-lambda, so degree1+zero multiplicity1=2, there are no unit roots, and H=0.
These are informal analytic checks, not executed Lean or numerical tests.

## Remaining gate and implementation work

A full final header review must bind successful local elaboration, exact
Definitions/Challenge/Comparator hashes, and the second independent review.
The root-count, Cayley multiplicity, reciprocal bookkeeping and adjugate
crossing bridges remain substantial unproved work. No solved/Lean-verified
status, publication, new resolution, or count increase follows from this
preliminary statement review. Default-kernel LeanCert and final real Linux
Comparator checks remain unrun for MF18.
