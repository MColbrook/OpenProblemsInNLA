#!/usr/bin/env python3
"""Read-only integrity replay for the independent MF-18 local332 source review.

Authenticates every sealed source, frozen contract, root local receipt/reuse DAG,
actual local334 diagnostic source/log/type dump, and proof-body certificate route.
Does not invoke Lean, Lake, Comparator, Git, shell, subprocess, or network. Hashes
and receipts authenticate evidence, not the semantic assessment or kernel itself.
Its execution receipt stays outside this directory's manifest to avoid cycles.
"""
from __future__ import annotations
from collections import deque
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
SNAPSHOT_MANIFEST_SHA256 = '2e759d65649392fc8c0df938b6a1ec9d4edc12fedb0a10aef09034397cdde13e'
COMPLETE_SHA256 = '7ea613c437d233a8a9c3f71589b8a54c3b15c394654f2a939780f30bb17570d2'
COMPARISON_SHA = '4a1ff806626d3a18c2a9736f824f85ece2e63805fd33678687e8d074cd3cbec3'
PERMITTED = {'propext', 'Classical.choice', 'Quot.sound'}

def sha(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path: Path | str):
    return json.loads(Path(path).read_text())


def authenticate(path: Path | str, expected: str, size: int | None = None):
    path = Path(path)
    assert path.is_file(), f"missing file: {path}"
    assert sha(path) == expected, f"hash mismatch: {path}"
    if size is not None:
        assert path.stat().st_size == size, f"size mismatch: {path}"


def manifest_files(path: Path):
    m = read(path)
    entries = m["files"]
    if isinstance(entries, dict):
        entries = [{"path": name, "sha256": h} for name, h in entries.items()]
    seen = set()
    for item in entries:
        name = item["path"]
        assert name not in seen and not Path(name).is_absolute() and ".." not in Path(name).parts
        seen.add(name)
        authenticate(path.parent / name, item["sha256"], item.get("bytes"))
    return seen


def strip_comments(text: str) -> str:
    # Lean permits nested block comments. Preserve line numbers and code strings.
    out = []
    i = depth = 0
    line_comment = quoted = False
    while i < len(text):
        pair = text[i:i + 2]
        ch = text[i]
        if line_comment:
            out.append("\n" if ch == "\n" else " ")
            if ch == "\n":
                line_comment = False
            i += 1
        elif depth:
            if pair == "/-":
                depth += 1
                out.append("  ")
                i += 2
            elif pair == "-/":
                depth -= 1
                out.append("  ")
                i += 2
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
        elif quoted:
            out.append(ch)
            i += 1
            if ch == "\\" and i < len(text):
                out.append(text[i])
                i += 1
            elif ch == '"':
                quoted = False
        elif pair == "/-":
            depth = 1
            out.append("  ")
            i += 2
        elif pair == "--":
            line_comment = True
            out.append("  ")
            i += 2
        else:
            quoted = ch == '"'
            out.append(ch)
            i += 1
    assert depth == 0 and not quoted, "unbalanced comments or strings"
    return "".join(out)


def local_imports(text: str):
    code = strip_comments(text)
    return [name for row in re.findall(r"^import\s+([^\n]+)", code, re.M)
            for name in row.split() if name.startswith("NLA.")]


bindings = read(HERE / "BINDINGS.json")
verdict = read(HERE / "VERDICT.json")
review_files = manifest_files(HERE / "MANIFEST.json")
assert review_files == {"REVIEW.md", "VERDICT.json", "BINDINGS.json", "verify_review.py", "FIRST-FINDINGS.json", "FULL-FINDINGS.json", "REUSE-SEARCHES.json", "declarations.txt"}
assert verdict["snapshot_manifest_sha256"] == SNAPSHOT_MANIFEST_SHA256
assert verdict["reviewer"] == "/root/mi24_full_referee1"
assert verdict["own_Lean_executions"] == verdict["own_Lake_executions"] == verdict["own_Comparator_executions"] == 0
assert verdict["count_changes"] == {"mathematical_resolutions": 0, "complete_Lean_verifications": 0}
assert verdict["overall"] == "request_changes"

snapshot = Path(bindings["snapshot"])
authenticate(snapshot / "MANIFEST.json", SNAPSHOT_MANIFEST_SHA256)
snapshot_files = manifest_files(snapshot / "MANIFEST.json")
assert len(snapshot_files) == 49
assert {str(p.relative_to(snapshot)) for p in snapshot.rglob("*") if p.is_file()} == snapshot_files | {"MANIFEST.json"}
authenticate(snapshot / "MF18-LOCAL-COMPLETE-332.json", COMPLETE_SHA256)
complete = read(snapshot / "MF18-LOCAL-COMPLETE-332.json")
freeze = read(snapshot / "MF18-STATEMENT-FREEZE-local288.json")
candidate = snapshot / "candidate"
config = read(candidate / "comparator.json")
names = config["theorem_names"]
assert len(names) == len(set(names)) == 25
assert names == freeze["contract_names"] == bindings["frozen_contracts"]
assert set(config["permitted_axioms"]) == PERMITTED
assert config["definition_names"] == []
assert config["challenge_module"] == "Challenge" and config["solution_module"] == "Solution"
for path, h in freeze["frozen_files"].items():
    authenticate(candidate / path, h)
assert bindings["frozen_files"] == freeze["frozen_files"]

source_hashes = complete["sources"]
assert source_hashes == bindings["source_hashes"]
assert len(source_hashes) == complete["actual_local_closure_modules"] == 38
assert complete["exact_contracts"] == 25
texts = {}
modules = {}
for rel, h in source_hashes.items():
    authenticate(candidate / rel, h)
    texts[rel] = (candidate / rel).read_text()
    name = "NLA.MF18.Solution" if rel == "Solution.lean" else rel[:-5].replace("/", ".")
    modules[name] = rel
assert {str(p.relative_to(candidate)) for p in candidate.rglob("*.lean")} == set(source_hashes) | {"Challenge.lean"}
imports = {name: local_imports(texts[rel]) for name, rel in modules.items()}
assert all(dep in modules for deps in imports.values() for dep in deps)
closures = {}
visiting = set()


def closure(name):
    if name not in closures:
        assert name not in visiting, f"import cycle: {name}"
        visiting.add(name)
        ans = {name}
        for dep in imports[name]:
            ans |= closure(dep)
        visiting.remove(name)
        closures[name] = ans
    return closures[name]


assert closure("NLA.MF18.Solution") == set(modules)
for rel, text in texts.items():
    code = strip_comments(text)
    # Static supplemental hygiene only; the logged axiom report is checked below.
    assert not re.search(r"\b(sorry|admit|sorryAx|native_decide|unsafe|axiom|implemented_by)\b", code), rel
    assert not re.search(r"(?m)^\s*(#eval|#reduce|run_elab|initialize|elab|macro|syntax|opaque|variable)\b", code), rel
    assert "import Challenge" not in code and "import NLA.MF18.Challenge" not in code, rel

challenge = (candidate / "Challenge.lean").read_text()
assert len(re.findall(r"\bsorry\b", strip_comments(challenge))) == 25
for name in names:
    pattern = r"^theorem\s+" + re.escape(name.split(".")[-1]) + r"\b[\s\S]*?(?=\s*:=\s*by)"
    expected = re.findall(pattern, challenge, re.M)
    found = [m.rstrip() for text in texts.values() for m in re.findall(pattern, text, re.M)]
    assert len(expected) == 1 and found == [expected[0].rstrip()], f"frozen header mismatch: {name}"
solution = texts["Solution.lean"]
assert re.findall(r"^#print axioms (\S+)$", solution, re.M) == names
assert re.findall(r"^#assert_trust kernel (\S+)$", solution, re.M) == names
assert 'set_option leancert.trust "kernel"' in solution
numerical = texts["NLA/MF18/Numerical.lean"]
assert 'interval_decide (trust := kernel)' in numerical
assert 'set_option leancert.trust "kernel"' in numerical
assert 'certified_half.1' in texts['NLA/MF18/Positivity.lean']
assert '#assert_trust kernel certified_half' in numerical

coverage = bindings["full_source_read_coverage"]
assert {x["path"] for x in coverage} == set(source_hashes) | {"Challenge.lean"}
for item in coverage:
    file = candidate / item["path"]
    authenticate(file, item["sha256"])
    assert item["read_lines"] == [1, len(file.read_text().splitlines())]
    assert item["read_in_full"] is True

retained = complete["retained_original_evidence"]
assert retained == bindings["local_evidence_hashes"]
for path, h in retained.items():
    authenticate(path, h)
local_root = Path(complete["receipt"]).parents[2]
authenticate(complete["receipt"], complete["receipt_sha256"])
authenticate(complete["assembly"], complete["assembly_sha256"])
entry = read(complete["receipt"])
assert entry["end"] and not entry["failed_modules"] and not entry["blocked_modules"]
assert entry["assembly_sha256"] == complete["assembly_sha256"]
authenticate(local_root / "serial_compile_v3.py", entry["runner_sha256"])
authenticate(snapshot / "capture_full_local_completion_v2.py", complete["audit_script_sha256"])
env = read(local_root / "LOCAL-ENVIRONMENT.json")
authenticate(env["compiler"], entry["compiler_sha256"])
manifest = read(candidate / "lake-manifest.json")
pins = {p["name"]: p["rev"] for p in manifest["packages"]}
assert pins == {p["package"]: p["commit"] for p in env["dependencies"]}
assert (candidate / "lean-toolchain").read_text().strip() == "leanprover/lean4:v4.33.1"
assert pins["mathlib"] == "0df444a360eaa60ab8c11dca51a86af692955474"
assert pins["leancert"] == "621a43d7cf21f87872392a01e874f2f1dbddc926"
for dep in ("mathlib", "leancert"):
    dotgit = local_root / ".lake/packages" / dep / ".git"
    head = (dotgit / "HEAD").read_text().strip()
    if head.startswith("ref: "):
        head = (dotgit / head[5:]).read_text().strip()
    assert head == pins[dep]

origins = {o["module"]: o for o in complete["commands_and_successful_origins"]}
assert len(origins) == 38 and set(origins) == set(modules)
authenticated_receipts = set()
authenticated_logs = set()
authenticated_assemblies = set()
total_reuse_hops = 0
for module, origin in origins.items():
    rel = modules[module]
    local_rel = module.replace(".", "/") + ".lean"
    assert origin["canonical_source_path"] == rel and origin["source_sha256"] == source_hashes[rel]
    chain = origin["reuse_chain"]
    assert chain and chain[0] == {"receipt": complete["receipt"], "sha256": complete["receipt_sha256"]}
    assert len({h["receipt"] for h in chain}) == len(chain)
    assert origin["historical_reuse_hops_authenticated"] == len(chain) - 1
    total_reuse_hops += len(chain) - 1
    for i, hop in enumerate(chain):
        path = Path(hop["receipt"])
        authenticate(path, hop["sha256"])
        assert retained[str(path)] == hop["sha256"]
        node = read(path)
        assert node.get("end") and node["platform"] == "darwin"
        assert node["threads"] == node["max_compiler_processes"] == 1
        assert 0 < node["memory_cap_mib"] <= 4096
        assert node["runner_sha256"] == entry["runner_sha256"]
        assert node["compiler_sha256"] == entry["compiler_sha256"]
        assembly = local_root / ("ASSEMBLY-" + path.parent.name.removeprefix("development-") + ".json")
        authenticate(assembly, node["assembly_sha256"])
        assembly_sources = read(assembly)["sources"]
        assert {p: item["sha256"] for p, item in assembly_sources.items()} == node["source_inputs"]
        authenticated_assemblies.add(str(assembly))
        authenticated_receipts.add(str(path))
        commands = [c for c in node["commands"] if c["module"] == module]
        assert len(commands) == 1
        command = commands[0]
        assert command["source_sha256"] == source_hashes[rel]
        assert command["output_sha256"] == origin["command"]["output_sha256"]
        for dep in closure(module):
            dep_rel = dep.replace(".", "/") + ".lean"
            assert node["source_inputs"][dep_rel] == source_hashes[modules[dep]], (module, dep, path)
        if i + 1 < len(chain):
            assert command["status"] == "reused_exact_successful_local_output"
            assert command["prior_receipt"] == chain[i + 1]["receipt"]
            assert command["prior_receipt_sha256"] == chain[i + 1]["sha256"]
            transitive = command.get("transitive_source_hashes")
            if transitive is not None:
                assert transitive == {dep.replace(".", "/") + ".lean": source_hashes[modules[dep]] for dep in closure(module)}
        else:
            assert str(path) == origin["success_origin_receipt"]
            assert sha(path) == origin["receipt_sha256"]
            assert command == origin["command"] and command["exit_code"] == 0
            assert command["cwd"] == str(local_root)
            expected_argv = [env["compiler"], "--threads=1", "--memory=4096", "-o",
                             str(local_root / ".lake/build/lib/lean" / (local_rel[:-5] + ".olean")), local_rel]
            assert command["argv"] == expected_argv
            assert command["end"] >= command["start"] and command["elapsed_seconds"] >= 0
            assert set(command["dependency_olean_sha256"]) == set(imports[module])
            for dep, h in command["dependency_olean_sha256"].items():
                assert h == origins[dep]["command"]["output_sha256"], (module, dep)
            log = path.parent / (module + ".log")
            authenticate(log, command["log_sha256"])
            assert retained[str(log)] == command["log_sha256"]
            assert "error:" not in log.read_text() and "sorryAx" not in log.read_text()
            authenticated_logs.add(str(log))

assert authenticated_receipts | authenticated_logs == set(retained)
assert len(authenticated_receipts) == 27 and len(authenticated_logs) == 38
solution_origin = origins["NLA.MF18.Solution"]
entry_log = Path(solution_origin["success_origin_receipt"]).parent / "NLA.MF18.Solution.log"
observed = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", entry_log.read_text(), re.M)
assert [name for name, _ in observed] == names
observed_axioms = {name: [a.strip() for a in value.split(",")] for name, value in observed}
assert observed_axioms == complete["observed_axioms"]
assert all(set(ax) <= PERMITTED for ax in observed_axioms.values())
num_origin = origins["NLA.MF18.Numerical"]
num_log = Path(num_origin["success_origin_receipt"]).parent / "NLA.MF18.Numerical.log"
assert "'NLA.MF18.certified_half' depends on axioms: [propext, Classical.choice, Quot.sound]" in num_log.read_text()
assert complete['source_filename_mapping'] == {'local': 'NLA/MF18/Solution.lean', 'canonical': 'Solution.lean', 'sha256': source_hashes['Solution.lean']}
assert entry['completed_modules'] == len(entry['commands']) == len(entry['module_order']) == 72
assert set(modules) <= set(entry['module_order'])
outside_scope = set(entry['module_order']) - set(modules)
assert len(outside_scope) == 34 and all(m.startswith('NLA.MI24.') for m in outside_scope)
entry_mf18 = [c for c in entry['commands'] if c['module'] in modules]
fresh = sum(c.get('exit_code') == 0 for c in entry_mf18)
assert len(entry_mf18) == 38 and fresh == 2
assert origins['NLA.MF18.Solution']['success_origin_receipt'] == complete['receipt']

statement_packet = Path(freeze["packet"])
authenticate(statement_packet / "MANIFEST.json", freeze["packet_manifest_sha256"])
manifest_files(statement_packet / "MANIFEST.json")
authenticate(statement_packet / "run/RECEIPT.json", freeze["local_statement_receipt_sha256"])
for rel, h in freeze["frozen_files"].items():
    authenticate(statement_packet / "candidate" / rel, h)
for reviewer in freeze["reviewers"]:
    path = Path(reviewer["manifest"])
    authenticate(path, reviewer["manifest_sha256"])
    manifest_files(path)
    rv = read(path.parent / "VERDICT.json")
    assert rv.get("packet_manifest_sha256", rv.get("approved_candidate_manifest_sha256")) == freeze["packet_manifest_sha256"]
    assert "APPROVE" in rv.get("verdict", rv.get("decision", ""))
    if "approved_candidate_files" in rv:
        assert rv["approved_candidate_files"] == freeze["frozen_files"]

for item in bindings["references"]:
    authenticate(item["path"], item["sha256"], item["bytes"])
standards_root = Path(bindings["standards_root"])
standards = read(standards_root / "STANDARD-BINDINGS.json")
for standard in standards["standards"]:
    authenticate(standards_root / standard["path"], standard["sha256"], standard.get("bytes"))
    if "TauCetiReview" in standard["path"]:
        assert standard["upstream"]["commit"] == "afb424eda89e8ac96d9eb69f6a88972055a4cd1b"

# Names shared with this reviewer's independent diagnostic validation utility.
S, P, L = snapshot, candidate, local_root
auth, sources, COMPLETE_SHA = authenticate, source_hashes, COMPLETE_SHA256

# Actual root local334 diagnostics: bind diagnostic sources and dependency
# oleans to the successful332 closure, then recompute all comparisons/routes.
D = B / 'MF18-type-diagnostics-334'
auth(D / 'COMPARISON.json', COMPARISON_SHA)
comparison = read(D / 'COMPARISON.json')
assert comparison['source_complete_record_sha256'] == COMPLETE_SHA
auth(comparison['source_complete_record'], COMPLETE_SHA)
auth(comparison['receipt'], comparison['receipt_sha256'])
dr = read(comparison['receipt'])
auth(L / 'ASSEMBLY-334.json', comparison['assembly_sha256'])
assert dr['assembly_sha256'] == comparison['assembly_sha256']
da = read(L / 'ASSEMBLY-334.json')
assert {p: e['sha256'] for p, e in da['sources'].items()} == dr['source_inputs']
assert dr.get('end') and not dr['failed_modules'] and not dr['blocked_modules']
assert dr['platform'] == 'darwin' and dr['threads'] == dr['max_compiler_processes'] == 1
assert dr['memory_cap_mib'] == 4096
assert dr['compiler_sha256'] == entry['compiler_sha256'] and dr['runner_sha256'] == entry['runner_sha256']
dc = {c['module']: c for c in dr['commands']}
for module, rel in modules.items():
    assert dr['source_inputs'][module.replace('.', '/') + '.lean'] == sources[rel]
    c = dc[module]
    assert c['status'] == 'reused_exact_successful_local_output'
    assert c['prior_receipt'] == complete['receipt'] and c['prior_receipt_sha256'] == complete['receipt_sha256']
    assert c['output_sha256'] == origins[module]['command']['output_sha256']
    assert c['transitive_source_hashes'] == {d.replace('.', '/') + '.lean': sources[modules[d]] for d in closure(module)}
diagnostic_modules = {'NLA.MF18Diagnostics.ChallengeTypes334', 'NLA.MF18Diagnostics.SolutionTypes334'}
assert set(dc) == set(modules) | diagnostic_modules
assert dr['completed_modules'] == 40
assert {c['module'] for c in comparison['diagnostic_commands']} == diagnostic_modules
for c in comparison['diagnostic_commands']:
    module = c['module']
    rel = module.replace('.', '/') + '.lean'
    assert c == dc[module] and c['exit_code'] == 0
    auth(D / 'sources' / rel, c['source_sha256'])
    assert dr['source_inputs'][rel] == c['source_sha256']
    assert c['argv'] == [env['compiler'], '--threads=1', '--memory=4096', '-o',
        str(L / '.lake/build/lib/lean' / (rel[:-5] + '.olean')), rel]
    assert c['cwd'] == str(L)
    log = Path(comparison['receipt']).parent / (module + '.log')
    auth(log, c['log_sha256'])
    assert 'error:' not in log.read_text()
    dep = 'NLA.MF18.Definitions' if 'ChallengeTypes' in module else 'NLA.MF18.Solution'
    assert c['dependency_olean_sha256'] == {dep: origins[dep]['command']['output_sha256']}
challenge_diag = (D / 'sources/NLA/MF18Diagnostics/ChallengeTypes334.lean').read_text()
assert challenge_diag.startswith(challenge.replace('import NLA.MF18.Definitions\n', 'import NLA.MF18.Definitions\nimport Lean\n') + '\n')
assert challenge_diag.count('sorry') == challenge.count('sorry')
solution_diag = (D / 'sources/NLA/MF18Diagnostics/SolutionTypes334.lean').read_text()
assert solution_diag.startswith('import NLA.MF18.Solution\nimport Lean\n')
normalizer_start = 'private def diagnosticEraseBinderNames'
normalizer_end = 'open Lean in\nrun_cmd do'
normalizer = lambda t: t.split(normalizer_start, 1)[1].split(normalizer_end, 1)[0]
assert normalizer(challenge_diag) == normalizer(solution_diag)
assert 'let ci ← getConstInfo name' in solution_diag
assert 'ci.value? (allowOpaque := true)' in solution_diag and 'body.getUsedConstants' in solution_diag
auth(D / 'challenge-types.json', comparison['challenge_dump_sha256'])
auth(D / 'solution-types.json', comparison['solution_dump_sha256'])
auth(D / 'certificate-body-route.json', comparison['body_graph_sha256'])
challenge_types, solution_types = read(D / 'challenge-types.json'), read(D / 'solution-types.json')
assert [r['name'] for r in challenge_types] == [r['name'] for r in solution_types] == names
# Eight raw types differ only in generated NeZero binder names; normalize names only.
assert sum(c['type'] != s['type'] for c, s in zip(challenge_types, solution_types)) == 8
results = [{'name': c['name'], 'same_universes': c['levelParams'] == s['levelParams'],
            'same_binder_normalized_type': c['binderNormalizedType'] == s['binderNormalizedType']}
           for c, s in zip(challenge_types, solution_types)]
assert results == comparison['results'] and all(r['same_universes'] and r['same_binder_normalized_type'] for r in results)
rows = read(D / 'certificate-body-route.json')
graph = {r['name']: r for r in rows}
assert len(rows) == len(graph) == comparison['body_graph_nodes'] == 197
assert all(graph[n]['hasBody'] for n in names)


def route(target):
    todo = deque([['NLA.MF18.canonical_full_complex_rank']])
    seen = set()
    while todo:
        path = todo.popleft()
        last = path[-1]
        if last == target:
            return path
        if last in seen:
            continue
        seen.add(last)
        if last in graph:
            assert graph[last]['hasBody']
            todo.extend(path + [n] for n in graph[last]['bodyConstants'] if n not in seen)
    raise AssertionError(('missing proof-body route', target))


routes = {
    'final_to_frozen_certificate': route('NLA.MF18.certified_half'),
    'final_to_kernel_checked_bound': route('LeanCert.Validity.verify_strict_upper_bound_dyadic_checked'),
    'final_to_exact_certificate_check_7': route('NLA.MF18.certified_half._proof_1_7'),
    'final_to_exact_certificate_check_15': route('NLA.MF18.certified_half._proof_1_15'),
}
assert routes == comparison['actual_elaborated_body_routes']
assert comparison['all25_match'] is True and comparison['Comparator_executed'] is False
auth(B / 'compare_mf18_diagnostics.py', comparison['comparison_script_sha256'])

assert bindings['diagnostic_comparison_sha256'] == COMPARISON_SHA
assert verdict['rubrics']['correctness'] == 'approve_source_scope'
assert verdict['publication_approval'] is False
assert verdict['other_final_reviewer_reports_read_before_sealing'] is False
assert set(verdict['findings']) == {'Q1','R1/G1','R2','R3','G2'}
ff = read(HERE / 'FULL-FINDINGS.json')
assert ff['snapshot_manifest_sha256'] == SNAPSHOT_MANIFEST_SHA256
assert {f['id'] for f in ff['findings']} == set(verdict['findings'])
q1 = next(f for f in ff['findings'] if f['id'] == 'Q1')['sites']
assert q1 == bindings['proof_quality_sites'] and len(q1) == 31
for site in q1:
    assert texts[site['path']].splitlines()[site['line']-1] == site['source_line']
all_conversions = {(rel, i+1) for rel, t in texts.items()
                   for i, line in enumerate(strip_comments(t).splitlines())
                   if re.search(r'\b(change|show)\b', line)}
assert all_conversions == {(x['path'],x['line']) for x in q1} | {('NLA/MF18/SelectedCount.lean',43)}
searches = read(HERE / 'REUSE-SEARCHES.json')
assert searches['returncode'] == 0 and not searches['stderr']
assert searches['candidate_names'] == (HERE / 'declarations.txt').read_text().splitlines()
assert len(searches['candidate_names']) == 153
assert str(B / 'next-proofs') in searches['command']
assert '!**/MF-18/**' in searches['command']
assert 'NLA/MF18' not in searches['stdout']

print(json.dumps({
    'status': 'PASS_READ_ONLY_INTEGRITY',
    'review_verdict': verdict['overall'],
    'snapshot_manifest_sha256': SNAPSHOT_MANIFEST_SHA256,
    'snapshot_files_authenticated': len(snapshot_files),
    'full_source_modules_authenticated': len(modules),
    'full_source_read_rows_bound_including_Challenge': len(coverage),
    'frozen_contract_headers_identical': len(names),
    'statement_review_manifests_authenticated': len(freeze['reviewers']),
    'root_local332_fresh_modules': fresh,
    'root_local332_authenticated_reused_modules': 38 - fresh,
    'root_local332_total_selected_modules': len(entry['module_order']),
    'root_local332_selected_modules_outside_review_scope': len(outside_scope),
    'local_receipts_authenticated': len(authenticated_receipts),
    'successful_origin_logs_authenticated': len(authenticated_logs),
    'local_assemblies_authenticated': len(authenticated_assemblies),
    'source_matched_reuse_hops_authenticated': total_reuse_hops,
    'final_logged_axiom_reports': len(observed),
    'final_source_kernel_assertions': len(names),
    'numerical_success_origin_run': int(Path(num_origin['success_origin_receipt']).parent.name.removeprefix('development-')),
    'actual_root_diagnostic_run': 334,
    'diagnostic_commands_authenticated': len(diagnostic_modules),
    'binder_name_normalized_elaborated_type_pairs_equal': len(results),
    'raw_type_pairs_differ_only_by_normalized_binder_names': 8,
    'actual_body_graph_nodes': len(rows),
    'actual_body_routes_to_certificate_checked_bound_and_exact_certificates': len(routes),
    'undocumented_change_show_sites_authenticated': len(q1),
    'reviewer_Lean_runs': 0, 'reviewer_Lake_runs': 0, 'reviewer_Comparator_runs': 0,
    'scope': 'Full independent source review and retained root local evidence; no Linux Comparator, publication, final metadata, or count approval.'
}, indent=2))
