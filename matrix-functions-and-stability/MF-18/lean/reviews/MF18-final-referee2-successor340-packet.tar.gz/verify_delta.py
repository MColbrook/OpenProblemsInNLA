#!/usr/bin/env python3
"""Read-only authentication of the MF18 bounded source cleanup, not a Lean run.

The actual root successor completion/diagnostics remain separate gates. Replays
this reviewer's sealed baseline integrity checker, then binds the full virtual
successor closure from unchanged baseline sources plus exact archived edits.
"""
from pathlib import Path
from contextlib import redirect_stdout
import difflib
import hashlib
import io
import json
import re
import runpy

H = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
BASE = B / 'reviews/MF18-final-referee2-local332'
C = B / 'MF18-source-history/referee-cleanup-local332'
BASE_SHA = '7b3efbb0665d4fb46e92b565611bb71441a5e26daff462e17b416d7b35263372'
CLEANUP_SHA = '5edd277cb372069d042a66298cea4cc06f8623a37fe9ab2a726f230dfac49411'
CHANGES_SHA = '612615ea390bccf9c416fafc5f50f969613453b2ce91d7c5d5bf56af23bfc423'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def auth(path, h, size=None):
    assert sha(path) == h, ('hash mismatch', str(path))
    if size is not None:
        assert Path(path).stat().st_size == size

auth(BASE / 'MANIFEST.json', BASE_SHA)
capture = io.StringIO()
with redirect_stdout(capture):
    base = runpy.run_path(str(BASE / 'verify_review.py'))
base_result = json.loads(capture.getvalue())
assert base_result['status'] == 'PASS_READ_ONLY_INTEGRITY'
assert base_result['review_verdict'] == 'request_changes'
auth(BASE.with_name(BASE.name + '-CHECK.json'),
     'bde18986e765549cc6063844f7aa84d705c7b7bddaacbc51240d6fba0b48ae82')
auth(C / 'MANIFEST.json', CLEANUP_SHA)
inventory = base['manifest_files'](C / 'MANIFEST.json')
assert inventory == {str(p.relative_to(C)) for p in C.rglob('*') if p.is_file()} - {'MANIFEST.json'}
auth(C / 'CHANGES.json', CHANGES_SHA)
changes = read(C / 'CHANGES.json')
assert changes['baseline_manifest_sha256'] == base['SNAPSHOT_MANIFEST_SHA256']
assert any(r['sha256'] == BASE_SHA and r['path'] == str(BASE / 'MANIFEST.json')
           for r in changes['review_manifests'])
data = read(H / 'SOURCE-DELTA.json')
assert data['baseline_manifest_sha256'] == BASE_SHA
assert data['cleanup_manifest_sha256'] == CLEANUP_SHA
assert data['changes_sha256'] == CHANGES_SHA
assert data['resolved_findings'] == ['Q1', 'R1/G1', 'R2', 'R3', 'G2']
assert data['remaining_source_findings'] == []
assert data['own_Lean_runs'] == data['own_Lake_runs'] == data['own_Comparator_runs'] == 0
assert data['root_new_Lean_completion_authenticated'] is False
assert data['root_new_diagnostics_authenticated'] is False
assert data['publication_approval'] is False and data['count_changes'] == 0

changed = {x['path']: x for x in changes['changed_files']}
assert len(changed) == len(changes['changed_files']) == 17
norm = lambda s: ''.join(base['strip_comments'](s).split())
oldtexts = base['texts']
texts = {}
diff = ''
comment_only, signature_only, proof_reuse = [], [], []
for rel, old in sorted(oldtexts.items()):
    if rel in changed:
        x = changed[rel]
        auth(C / 'before' / rel, base['source_hashes'][rel])
        assert x['before_sha256'] == base['source_hashes'][rel]
        auth(C / 'after' / rel, x['after_sha256'], x['after_bytes'])
        new = (C / 'after' / rel).read_text()
        diff += ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
            fromfile='local332/' + rel, tofile='candidate/' + rel))
        if x['kind'] == 'comments only':
            assert norm(old) == norm(new)
            comment_only.append(rel)
        elif x['kind'] == 'helper signature generalization only':
            signature_only.append(rel)
        else:
            assert x['kind'] == 'proof reuse and local comments'
            proof_reuse.append(rel)
    else:
        new = old
    texts[rel] = new
    assert hashlib.sha256(new.encode()).hexdigest() == data['source_hashes'][rel]
    assert base['local_imports'](new) == base['local_imports'](old)
    assert re.findall(r'^import[^\n]*$', new, re.M) == re.findall(r'^import[^\n]*$', old, re.M)
    code = base['strip_comments'](new)
    assert not re.search(r'\b(sorry|admit|sorryAx|native_decide|unsafe|axiom|implemented_by)\b', code)
    assert not re.search(r'(?m)^\s*(#eval|#reduce|run_elab|initialize|elab|macro|syntax|opaque|variable)\b', code)
assert set(data['source_hashes']) == set(base['source_hashes'])
assert diff == (C / 'cleanup.diff').read_text()
assert (len(comment_only), len(signature_only), len(proof_reuse)) == (8, 2, 7)
assert len(texts) == 38
assert changes['frozen_files_unchanged'] == list(base['freeze']['frozen_files'])
assert not set(changed) & set(base['freeze']['frozen_files'])

def headers(text):
    return {m.group(2): m.group(0) for m in re.finditer(
        r'^(?:(?:private|protected)\s+)?(theorem|lemma)\s+(\w+)\b[\s\S]*?:=', text, re.M)}

olds = {k: v for t in oldtexts.values() for k, v in headers(t).items()}
news = {k: v for t in texts.values() for k, v in headers(t).items()}
generalized = {'exists_fin_multiset_enumeration', 'independent_finset_sup_finrank'}
assert set(news) - set(olds) == {'pencil_factorization', 'pencil_polynomial_factorization'}
assert set(olds) <= set(news)
for name, old in olds.items():
    if name not in generalized:
        assert news[name] == old, ('changed old header', name)
for rel in signature_only:
    reconstructed = texts[rel]
    for name in generalized & headers(reconstructed).keys():
        reconstructed = reconstructed.replace(news[name], olds[name], 1)
    assert reconstructed == oldtexts[rel], rel
for name in base['names']:
    short = name.split('.')[-1]
    assert news[short] == olds[short]
assert '{α : Type*}' in news['exists_fin_multiset_enumeration']
assert '[DivisionRing K]' in news['independent_finset_sup_finrank']
assert '[FiniteDimensional K V]' in news['independent_finset_sup_finrank']
for name in ('pencil_factorization', 'pencil_polynomial_factorization'):
    assert '(A B Q X : Mat n)' in news[name]
    assert '(hX : X.det ≠ 0) (heq : X + B * X⁻¹ * A = Q)' in news[name]
    assert 'Stabil' not in news[name]
assert 'exact pencil_factorization (regularizedA C D η)' in texts['NLA/MF18/PencilAlgebra.lean']
assert 'exact pencil_factorization C C.conjTranspose R X hX heq z' in texts['NLA/MF18/UnregularizedFactorization.lean']
assert 'exact pencil_polynomial_factorization (regularizedA C D η)' in texts['NLA/MF18/SolutionPolynomial.lean']
assert 'exact pencil_polynomial_factorization C C.conjTranspose R X hX heq' in texts['NLA/MF18/UnregularizedFactorization.lean']
assert 'have hleft' not in texts['NLA/MF18/SteinIdentity.lean']
assert 'Matrix.mul_nonsing_inv_cancel_left X₀ C hu' in texts['NLA/MF18/SteinIdentity.lean']
assert texts['NLA/MF18/ReciprocalCount.lean'].count('Multiset.filter_add_not') == 2
assert 'induction s' not in texts['NLA/MF18/ReciprocalCount.lean']
for rel in ('NLA/MF18/BoundaryNonvanishing.lean', 'NLA/MF18/UnitPencilKernel.lean'):
    assert 'Matrix.isHermitian_add_transpose_self (lam • C.conjTranspose)' in texts[rel]
    assert 'change ' not in base['strip_comments'](texts[rel])

comments = read(C / 'COMMENTS.json')['sites']
assert len(comments) == 29
trim = lambda s: s.strip().removeprefix('· ').strip()
oldsites = {(x['path'], trim(x['source_line'])): x for x in base['q1']}
removed = {'NLA/MF18/BoundaryNonvanishing.lean', 'NLA/MF18/UnitPencilKernel.lean'}
assert {(x['file'], trim(x['site'])) for x in comments} == {
    k for k in oldsites if k[0] not in removed}
resolved = []
for x in comments:
    lines = texts[x['file']].splitlines()
    positions = [i for i, line in enumerate(lines) if line.strip() == x['comment']]
    assert len(positions) == 1
    i = positions[0]
    assert trim(lines[i + 1]) == trim(x['site'])
    resolved.append({'path': x['file'], 'old_line': oldsites[(x['file'], trim(x['site']))]['line'],
        'new_line': i + 2, 'comment_line': i + 1, 'comment': x['comment']})
conversions = {(r, i + 1) for r, t in texts.items()
    for i, line in enumerate(base['strip_comments'](t).splitlines())
    if re.search(r'\b(change|show)\b', line)}
assert conversions == {(x['path'], x['new_line']) for x in resolved} | {('NLA/MF18/SelectedCount.lean', 43)}
assert len(data['coverage']) == len(texts)
for row in data['coverage']:
    r = row['path']
    assert row['baseline_sha256'] == base['source_hashes'][r]
    assert row['successor_sha256'] == data['source_hashes'][r]
    assert row['baseline_full_read'] is True
    assert row['successor_lines'] == [1, len(texts[r].splitlines())]
    assert row['read_mode'] == ('reread_in_full' if r in proof_reuse + signature_only else
        'complete_delta_and_context_read' if r in comment_only else 'byte_identical_full_read_carried_forward')
for x in data['library_references']:
    auth(x['path'], x['sha256'], x['bytes'])

print(json.dumps({'status': 'PASS_SOURCE_DELTA_INTEGRITY',
    'baseline_integrity_replayed': base_result,
    'cleanup_manifest_sha256': CLEANUP_SHA,
    'full_successor_source_hashes_bound': len(texts),
    'changed_files': len(changed), 'unchanged_files': len(texts) - len(changed),
    'comment_only_files': len(comment_only), 'signature_only_files': len(signature_only),
    'proof_reuse_files': len(proof_reuse),
    'frozen_files_preserved': 3, 'frozen_headers_preserved': len(base['names']),
    'resolved_adjacent_comment_sites': len(resolved), 'removed_conversion_sites': 2,
    'new_generic_factorization_helpers': 2, 'generalized_helpers': 2,
    'new_execution_approval': False,
    'reviewer_Lean_runs': 0, 'reviewer_Lake_runs': 0, 'reviewer_Comparator_runs': 0}, indent=2))
