#!/usr/bin/env python3
"""Read-only byte/coverage/evidence replay. No compiler, subprocess, or network.

Run python3 verify_review.py [--live]. This checks declared identities and the
retained root execution receipt, not mathematical truth or a newly run checker.
External immutable draft/local288 packets remain required at SCOPE.json paths.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

R = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--live', action='store_true')
args = parser.parse_args()
checks = 0


def require(test, message):
    global checks
    checks += 1
    if not test:
        raise SystemExit('FAIL: ' + message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def readj(path):
    return json.loads(path.read_text())


def safe(root, rel):
    p = Path(rel)
    require(not p.is_absolute() and '..' not in p.parts, 'unsafe relative path')
    return root / p


def inventory(root, expected_manifest, exact=True):
    mf = root / 'MANIFEST.json'
    require(sha(mf) == expected_manifest, 'manifest hash: ' + str(root))
    data = readj(mf)['files']
    entries = data if isinstance(data, list) else [
        {'path': k, 'sha256': v} for k, v in data.items()]
    names = [x['path'] for x in entries]
    require(len(names) == len(set(names)), 'unique manifest names')
    for e in entries:
        p = safe(root, e['path'])
        require(p.is_file(), 'missing payload: ' + str(p))
        require(sha(p) == e['sha256'], 'payload hash: ' + str(p))
        if 'bytes' in e:
            require(p.stat().st_size == e['bytes'], 'payload size: ' + str(p))
    if exact:
        actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()
                  and p != mf and '__pycache__' not in p.parts}
        require(actual == set(names), 'exact manifest inventory: ' + str(root))
    return len(entries)


scope = readj(R / 'SCOPE.json')
verdict = readj(R / 'VERDICT.json')
D, P = Path(scope['draft']['path']), Path(scope['elaborated']['path'])
nd = inventory(D, scope['draft']['manifest_sha256'])
np = inventory(P, scope['elaborated']['manifest_sha256'])
require(nd == 64 and np == 9, 'reviewed packet inventory counts')
require(scope['source_commit'] == 'e7519c46fd249a6a033bfe5d11c66bf47f7f8885',
        'canonical source pin')
for rel, h in scope['primary_sources'].items():
    require(sha(safe(D, rel)) == h, 'primary source binding ' + rel)
for rel, h in scope['candidate_files'].items():
    require(sha(safe(P / 'candidate', rel)) == h, 'candidate binding ' + rel)
    snapshot = {'NLA/MF18/Definitions.lean': 'Definitions.lean',
                'Challenge.lean': 'Challenge.lean',
                'comparator.json': 'comparator.json'}[rel]
    require(sha(R / 'reviewed' / snapshot) == h, 'review snapshot ' + rel)
    if args.live:
        require(sha(safe(Path(scope['live_candidate']), rel)) == h,
                'live candidate binding ' + rel)
if args.live:
    for path, h in scope['additional_read_api_files'].items():
        require(sha(Path(path)) == h, 'inspected API binding ' + path)

olddef = (D / 'NLA/MF18/Definitions.lean').read_text()
oldch = (D / 'Challenge.lean').read_text()
defs = (R / 'reviewed/Definitions.lean').read_text()
ch = (R / 'reviewed/Challenge.lean').read_text()


def common_delta(s):
    return s.replace('λ', 'lam').replace(
        'open scoped BigOperators Topology',
        'open scoped BigOperators Topology ComplexOrder')


expected = common_delta(olddef)
expected = expected.replace(
    '(fun i j => Polynomial.C ((B * X⁻¹) i j) * Polynomial.X -\n'
    '    Polynomial.C ((1 : Mat n) i j) : Matrix (Fin n) (Fin n) CPoly).det',
    'Matrix.det (fun i j => Polynomial.C ((B * X⁻¹) i j) * Polynomial.X -\n'
    '    Polynomial.C ((1 : Mat n) i j))')
expected = expected.replace('(S.toLin\').maxGenEigenspace lam',
                            'Module.End.maxGenEigenspace S.toLin\' lam')
require(expected == defs, 'entire Definitions syntax-only delta')
require(common_delta(oldch) == ch, 'entire Challenge alpha/scope-only delta')


def strip_comments(s):
    out = []
    i, depth = 0, 0
    while i < len(s):
        if s.startswith('/-', i):
            depth += 1
            i += 2
        elif depth and s.startswith('-/', i):
            depth -= 1
            i += 2
        elif depth:
            i += 1
        elif s.startswith('--', i):
            i = s.find('\n', i)
            if i < 0:
                break
        else:
            out.append(s[i])
            i += 1
    require(depth == 0, 'balanced Lean comments')
    return ''.join(out)


code = strip_comments(ch)
independent = strip_comments((R / 'IndependentChallenge.lean').read_text())
require(code == independent, 'independently approved exact Challenge code')
names = re.findall(r'(?m)^theorem\s+(\w+)', code)
require(len(names) == len(set(names)) == 25, '25 unique contracts')
require(len(re.findall(r'(?m)^\s+sorry\s*$', code)) == 25,
        '25 intentional statement placeholders')
require(not re.search(r'\b(sorry|admit)\b', strip_comments(defs)),
        'no placeholder in transparent definitions')
require(not re.search(r'(?m)^\s*(axiom|opaque|unsafe)\b', code + '\n' + defs),
        'no custom axiom, opaque target or unsafe declaration')
config = readj(R / 'reviewed/comparator.json')
require(config['theorem_names'] == ['NLA.MF18.' + n for n in names],
        'complete exact Comparator coverage')
require(config['definition_names'] == [], 'definition configuration')
require(config['permitted_axioms'] == ['propext', 'Quot.sound', 'Classical.choice'],
        'standard permitted axiom list')
require('Filter.Tendsto X (nhdsWithin 0 (Set.Ioi 0)) (nhds X₀)' in defs,
        'literal original right limit')
require('unregularizedPolynomial C R ≠ 0' in defs, 'literal regularity')
require('(hermitianImaginaryPart X₀).rank = m' in code,
        'literal original final rank')
require(not (P / 'candidate/Solution.lean').exists(),
        'no solution in reviewed statement packet')

receipt = readj(R / 'evidence/local288-RECEIPT.json')
require(sha(R / 'evidence/local288-RECEIPT.json') == sha(P / 'run/RECEIPT.json'),
        'retained actual receipt identity')
require(receipt['platform'] == 'darwin', 'actual local platform')
require(receipt['threads'] == receipt['max_compiler_processes'] == 1,
        'serial local compiler limits')
require(receipt['memory_cap_mib'] == 4096, 'memory cap')
require(receipt['failed_modules'] == [] and receipt['blocked_modules'] == [],
        'local288 terminal result')
require(receipt['count_change'] == 0, 'local statement run count')
require(receipt['assembly_sha256'] == sha(P / 'ASSEMBLY-288.json'),
        'actual source assembly binding')
commands = {x['module']: x for x in receipt['commands']
            if x['module'].startswith('NLA.MF18.')}
require(set(commands) == {'NLA.MF18.Definitions', 'NLA.MF18.Challenge'},
        'exact two fresh MF18 module records')
for name, rel, log in [
        ('NLA.MF18.Definitions', 'NLA/MF18/Definitions.lean', 'Definitions.log'),
        ('NLA.MF18.Challenge', 'Challenge.lean', 'Challenge.log')]:
    c = commands[name]
    require(c['exit_code'] == 0 and c['elapsed_seconds'] > 0,
            'actual fresh successful record ' + name)
    require(c['source_sha256'] == scope['candidate_files'][rel],
            'executed exact source ' + name)
    require('--threads=1' in c['argv'] and '--memory=4096' in c['argv'],
            'actual invocation flags ' + name)
    require(c['log_sha256'] == sha(R / 'evidence' / log),
            'full raw log binding ' + name)
require(commands['NLA.MF18.Challenge']['dependency_olean_sha256'] == {
    'NLA.MF18.Definitions': commands['NLA.MF18.Definitions']['output_sha256']},
    'fresh Definitions output used for Challenge')
require((R / 'evidence/Definitions.log').read_bytes() == b'',
        'clean definitions log')
lines = (R / 'evidence/Challenge.log').read_text().splitlines()
require(len(lines) == 25 and all('warning: declaration uses `sorry`' in x for x in lines),
        'exact expected 25 placeholder warnings only')
elab = readj(R / 'evidence/ELABORATION.json')
require(elab['actual_local_run'] == 288 and elab['proof_count'] == 0
        and elab['statement_count'] == 25, 'root statement-only execution scope')
require(elab['actual_receipt_sha256'] == sha(R / 'evidence/local288-RECEIPT.json'),
        'root elaboration receipt binding')
require(scope['reviewer_executions'] ==
        {'Lean': 0, 'Lake': 0, 'Comparator': 0, 'GitHub_workflow': 0},
        'no invented reviewer execution')
require(verdict['decision'] == 'APPROVE_EXACT_ELABORATED_STATEMENT_BOUNDARY'
        and verdict['mathematical_blockers'] == [], 'statement-only verdict')
require(verdict['proof_approval'] is False and verdict['publication_approval'] is False
        and verdict['count_change'] == 0, 'no full verification/publication count claim')
require(verdict['approved_candidate_files'] == scope['candidate_files'],
        'verdict exact source binding')
if (R / 'MANIFEST.json').exists():
    inventory(R, sha(R / 'MANIFEST.json'))
print(json.dumps({'result': 'PASS', 'checks': checks, 'live': args.live,
                  'scope': 'Read-only integrity, exact syntax delta, contract coverage and retained root execution evidence; no proof checking.',
                  'draft_payloads': nd, 'elaboration_payloads': np,
                  'reviewed_contracts': len(names), 'Lean_runs_by_this_verifier': 0,
                  'Comparator_runs_by_this_verifier': 0, 'count_change': 0}, indent=2))
