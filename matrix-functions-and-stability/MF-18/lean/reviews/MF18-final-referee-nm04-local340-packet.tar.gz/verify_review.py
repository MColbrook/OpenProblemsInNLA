#!/usr/bin/env python3
"""Read-only evidence replay; never starts Lean/Lake/Comparator/Git or a workflow."""
import argparse
import hashlib
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--campaign-root", type=Path,
                    default=Path("/private/tmp/nla-lean-next-20260915"))
parser.add_argument("--live", action="store_true")
parser.add_argument("--require-sealed", action="store_true")
args = parser.parse_args()
B = args.campaign_root.resolve()
R = Path(__file__).resolve().parent
checks = 0


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(condition, label):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def strip_comments(source):
    # Nested block comments and line comments, for the lexical guard only.
    out, i, depth = [], 0, 0
    while i < len(source):
        if source.startswith("/-", i):
            depth += 1
            i += 2
        elif depth and source.startswith("-/", i):
            depth -= 1
            i += 2
        elif depth:
            i += 1
        elif source.startswith("--", i):
            end = source.find("\n", i)
            i = len(source) if end < 0 else end
        else:
            out.append(source[i])
            i += 1
    return "".join(out)


scope = read(R / "SCOPE.json")
verdict = read(R / "VERDICT.json")
S = B / scope["source_snapshot"]
P = S / "candidate"
check(sha(S / "MANIFEST.json") == scope["snapshot_manifest_sha256"], "snapshot manifest identity")
for row in read(S / "MANIFEST.json")["files"]:
    check(sha(S / row["path"]) == row["sha256"], "snapshot payload: " + row["path"])
    check((S / row["path"]).stat().st_size == row["bytes"], "snapshot payload size")
for record, hash_key in [(scope["local_complete_record"], "local_complete_record_sha256"),
                         (scope["type_diagnostic_record"], "type_diagnostic_record_sha256")]:
    check(sha(B / record) == scope[hash_key], "root actual evidence record")
complete = read(B / scope["local_complete_record"])
diag = read(B / scope["type_diagnostic_record"])
freeze_path = B / "MF18-STATEMENT-FREEZE-local288.json"
check(sha(freeze_path) == scope["statement_freeze_sha256"], "statement freeze")
freeze = read(freeze_path)
check(not freeze["proof_implementation_started_before_gate"], "statement-first recorded order")
check(freeze["frozen_files"] == scope["all_frozen_inputs"], "complete frozen boundary")
for rel, expected in freeze["frozen_files"].items():
    check(sha(P / rel) == expected, "unchanged frozen input")
for rel, expected in scope["canonical_sources"].items():
    check(sha(B / rel) == expected, "canonical source binding")
for rel, expected in scope["standards"].items():
    check(sha(B / rel) == expected, "pinned review rubric")
check(complete["sources"] == scope["all_38_sources_read"], "reviewed source map")
check(len(complete["sources"]) == 38, "full 38-source closure")
texts = {}
for rel, expected in complete["sources"].items():
    check(sha(P / rel) == expected, "proof source identity")
    if args.live:
        check(sha(B / "next-proofs/MF-18" / rel) == expected, "optional live source identity")
    texts[rel] = (P / rel).read_text()
    check(not re.search(r"\b(?:sorry|admit|axiom|unsafe|native_decide)\b", strip_comments(texts[rel])),
          "no lexical forbidden proof escape: " + rel)
cfg = read(P / "comparator.json")
names = cfg["theorem_names"]
check(names == freeze["contract_names"] == scope["all_25_contracts_read"], "exact 25-name boundary")
check(len(names) == len(set(names)) == 25, "25 distinct exports")
check(cfg["definition_names"] == [], "no definition substitutions")
allowed = {"propext", "Classical.choice", "Quot.sound"}
check(set(cfg["permitted_axioms"]) == allowed, "standard permitted axioms")
challenge = (P / "Challenge.lean").read_text()
check(len(re.findall(r"\bsorry\b", strip_comments(challenge))) == 25, "intentional Challenge placeholders")
for name in names:
    pattern = r"^theorem\s+" + re.escape(name.split(".")[-1]) + r"\b[\s\S]*?(?=\s*:=\s*by)"
    c = re.search(pattern, challenge, re.M)
    found = [m.group().rstrip() for t in texts.values() if (m := re.search(pattern, t, re.M))]
    check(bool(c) and found == [c.group().rstrip()], "literal selected header: " + name)
    check(set(complete["observed_axioms"][name]) == allowed, "root actual observed axioms")
check(len(re.findall(r"^#assert_trust kernel ", texts["Solution.lean"], re.M)) == 25,
      "all 25 requested kernel-trust assertions")
check("import Challenge" not in texts["Solution.lean"], "proof target does not import contracts")

def canonical(module):
    return "Solution.lean" if module == "NLA.MF18.Solution" else module.replace(".", "/") + ".lean"


closures = {}


def closure(module):
    if module not in closures:
        rel = canonical(module)
        check(rel in texts, "all project imports in reviewed source scope")
        deps = [x for x in re.findall(r"^import\s+(\S+)", texts[rel], re.M) if x.startswith("NLA.")]
        closures[module] = {module}
        for dep in deps:
            closures[module] |= closure(dep)
    return closures[module]


modules = closure("NLA.MF18.Solution")
check({canonical(m) for m in modules} == set(texts), "complete source import closure")
for path, expected in complete["retained_original_evidence"].items():
    check(sha(Path(path)) == expected, "retained original receipt/log identity")
receipt = read(complete["receipt"])
check(sha(Path(complete["receipt"])) == complete["receipt_sha256"], "actual340 receipt")
check(receipt.get("end") and not receipt["failed_modules"] and not receipt["blocked_modules"],
      "terminal root run succeeded")
check(sha(Path(complete["assembly"])) == complete["assembly_sha256"] == receipt["assembly_sha256"],
      "actual340 assembly binding")
fresh = 0
for origin in complete["commands_and_successful_origins"]:
    module = origin["module"]
    rel = canonical(module)
    latest = next(c for c in receipt["commands"] if c["module"] == module)
    fresh += latest.get("exit_code") == 0
    for i, hop in enumerate(origin["reuse_chain"]):
        path = Path(hop["receipt"])
        check(sha(path) == hop["sha256"], "retained reuse-hop hash")
        node = read(path)
        check(bool(node.get("end")) and node["platform"] == "darwin", "actual local origin platform/end")
        check(node["threads"] == node["max_compiler_processes"] == 1, "serial one-thread provenance")
        check(0 < node["memory_cap_mib"] <= 4096, "local compiler memory limit")
        command = next(c for c in node["commands"] if c["module"] == module)
        check(command["source_sha256"] == complete["sources"][rel], "source matched at every reuse hop")
        check(command["output_sha256"] == latest["output_sha256"], "same successful output reused")
        for dep in closure(module):
            check(node["source_inputs"][dep.replace(".", "/") + ".lean"] == complete["sources"][canonical(dep)],
                  "whole transitive source closure matched at reuse hop")
        if i + 1 < len(origin["reuse_chain"]):
            check(command.get("status") == "reused_exact_successful_local_output", "actual intermediate reuse status")
            check(command.get("prior_receipt") == origin["reuse_chain"][i + 1]["receipt"], "exact prior receipt edge")
            check(command.get("prior_receipt_sha256") == origin["reuse_chain"][i + 1]["sha256"], "prior receipt edge hash")
        else:
            check(command == origin["command"], "actual fresh origin command")
            check(command["exit_code"] == 0, "actual fresh origin exit0")
            check("--threads=1" in command["argv"] and "--memory=4096" in command["argv"], "actual compiler limits")
            log = path.parent / (module + ".log")
            check(sha(log) == command["log_sha256"], "actual full origin log")
            check("error:" not in log.read_text(), "successful origin has no errors; warnings permitted")
entry_log = Path(complete["receipt"]).parent / "NLA.MF18.Solution.log"
observed = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", entry_log.read_text(), re.M)
check([n for n, _ in observed] == names, "actual all25 final export reports")
for name, ax in observed:
    check({x.strip() for x in ax.split(",")} == allowed, "actual final permitted axiom report")

D = B / "MF18-type-diagnostics-341"
for file, key in [("challenge-types.json", "challenge_dump_sha256"),
                  ("solution-types.json", "solution_dump_sha256"),
                  ("certificate-body-route.json", "body_graph_sha256")]:
    check(sha(D / file) == diag[key], "actual diagnostic payload")
crows = read(D / "challenge-types.json")
srows = read(D / "solution-types.json")
check([r["name"] for r in crows] == [r["name"] for r in srows] == names, "both complete diagnostic exports")
for c, s in zip(crows, srows):
    check(c["levelParams"] == s["levelParams"], "independent universe comparison")
    check(c["binderNormalizedType"] == s["binderNormalizedType"], "independent elaborated-type comparison")
check(diag["all25_match"] and not diag["Comparator_executed"], "local comparison scope, not Comparator")
check(sha(Path(diag["receipt"])) == diag["receipt_sha256"], "actual341 receipt")
diag_receipt = read(diag["receipt"])
for command in diag["diagnostic_commands"]:
    check(command in diag_receipt["commands"], "actual diagnostic command in receipt")
    check(command["exit_code"] == 0, "actual diagnostic command success")
    source = D / "sources" / (command["module"].replace(".", "/") + ".lean")
    check(sha(source) == command["source_sha256"], "actual diagnostic source identity")
    log = Path(diag["receipt"]).parent / (command["module"] + ".log")
    check(sha(log) == command["log_sha256"], "actual diagnostic log identity")
graph_rows = read(D / "certificate-body-route.json")
graph = {r["name"]: r for r in graph_rows}
check(len(graph) == len(graph_rows) == diag["body_graph_nodes"], "complete unique body graph")
for name, route in diag["actual_elaborated_body_routes"].items():
    check(route[0] == "NLA.MF18.canonical_full_complex_rank", "actual final theorem is consumption root")
    for a, b in zip(route, route[1:]):
        check(graph[a]["hasBody"] and b in graph[a]["bodyConstants"], "actual elaborated proof-body dependency")
check(diag["actual_elaborated_body_routes"]["final_to_kernel_checked_bound"][-1] ==
      "LeanCert.Validity.verify_strict_upper_bound_dyadic_checked", "consumed real kernel-checked certificate")
# Bind the unchanged full-review history and inspect the complete successor delta.
for key, hash_key in [("baseline_review_manifest", "baseline_review_manifest_sha256"),
                      ("cleanup_manifest", "cleanup_manifest_sha256")]:
    mp = Path(scope[key])
    check(sha(mp) == scope[hash_key], "historical packet manifest")
    hist = read(mp)
    actual = {str(p.relative_to(mp.parent)) for p in mp.parent.rglob("*") if p.is_file() and p != mp}
    check(actual == {row["path"] for row in hist["files"]}, "historical packet complete inventory")
    for row in hist["files"]:
        check(sha(mp.parent / row["path"]) == row["sha256"], "historical payload")
base_review = Path(scope["baseline_review_manifest"]).parent
base_scope = read(base_review / "SCOPE.json")
base = B / base_scope["source_snapshot"] / "candidate"
cleanup = Path(scope["cleanup_manifest"]).parent
changes = read(cleanup / "CHANGES.json")
changed = {row["path"]: row for row in changes["changed_files"]}
check(len(changed) == 17, "complete17-file source delta")
for rel, expected in complete["sources"].items():
    if rel in changed:
        check(sha(base / rel) == changed[rel]["before_sha256"] == sha(cleanup / "before" / rel), "exact before source")
        check(sha(P / rel) == changed[rel]["after_sha256"] == sha(cleanup / "after" / rel), "exact after source")
        if changed[rel]["kind"] == "comments only":
            check(" ".join(strip_comments((base / rel).read_text()).split()) ==
                  " ".join(strip_comments((P / rel).read_text()).split()), "only comments changed")
    else:
        check(sha(P / rel) == sha(base / rel), "all remaining proof sources unchanged")
    check(re.findall(r"^import .*", (base / rel).read_text(), re.M) ==
          re.findall(r"^import .*", (P / rel).read_text(), re.M), "project imports unchanged")
comments = read(cleanup / "COMMENTS.json")
check(len(comments["sites"]) == comments["count"] == 29, "29 adjacent bridge explanations")
for row in comments["sites"]:
    text = (P / row["file"]).read_text()
    check(row["comment"] in text, "exact explanation present")
    comment_end = text.index(row["comment"]) + len(row["comment"])
    check(text[comment_end:].lstrip().startswith(row["site"].lstrip("· ")), "explanation directly adjacent to bridge")
for file in ["BoundaryNonvanishing", "UnitPencilKernel"]:
    text = (P / f"NLA/MF18/{file}.lean").read_text()
    check("using Matrix.isHermitian_add_transpose_self (lam • C.conjTranspose)" in text,
          "direct existing Hermitian-sum theorem")
    check("hstarinv" not in text, "duplicated adjoint expansion removed")
check("exact pencil_factorization C C.conjTranspose R X hX heq z" in
      texts["NLA/MF18/UnregularizedFactorization.lean"], "unregularized generic matrix specialization")
check("exact pencil_polynomial_factorization C C.conjTranspose R X hX heq" in
      texts["NLA/MF18/UnregularizedFactorization.lean"], "unregularized generic polynomial specialization")
check("exact pencil_factorization (regularizedA C D η) (regularizedB C D η)" in
      texts["NLA/MF18/PencilAlgebra.lean"], "regularized generic matrix specialization")
check("exact pencil_polynomial_factorization (regularizedA C D η) (regularizedB C D η)" in
      texts["NLA/MF18/SolutionPolynomial.lean"], "regularized generic polynomial specialization")
for rel, expected in complete["sources"].items():
    key = "NLA/MF18/Solution.lean" if rel == "Solution.lean" else rel
    check(diag_receipt["source_inputs"][key] == expected, "diagnostic full current proof closure")
check(diag_receipt["source_inputs"]["NLA/MF18/Challenge.lean"] == sha(P / "Challenge.lean"),
      "diagnostic exact frozen contracts")
check(fresh == 28 and len(modules) - fresh == 10, "actual28fresh10matchedreuse")
check(verdict["overall"] == "approve" and verdict["mathematical_source_verdict"] == "approve",
      "precise mathematical/code disposition")
check(verdict["reviewer_Lean_runs"] == verdict["reviewer_Comparator_runs"] == 0, "no reviewer compiler fiction")
check(verdict["count_increment"] == 0, "no final acceptance/count")
manifest_path = R / "MANIFEST.json"
if args.require_sealed:
    check(manifest_path.exists(), "review manifest sealed")
if manifest_path.exists():
    manifest = read(manifest_path)
    actual = {str(p.relative_to(R)) for p in R.rglob("*") if p.is_file() and p != manifest_path}
    check(actual == {r["path"] for r in manifest["files"]}, "complete review packet coverage")
    for row in manifest["files"]:
        check(sha(R / row["path"]) == row["sha256"], "sealed review payload")
print(json.dumps({"status": "PASS", "checks": checks, "scope": "Read-only source/evidence integrity replay; not another Lean/Comparator run",
                  "contracts": 25, "sources": 38, "actual340_fresh": fresh,
                  "actual340_source_matched_reuse": 38 - fresh, "current_sources_checked": args.live,
                  "mathematical_verdict": "approve", "overall_verdict": "approve",
                  "reviewer_compiler_executions": 0, "count_increment": 0}, indent=2))
