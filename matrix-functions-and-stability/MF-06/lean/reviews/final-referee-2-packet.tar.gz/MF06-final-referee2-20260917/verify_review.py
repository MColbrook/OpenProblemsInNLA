#!/usr/bin/env python3
"""Read-only replay of this referee's source/evidence binding; does not run Lean."""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path(
        "/private/tmp/nla-lean-next-20260915/next-proofs/MF-06"))
    parser.add_argument("--repository", type=Path, default=Path(
        "/Users/georgestepaniants/Research/OpenProblemsInNLA"))
    args = parser.parse_args()
    p = args.project
    base = Path("/private/tmp/nla-lean-next-20260915")
    record_path = base / "MF06-LOCAL-COMPLETE-268.json"
    assert sha(record_path) == "7c138cd627b595aa7e18c625cc39b73a673ed0434d6020664d77d769b2cdeaa6"
    record = read(record_path)
    closures, sources = {}, {}

    def closure(rel):
        if rel in closures:
            return closures[rel]
        text = (p / rel).read_text()
        deps = []
        for line in re.findall(r"^import\s+([^\n]+)", text, re.M):
            for module in line.split():
                dep = module.replace(".", "/") + ".lean"
                if (p / dep).is_file():
                    deps.append(dep)
        result = {rel}
        for dep in deps:
            result |= closure(dep)
        closures[rel] = result
        sources[rel] = sha(p / rel)
        return result

    allfiles = closure("Solution.lean")
    assert len(allfiles) == 119
    assert sources == record["sources"]
    assert "Challenge.lean" not in allfiles
    freeze_path = p / "STATEMENT-FREEZE.json"
    assert sha(freeze_path) == "0acb781d89b640a5e1cc8e5a85e9611567e268db34e69a3ef7f2b4bb8085777c"
    freeze = read(freeze_path)
    for rel, digest in freeze["source_sha256"].items():
        assert sha(p / rel) == digest, rel
    for rel in allfiles:
        assert sha(base / "MF06-local268-source-snapshot" / rel) == sources[rel], rel
        assert not re.search(
            r"\b(sorry|admit|axiom|unsafe|native_decide|sorryAx|implemented_by|extern)\b",
            (p / rel).read_text()), rel

    config = read(p / "comparator.json")
    headers = read(p / "STATEMENT-HEADERS.json")["headers"]
    assert [h["declaration"] for h in headers] == config["theorem_names"]
    assert len(headers) == 38 and config["definition_names"] == []
    assert set(config["permitted_axioms"]) == {"propext", "Quot.sound", "Classical.choice"}
    for header in headers:
        short = header["declaration"].split(".")[-1]
        found = []
        for rel in allfiles:
            text = (p / rel).read_text()
            match = re.search(r"(?m)^theorem " + re.escape(short) + r"\b", text)
            if match:
                actual = text[match.start():text.index(":= by", match.start())].rstrip()
                assert actual == header["header"], (rel, short)
                assert hashlib.sha256(actual.encode()).hexdigest() == header["header_sha256"]
                found.append(rel)
        assert len(found) == 1, (short, found)

    pins = read(p / "REUSE-SOURCE-PINS.json")
    for rel, digest in pins["git_bytes_matched"].items():
        assert sha(p / rel) == digest, rel
        data = subprocess.check_output([
            "git", "-C", str(args.repository), "show",
            pins["published_commit"] + ":matrix-functions-and-stability/MF-05/lean/" + rel])
        assert hashlib.sha256(data).hexdigest() == digest, rel
    for rel in ["README.md", "solution.md"]:
        data = subprocess.check_output([
            "git", "-C", str(args.repository), "show",
            "3923b68ecee13d02e732085a57b42a2e7e95ac7a:matrix-functions-and-stability/MF-06/" + rel])
        assert data == (p / "source-inputs/canonical" / rel).read_bytes(), rel
    inputs = read(p / "SOURCE-INPUTS.json")["files"]
    for item in inputs:
        assert sha(p / item["path"]) == item["sha256"], item["path"]

    receipt_cache = {}

    def receipt(path):
        path = str(path)
        if path not in receipt_cache:
            receipt_cache[path] = read(path)
        return receipt_cache[path]

    for path, digest in record["retained_original_evidence"].items():
        assert sha(path) == digest, path
        if Path(path).name == "RECEIPT.json":
            receipt(path)
    terminal_path = record["receipt"]
    terminal = receipt(terminal_path)
    assert not terminal["failed_modules"] and not terminal["blocked_modules"]
    assert terminal["completed_modules"] == 119
    assert terminal["threads"] == 1 and terminal["max_compiler_processes"] == 1
    assert terminal["memory_cap_mib"] == 4096
    assert terminal["source_inputs"] == sources
    assert sha(terminal_path) == record["receipt_sha256"]
    assert sha(record["assembly"]) == record["assembly_sha256"]
    output_hashes = {c["module"]: c["output_sha256"] for c in terminal["commands"]}
    fresh_origins = 0
    legacy_embedded_hops = 0
    for initial in terminal["commands"]:
        module = initial["module"]
        rel = module.replace(".", "/") + ".lean"
        command, path, visited = initial, terminal_path, set()
        while command.get("status") == "reused_exact_successful_local_output":
            assert command["source_sha256"] == sources[rel], module
            if "transitive_source_hashes" in command:
                assert command["transitive_source_hashes"] == {
                    f: sources[f] for f in closures[rel]}, module
            if "prior_receipt" in command:
                prior_path = command["prior_receipt"]
                assert prior_path not in visited
                visited.add(prior_path)
                assert sha(prior_path) == command["prior_receipt_sha256"], prior_path
                prior = [c for c in receipt(prior_path)["commands"] if c["module"] == module]
                assert len(prior) == 1
                prior = prior[0]
            else:
                # Early successful cache receipts embed the original command.
                # Locate and require its exact equality with a retained real fresh receipt.
                legacy_embedded_hops += 1
                embedded = command["prior_command"]
                matches = [(rp, c) for rp, rr in receipt_cache.items()
                           for c in rr["commands"]
                           if c.get("module") == module and c == embedded
                           and c.get("exit_code") == 0]
                assert matches, module
                prior_path, prior = matches[0]
            assert command["output_sha256"] == prior["output_sha256"], module
            command, path = prior, prior_path
        assert command["exit_code"] == 0 and command["source_sha256"] == sources[rel], module
        assert "--threads=1" in command["argv"], module
        memory = [int(x.split("=", 1)[1]) for x in command["argv"] if x.startswith("--memory=")]
        assert len(memory) == 1 and 0 < memory[0] <= 4096, module
        log = Path(path).parent / (module + ".log")
        assert sha(log) == command["log_sha256"], module
        for dep, digest in command["dependency_olean_sha256"].items():
            assert output_hashes[dep] == digest, (module, dep)
        fresh_origins += 1
    log = (Path(terminal_path).parent / "Solution.log").read_text()
    permitted = set(config["permitted_axioms"])
    for name in config["theorem_names"]:
        matches = re.findall("'" + re.escape(name) + "' depends on axioms: \\[(.*?)\\]", log)
        assert len(matches) == 1, name
        assert set(matches[0].split(", ")) <= permitted, name

    diagnostic = base / "MF06-type-diagnostics-270"
    comparison = read(diagnostic / "COMPARISON.json")
    assert sha(diagnostic / "COMPARISON.json") == "3ffb62cff222c6bfc6df5139c44cf43ce5f0e5519f1db22ccc3bcbffdba9bbd5"
    assert comparison["source_complete_record_sha256"] == sha(record_path)
    assert sha(comparison["receipt"]) == comparison["receipt_sha256"]
    diag_receipt = receipt(comparison["receipt"])
    assert not diag_receipt["failed_modules"] and not diag_receipt["blocked_modules"]
    for side in ["challenge", "solution"]:
        assert sha(diagnostic / (side + "-types.json")) == comparison[side + "_dump_sha256"]
    left = read(diagnostic / "challenge-types.json")
    right = read(diagnostic / "solution-types.json")
    assert [row["name"] for row in left] == config["theorem_names"]
    assert [row["name"] for row in right] == config["theorem_names"]
    for a, b in zip(left, right):
        assert a["levelParams"] == b["levelParams"]
        assert a["binderNormalizedType"] == b["binderNormalizedType"]
    consumption = read(diagnostic / "CERTIFICATE-CONSUMPTION.json")
    assert sha(diagnostic / "certificate-body-route.json") == consumption["body_dump_sha256"]
    bodies = {row["name"]: row["bodyConstants"]
              for row in read(diagnostic / "certificate-body-route.json")}
    for route in consumption["actual_consumption_paths"]:
        for first, second in zip(route, route[1:]):
            assert second in bodies[first], (first, second)
    assert "LeanCert.Validity.verify_strict_upper_bound_dyadic_checked" in bodies[
        "NLA.MF05.half_radius_certificate"]

    print(json.dumps({
        "verdict": "PASS",
        "scope": "Independent read-only source and retained local-evidence replay; no Lean or Comparator invoked",
        "proof_closure_files": len(allfiles),
        "frozen_contracts": len(headers),
        "published_reuse_files_git_matched": len(pins["git_bytes_matched"]),
        "canonical_git_blobs_matched": 2,
        "source_input_hashes_checked": len(inputs),
        "retained_evidence_hashes_checked": len(record["retained_original_evidence"]),
        "successful_fresh_origins_retraced": fresh_origins,
        "legacy_embedded_hops_grounded_in_fresh_receipts": legacy_embedded_hops,
        "local_elaborated_type_matches": len(left),
        "actual_body_certificate_paths": len(consumption["actual_consumption_paths"]),
        "github_comparator": "not run/reviewed by this referee",
        "count_change": 0
    }, indent=2))


if __name__ == "__main__":
    main()
