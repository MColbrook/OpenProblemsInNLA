#!/usr/bin/env python3
"""Read-only statement-review integrity checks; does not run Lean or prove mathematics."""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
EXPECTED_DRAFT = 'f37bf9237fb7a3dbff8d917597d39d549e69ce14640f326e7b38b254dbd40c21'
CHECKS = 0

def check(condition, description):
    global CHECKS
    if not condition:
        raise AssertionError(description)
    CHECKS += 1

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def header(text, name):
    found = re.search(r'^theorem\s+' + re.escape(name) + r'\b[\s\S]*?(?= := by)', text, re.M)
    check(found is not None, 'header exists: ' + name)
    return found.group()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-current', action='store_true',
                        help='also compare the live reviewed draft and local177 records read-only')
    args = parser.parse_args()
    manifest = read_json(ROOT / 'MANIFEST.json')
    payloads = manifest['payloads']
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and str(p.relative_to(ROOT)) not in ('MANIFEST.json', 'VERIFICATION.json')
              and '__pycache__' not in p.parts}
    expected = set(payloads)
    check(actual == expected, 'sealed payload inventory')
    for rel, value in payloads.items():
        p = ROOT / rel
        check(not p.is_symlink() and p.is_file(), 'regular payload ' + rel)
        check(digest(p.read_bytes()) == value, 'payload hash ' + rel)

    draft = ROOT / 'snapshot/draft'
    raw = (draft / 'MANIFEST.json').read_bytes()
    check(digest(raw) == EXPECTED_DRAFT, 'exact original statement-draft manifest')
    original = json.loads(raw)
    check(len(original['payloads']) == 81, '81 author-sealed input payloads')
    for rel, value in original['payloads'].items():
        check(digest((draft / rel).read_bytes()) == value, 'original payload ' + rel)

    challenge = (draft / 'Challenge.lean').read_text()
    definitions = (draft / 'NLA/MF06/Definitions.lean').read_text()
    names = re.findall(r'^theorem\s+(\w+)\b', challenge, re.M)
    definition_names = re.findall(r'^(?:def|abbrev)\s+(\w+)\b', definitions, re.M)
    check(len(names) == 38 and len(set(names)) == 38, 'all 38 unique obligations')
    check(len(definition_names) == 37, 'all 37 new definitions/abbreviations')
    check(len(re.findall(r'^  sorry$', challenge, re.M)) == 38, 'intentional Challenge placeholders only')
    check(not re.search(r'^(?:theorem|lemma|axiom|opaque)\s', definitions, re.M), 'new file is definitions only')
    check(not (draft / 'Solution.lean').exists(), 'no proof implementation in reviewed draft')
    ids = [f'C{i:02d}' for i in range(1, 39)]
    headers = read_json(draft / 'STATEMENT-HEADERS.json')['headers']
    check(len(headers) == 38, 'header inventory covers all 38')
    contracts = read_json(ROOT / 'CONTRACT-AUDIT.json')
    check([x['id'] for x in contracts] == ids, 'independent decisions cover all contracts')
    comparator = read_json(draft / 'comparator.json')
    expected_names = ['NLA.MF05.' + x for x in names[:4]] + ['NLA.MF06.' + x for x in names[4:]]
    check(comparator['theorem_names'] == expected_names, 'Comparator names match reviewed contracts')
    check(comparator['definition_names'] == [], 'no prospective definition replacement permissions')
    check(comparator['permitted_axioms'] == ['propext', 'Quot.sound', 'Classical.choice'], 'standard permitted axioms')
    for i, item in enumerate(headers):
        h = header(challenge, names[i])
        check(item['id'] == ids[i] and item['declaration'] == expected_names[i], 'contract identity ' + ids[i])
        check(item['header'] == h and item['header_sha256'] == digest(h.encode()), 'literal header ' + ids[i])
        check(contracts[i]['header_sha256'] == digest(h.encode()), 'review binds header ' + ids[i])
        check(contracts[i]['decision'] == 'approve-statement-only', 'scope of decision ' + ids[i])
    for i, module in enumerate(('Numerical', 'Hausdorff', 'RootLimit', 'Scaling')):
        old = (draft / ('source-inputs/reuse/NLA/MF05/' + module + '.lean.txt')).read_text()
        check(header(challenge, names[i]) == header(old, names[i]), 'exact existing implementation header ' + names[i])

    verdict = read_json(ROOT / 'VERDICT.json')
    check(verdict['decision'] == 'APPROVE_STATEMENTS_ONLY', 'verdict limited to statements')
    check(verdict['new_complete_targets'] == 0, 'no count increment')
    check(verdict['reviewer_compiler_invocations'] == 0, 'no reviewer compiler claim')
    check(verdict['reviewer_comparator_invocations'] == 0, 'no reviewer Comparator claim')
    check(verdict['statement_author'] != verdict['reviewer'], 'nonauthor identities differ')
    check(verdict['frozen_by_this_review'] is False, 'review does not freeze statements')
    check(verdict['proof_approval'] is False, 'review is not proof approval')
    check(verdict['approved_contract_ids'] == ids, 'all contract decisions recorded')
    check(verdict['draft_manifest_sha256'] == EXPECTED_DRAFT, 'verdict binds original draft')

    local = ROOT / 'evidence/local177'
    receipt = read_json(local / 'RECEIPT.json')
    check(receipt['completed_modules'] == 6 and not receipt['failed_modules'] and not receipt['blocked_modules'], 'root local177 terminal success')
    check(bool(receipt['end']), 'root actual run ended')
    check(receipt['max_compiler_processes'] == 1 and receipt['threads'] == 1 and receipt['memory_cap_mib'] == 4096, 'local compiler limits')
    for rel, value in receipt['source_inputs'].items():
        check(digest((local / ('source/' + rel + '.txt')).read_bytes()) == value, 'local source ' + rel)
    check(receipt['source_inputs']['Challenge.lean'] == digest((draft / 'Challenge.lean').read_bytes()), 'actual elaborated Challenge matches review')
    check(receipt['source_inputs']['NLA/MF06/Definitions.lean'] == digest((draft / 'NLA/MF06/Definitions.lean').read_bytes()), 'actual elaborated Definitions match review')
    fresh = [x for x in receipt['commands'] if 'exit_code' in x]
    check([x['module'] for x in fresh] == ['NLA.MF06.Definitions', 'Challenge'], 'two actual new elaborations')
    for command in fresh:
        check(command['exit_code'] == 0 and command['argv'][1:3] == ['--threads=1', '--memory=4096'], 'successful bounded root command ' + command['module'])
        check(digest((local / (command['module'] + '.log')).read_bytes()) == command['log_sha256'], 'actual log binding ' + command['module'])
    check((local / 'NLA.MF06.Definitions.log').read_text() == '', 'Definitions log clean')
    warnings = (local / 'Challenge.log').read_text().splitlines()
    check(len(warnings) == 38 and all('warning: declaration uses `sorry`' in x for x in warnings), 'exactly 38 intentional statement placeholders')

    matches = read_json(ROOT / 'evidence/SOURCE-MATCHES.json')
    check(len(matches) == 25, '3 canonical, 11 reused, and 11 API Git comparisons')
    for item in matches:
        if item['role'] == 'canonical':
            rel = item['path'].removeprefix('matrix-functions-and-stability/MF-06/')
            p = ROOT / 'evidence/git/canonical' / rel
        elif item['role'] == 'exact reuse':
            rel = item['path'].removeprefix('matrix-functions-and-stability/MF-05/lean/') + '.txt'
            p = ROOT / 'evidence/git/reuse' / rel
        else:
            p = ROOT / 'evidence/git/mathlib' / (item['path'] + '.txt')
        check(digest(p.read_bytes()) == item['sha256'], 'captured pinned Git source ' + item['path'])
    for command in read_json(ROOT / 'evidence/COMMANDS.json'):
        check(command['argv'][0] in ('git', 'rg'), 'read-only command type')
        check(command['exit_code'] in (0, 1), 'read-only command completed')
        check(digest(command['stdout'].encode()) == command['stdout_sha256'], 'captured command stdout')
    if args.check_current:
        current = Path('/private/tmp/nla-lean-next-20260915/next-statements/MF-06/draft')
        check(digest((current / 'MANIFEST.json').read_bytes()) == EXPECTED_DRAFT, 'live source seal unchanged')
        for rel, value in original['payloads'].items():
            check(digest((current / rel).read_bytes()) == value, 'live reviewed source ' + rel)
        oldrun = Path('/private/tmp/nla-lean-local-shared-20260916/runs/development-177')
        for name in ('RECEIPT.json', 'NLA.MF06.Definitions.log', 'Challenge.log'):
            check((oldrun / name).read_bytes() == (local / name).read_bytes(), 'live root record ' + name)
    print(json.dumps({'status': 'PASS', 'read_only_checks': CHECKS,
                      'scope': 'source integrity and statement-review evidence, not Lean or mathematical proof replay',
                      'check_current': args.check_current, 'complete_target_count_change': 0}))

if __name__ == '__main__':
    main()
