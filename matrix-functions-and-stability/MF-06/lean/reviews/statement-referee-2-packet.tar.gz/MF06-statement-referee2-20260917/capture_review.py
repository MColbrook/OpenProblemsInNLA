#!/usr/bin/env python3
"""Capture a nonauthor statement review. No Lean, Lake, or network execution."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
DRAFT = Path('/private/tmp/nla-lean-next-20260915/next-statements/MF-06/draft')
REPO = Path('/Users/georgestepaniants/Research/OpenProblemsInNLA')
MATHLIB = Path('/Users/georgestepaniants/Research/project/lean-verification/.lake/packages/mathlib')
LOCAL = Path('/private/tmp/nla-lean-local-shared-20260916/runs/development-177')
SNAP = Path('/private/tmp/nla-lean-next-20260915/MF06-local177-statement-snapshot')
EXPECTED = 'f37bf9237fb7a3dbff8d917597d39d549e69ce14640f326e7b38b254dbd40c21'
PIN = '0df444a360eaa60ab8c11dca51a86af692955474'
REUSE = '06b8cf49740205c4b7b0b71ee5c636855fbe26a6'
BASE = '3923b68ecee13d02e732085a57b42a2e7e95ac7a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, data):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), str(p)
    p.write_bytes(data)

def jsave(path, value):
    save(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())

commands = []
def run(argv):
    result = subprocess.run(argv, capture_output=True, check=False)
    commands.append({'argv': argv, 'exit_code': result.returncode,
                     'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
                     'stdout_sha256': sha(result.stdout)})
    return result

assert sha((DRAFT / 'MANIFEST.json').read_bytes()) == EXPECTED
manifest = json.loads((DRAFT / 'MANIFEST.json').read_text())
assert len(manifest['payloads']) == 81
for path, digest in manifest['payloads'].items():
    data = (DRAFT / path).read_bytes()
    assert sha(data) == digest, path
    save('snapshot/draft/' + path, data)
save('snapshot/draft/MANIFEST.json', (DRAFT / 'MANIFEST.json').read_bytes())

source_matches = []
for name in ('README.md', 'solution.md', 'solution.tex'):
    path = 'matrix-functions-and-stability/MF-06/' + name
    result = run(['git', '-C', str(REPO), 'show', BASE + ':' + path])
    assert result.returncode == 0
    expected = (DRAFT / 'source-inputs/canonical' / name).read_bytes()
    assert result.stdout == expected
    save('evidence/git/canonical/' + name, result.stdout)
    source_matches.append({'role': 'canonical', 'commit': BASE, 'path': path,
                           'sha256': sha(expected)})

for src in sorted((DRAFT / 'source-inputs/reuse/NLA').rglob('*.lean.txt')):
    rel = str(src.relative_to(DRAFT / 'source-inputs/reuse'))[:-4]
    path = 'matrix-functions-and-stability/MF-05/lean/' + rel
    result = run(['git', '-C', str(REPO), 'show', REUSE + ':' + path])
    assert result.returncode == 0, path
    assert result.stdout == src.read_bytes(), path
    save('evidence/git/reuse/' + rel + '.txt', result.stdout)
    source_matches.append({'role': 'exact reuse', 'commit': REUSE, 'path': path,
                           'sha256': sha(result.stdout)})

head = run(['git', '-C', str(MATHLIB), 'rev-parse', 'HEAD'])
assert head.returncode == 0 and head.stdout.decode().strip() == PIN
for src in sorted((DRAFT / 'source-inputs/mathlib').rglob('*.lean.txt')):
    rel = str(src.relative_to(DRAFT / 'source-inputs/mathlib'))[:-4]
    result = run(['git', '-C', str(MATHLIB), 'show', PIN + ':' + rel])
    assert result.returncode == 0
    assert result.stdout == src.read_bytes()
    save('evidence/git/mathlib/' + rel + '.txt', result.stdout)
    source_matches.append({'role': 'pinned Mathlib API', 'commit': PIN,
                           'path': rel, 'sha256': sha(result.stdout)})

queries = [
    ['rg', '-n', '-i', 'joint.?spectral.?radius|barabanov|compoundMatrix|critical.*compound|FamilyIrreducible|stableGauge|block_nonresonance', str(MATHLIB / 'Mathlib')],
    ['rg', '-n', 'basis_repr_apply|map_apply_ιMulti_family|map_comp|ofFinEmbEquiv|mul_kronecker_mul|one_kronecker_one',
     str(MATHLIB / 'Mathlib/LinearAlgebra/ExteriorPower/Basis.lean'),
     str(MATHLIB / 'Mathlib/LinearAlgebra/ExteriorPower/Basic.lean'),
     str(MATHLIB / 'Mathlib/Order/Hom/PowersetCard.lean'),
     str(MATHLIB / 'Mathlib/LinearAlgebra/Matrix/Kronecker.lean')],
    ['rg', '-n', '^(def Seminorm.of|structure Seminorm|lemma tendstoUniformlyOn_of_forall_tendsto|noncomputable def equivFin |def Matrix.toLin\x27 |noncomputable def basisFun |def finProdFinEquiv )',
     str(MATHLIB / 'Mathlib/Analysis/Seminorm.lean'),
     str(MATHLIB / 'Mathlib/Topology/UniformSpace/Dini.lean'),
     str(MATHLIB / 'Mathlib/Data/Fintype/EquivFin.lean'),
     str(MATHLIB / 'Mathlib/LinearAlgebra/Matrix/ToLin.lean'),
     str(MATHLIB / 'Mathlib/LinearAlgebra/StdBasis.lean'),
     str(MATHLIB / 'Mathlib/Logic/Equiv/Fin/Basic.lean')],
]
for query in queries:
    result = run(query)
    assert result.returncode in (0, 1)

receipt = json.loads((LOCAL / 'RECEIPT.json').read_text())
assert receipt['end'] and receipt['completed_modules'] == 6
assert not receipt['failed_modules'] and not receipt['blocked_modules']
for src, digest in receipt['source_inputs'].items():
    data = (SNAP / src).read_bytes()
    assert sha(data) == digest
    save('evidence/local177/source/' + src + '.txt', data)
for name in ('RECEIPT.json', 'NLA.MF06.Definitions.log', 'Challenge.log'):
    save('evidence/local177/' + name, (LOCAL / name).read_bytes())
for command in receipt['commands']:
    if 'exit_code' in command:
        assert command['exit_code'] == 0
        assert command['argv'][1:3] == ['--threads=1', '--memory=4096']
        assert sha((LOCAL / (command['module'] + '.log')).read_bytes()) == command['log_sha256']
assert (LOCAL / 'NLA.MF06.Definitions.log').read_text() == ''
assert len((LOCAL / 'Challenge.log').read_text().splitlines()) == 38
assert all('warning: declaration uses `sorry`' in x for x in (LOCAL / 'Challenge.log').read_text().splitlines())

challenge = (DRAFT / 'Challenge.lean').read_text()
pattern = r'^theorem\s+(\w+)\b[\s\S]*?(?= := by)'
headers = re.findall(pattern, challenge, re.M)
assert len(headers) == 38
checked_headers = []
for name, module in [('half_radius_certificate', 'Numerical'),
                     ('spectral_hausdorff_semantics', 'Hausdorff'),
                     ('general_root_limit_semantics', 'RootLimit'),
                     ('positive_scaling_semantics', 'Scaling')]:
    one = re.search(r'^theorem\s+' + name + r'\b[\s\S]*?(?= := by)', challenge, re.M).group()
    text = (DRAFT / ('source-inputs/reuse/NLA/MF05/' + module + '.lean.txt')).read_text()
    two = re.search(r'^theorem\s+' + name + r'\b[\s\S]*?(?= := by)', text, re.M).group()
    assert one == two
    checked_headers.append({'name': 'NLA.MF05.' + name, 'sha256': sha(one.encode()), 'identical': True})

jsave('evidence/COMMANDS.json', commands)
jsave('evidence/SOURCE-MATCHES.json', source_matches)
jsave('evidence/REUSE-HEADERS.json', checked_headers)
jsave('evidence/CAPTURE.json', {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/mf06_statement_referee2', 'author': '/root/ie02_full_referee2',
    'draft_manifest_sha256': EXPECTED, 'draft_payloads': 81,
    'canonical_git_matches': 3, 'reused_git_matches': 11, 'mathlib_api_git_matches': 11,
    'challenge_theorems': 38, 'intentional_placeholders': 38,
    'source_matching_local_elaboration': 'root run177; reviewer did not rerun Lean',
    'reviewer_lean_lake_comparator_executions': 0,
    'read_only_git_and_search_commands': len(commands),
    'count_change': 0,
})
print('Captured 81 draft payloads, pinned canonical/reuse/API bytes, and actual root local177 evidence.')
