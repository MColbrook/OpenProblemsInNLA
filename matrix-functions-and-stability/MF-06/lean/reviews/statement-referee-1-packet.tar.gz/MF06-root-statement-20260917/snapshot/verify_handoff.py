#!/usr/bin/env python3
"""Read-only statement-draft integrity checks; this is NOT Lean typechecking."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COUNT = 0


def check(ok, message):
    global COUNT
    if not ok:
        raise AssertionError(message)
    COUNT += 1


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def raw(rel):
    path = ROOT / rel
    check(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'unsafe path: ' + rel)
    return path.read_bytes()


def data(rel):
    return json.loads(raw(rel))


def text(rel):
    return raw(rel).decode()


def without_comments(source):
    """Remove nested Lean block/line comments for this limited static scan."""
    result = []
    depth = 0
    i = 0
    while i < len(source):
        if source.startswith('/-', i):
            depth += 1
            result.extend('  ')
            i += 2
        elif depth and source.startswith('-/', i):
            depth -= 1
            result.extend('  ')
            i += 2
        elif not depth and source.startswith('--', i):
            end = source.find('\n', i)
            if end == -1:
                end = len(source)
            result.extend(' ' * (end - i))
            i = end
        else:
            result.append(source[i] if not depth or source[i] == '\n' else ' ')
            i += 1
    check(depth == 0, 'unclosed block comment in static source scan')
    return ''.join(result)


def main():
    manifest = data('MANIFEST.json')
    inventory = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    check(inventory - {'MANIFEST.json', 'VERIFICATION.json'} == set(manifest['payloads']),
          'handoff inventory differs')
    for rel, expected in manifest['payloads'].items():
        check(sha(raw(rel)) == expected, 'handoff hash differs: ' + rel)
    check({x for x in inventory if x.endswith('.lean')} ==
          {'NLA/MF06/Definitions.lean', 'Challenge.lean'}, 'new active source scope differs')
    state = data('STATE.json')
    check(state['contract_count'] == 38 and state['published_reuse_contracts'] == 4 and
          state['new_unproved_contracts'] == 34, 'contract scope differs')
    check(state['proof_gate'] == 'closed' and not state['frozen'] and state['statement_approvals'] == [],
          'author must not claim independent approval or freeze')
    check(state['implementation_bodies'] == state['compiler_executions_by_author'] ==
          state['comparator_executions'] == state['count_change'] == 0, 'unperformed work claimed')
    check(sha(raw('NLA/MF06/Definitions.lean')) == state['definitions_sha256'], 'definition boundary differs')
    check(sha(raw('Challenge.lean')) == state['challenge_sha256'], 'challenge boundary differs')
    definitions = text('NLA/MF06/Definitions.lean')
    challenge = text('Challenge.lean')
    definition_code = without_comments(definitions)
    check(not re.search(r'^\s*(?:axiom|theorem|lemma|example)\b', definition_code, re.M),
          'new Definitions contains a proof declaration or custom axiom')
    check(not re.search(r'\bsorry\b|\badmit\b|\bnative_decide\b|:=\s*by\b', definition_code),
          'new Definitions contains a hole or implementation proof')
    check(len(re.findall(r'^  sorry$', challenge, re.M)) == 38, 'Challenge placeholder count differs')
    check(not re.search(r'^import (?:Solution|NLA\.MF06\.(?!Definitions)[A-Za-z])', challenge, re.M),
          'Challenge imports an implementation')
    check(not (ROOT / 'Solution.lean').exists(), 'statement handoff unexpectedly contains Solution')

    headers = data('STATEMENT-HEADERS.json')['headers']
    check(len(headers) == 38 and [h['id'] for h in headers] == [f'C{i:02d}' for i in range(1, 39)],
          'header IDs/count differ')
    extracted = []
    namespace = ''
    for match in re.finditer(r'^namespace ([A-Za-z0-9_.]+)|^theorem ([A-Za-z0-9_]+)', challenge, re.M):
        if match.group(1):
            namespace = match.group(1)
        else:
            start = match.start()
            end = challenge.index(' := by\n  sorry', start)
            extracted.append((namespace + '.' + match.group(2), challenge[start:end],
                              challenge[:start].count('\n') + 1))
    for observed, saved in zip(extracted, headers):
        check(observed == (saved['declaration'], saved['header'], saved['line']), 'header extraction differs')
        check(sha(saved['header'].encode()) == saved['header_sha256'], 'header hash differs')
    check(len(extracted) == 38, 'unexpected theorem count')
    config = data('comparator.json')
    check(config['theorem_names'] == [h['declaration'] for h in headers], 'Comparator coverage differs')
    check(config['definition_names'] == [] and set(config['permitted_axioms']) ==
          {'propext', 'Quot.sound', 'Classical.choice'}, 'prospective trust boundary differs')
    check(config['challenge_module'] == 'Challenge' and config['solution_module'] == 'Solution',
          'prospective module configuration differs')
    old = text('source-inputs/reuse/Challenge-MF05.lean.txt')
    for h in headers[:4]:
        name = h['declaration'].rsplit('.', 1)[1]
        start = old.index('theorem ' + name)
        end = old.index(' := by\n  sorry', start)
        check(old[start:end] == h['header'], 'existing MF05 header changed')
    contract_map = data('CONTRACT-MAP.json')['contracts']
    check([c['declaration'] for c in contract_map] == config['theorem_names'], 'contract map differs')
    check(all(not c['proof_implementation_present'] for c in contract_map), 'implementation wrongly claimed')
    check(headers[-1]['declaration'] == 'NLA.MF06.canonical_pointwise_lower_lipschitz', 'wrong final target')
    final = headers[-1]['header']
    for phrase in ['(hd : 1 ≤ d)', '(hM : IsCompact M)', '(hneM : M.Nonempty)',
                   '∃ r : ℝ, 0 < r ∧ ∃ C : ℝ, 0 < C ∧',
                   '∀ N : Set (Square d), IsCompact N → N.Nonempty →',
                   'canonicalHausdorff M N < r →',
                   'jointSpectralRadius M - C * canonicalHausdorff M N ≤ jointSpectralRadius N']:
        check(phrase in final, 'final target boundary differs: ' + phrase)

    first = data('STATEMENTS-FIRST.json')
    check(sha(raw(first['path'])) == first['sha256'], 'numerical-first sheet changed')
    check(first['new_lean_files_at_record'] == [] and first['no_compiler'] and first['no_proof_bodies'],
          'source-first record differs')
    checkpoint = data('history/checkpoint-01/CHECKPOINT.json')
    check(sha(raw('history/checkpoint-01/Definitions.lean.txt')) ==
          checkpoint['files']['NLA/MF06/Definitions.lean'], 'original checkpoint source not preserved')
    check(sha(raw('source-inputs/precode/MANIFEST.json')) ==
          '993b09ca972bd6909e62fc19ae9690d4ddcfd03ed8b796aea3a353be3b0d08a7', 'pre-code seal differs')
    precode = data('source-inputs/precode/MANIFEST.json')['files']
    inputs = data('SOURCE-INPUTS.json')
    for row in inputs['files']:
        check(sha(raw(row['path'])) == row['sha256'], 'copied source bytes differ')
        check(len(raw(row['path'])) == row['bytes'], 'copied source size differs')
        marker = '/MF-06/precode/'
        if marker in row['source']:
            rel = row['source'].split(marker, 1)[1]
            if rel in precode:
                check(row['sha256'] == precode[rel]['sha256'], 'copied pre-code source not manifest-bound')
    check(inputs['MF05_reuse_commit'] == '06b8cf49740205c4b7b0b71ee5c636855fbe26a6', 'reuse source pin differs')
    prior_raw = raw('source-inputs/reuse/MF05-full-proof-review-manifest.json')
    check(sha(prior_raw) == '9ce7e23fe43444c67e9e5430cbf80e39addb8d220e248e53dd4826c8e494797e',
          'prior complete source review seal differs')
    prior = json.loads(prior_raw)['payloads']
    reused = [r for r in inputs['files'] if r['path'].startswith('source-inputs/reuse/NLA/')]
    check(len(reused) == 11, 'prospective reusable source scope differs')
    for row in reused:
        rel = row['path'][len('source-inputs/reuse/'):]
        check(row['sha256'] == prior['snapshot/final/' + rel], 'reused source differs from full approval')
    pin = data('MATHLIB-API-PIN-CHECK.json')
    check(pin['exit_code'] == 0 and not pin['stdout'] and not pin['stderr'], 'inspected Mathlib APIs modified')
    check(inputs['mathlib_pin_observation']['stdout'].strip() ==
          '0df444a360eaa60ab8c11dca51a86af692955474', 'Mathlib revision differs')
    check(text('lean-toolchain') == 'leanprover/lean4:v4.33.1\n', 'Lean toolchain differs')
    lake = data('lake-manifest.json')
    packages = {p['name']: p['rev'] for p in lake['packages']}
    check(packages['mathlib'] == '0df444a360eaa60ab8c11dca51a86af692955474' and
          packages['leancert'] == '621a43d7cf21f87872392a01e874f2f1dbddc926', 'dependency pins differ')

    metadata = data('formalization.yaml')
    schema = data('SCHEMA-CHECK.json')
    check(schema['exit_code'] == 0 and not schema['stderr'] and 'PASS' in schema['stdout'],
          'actual metadata schema validation not successful')
    check(schema['metadata_sha256'] == sha(raw('formalization.yaml')) and
          schema['schema_sha256'] == sha(raw('source-inputs/standards/v0.4.schema.json')),
          'schema validation not bound to current metadata')
    check(metadata['version'] == '0.4' and metadata['review']['status'] == 'unchecked' and
          metadata['review']['reviewers'] == [], 'draft review status differs')
    check(metadata['status']['main_results'] == [] and not metadata['status']['proof_implementation_started'],
          'draft metadata claims a proof')
    check(metadata['status']['intentional_challenge_placeholders'] == 38 and
          metadata['status']['completed_original_targets'] == 0, 'draft metadata scope differs')
    check([c['declaration'] for c in metadata['alignment']] == config['theorem_names'],
          'metadata contract coverage differs')
    check(metadata['project']['authors'] == ['George Stepaniants'] and
          metadata['project']['affiliation'] ==
          'Department of Computing and Mathematical Sciences, California Institute of Technology',
          'required attribution differs')
    for rel in ['NLA/MF06/Definitions.lean', 'Challenge.lean', 'README.md', 'formalization.yaml']:
        check(not re.search(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', text(rel)), 'new text contains an email')
    print(json.dumps({'result': 'PASS', 'checks': COUNT, 'scope': 'statement draft integrity; NOT Lean typechecking',
                      'contracts': 38, 'new_unproved_contracts': 34, 'existing_reuse_contracts': 4,
                      'compiler_executions': 0, 'comparator_executions': 0,
                      'independent_statement_approvals': 0, 'count_change': 0}, sort_keys=True))


if __name__ == '__main__':
    main()
