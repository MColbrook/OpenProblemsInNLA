# MF-06 transfer helpers: independent bounded source review

Reviewer: `/root/nm04_final_referee1`, 17 September 2026. The six implementation
modules were authored by `/root`. I have not authored or edited any MF-06 Lean
proof, definition, or frozen statement. No compiler or Comparator was run by
this reviewer.

**Approve the exact six reviewed modules and contracts C32, C34, C35 and C36
within their stated scope.** No mathematical correction is required. The single
proof-quality finding was closed by two adjacent explanatory comments, with
unchanged proof tokens and a successful fresh local check of those exact bytes.
This is not acceptance of the complete MF-06 proof. Two independent final
whole-target reviews and the actual Linux checks remain separate requirements.

## Scope and fixed mathematical target

I read all six modules completely: `CompoundRadius`, `CompoundFirstDegree`,
`HausdorffImages`, `CompoundHausdorff`, `HausdorffScaling`, and `RootLowerBound`.
I also read the complete definitions, the word-image and growth-comparison
bridges, the compound-continuity provider, the reused MF05 Hausdorff and scaling
proofs and root-limit interface. The exact retained import closure contains
37 NLA sources. Retaining and authenticating that closure does not mean every
previously reviewed module received a new whole-file mathematical review here;
the precise complete-read list and earlier review references are in `SCOPE.json`.

The six frozen boundary files retain their approved hashes. Each implemented
C32/C34/C35/C36 theorem header agrees **literally** with its frozen header and
with `Challenge.lean`. The canonical README and manuscript still ask for a
pointwise lower Lipschitz estimate for every fixed nonempty compact complex
matrix family, with constants chosen before the arbitrary nearby family.
They include zero reference radius, reducible and infinite compact families,
singular generators, and perturbations that do not preserve invariant subspaces.

The reviewed helpers supply the radius and distance transfer steps of manuscript
sections 5–6. They do not supply the entire critical product-bounded compound
construction or the final assembly. The conservative symbolic constants were
already allowed by the frozen numerical plan N4; N5 explicitly specified the
integer-power scalar transfer, and N6 separated zero-radius normalization.
There is no new narrowing of the original target.

## Correctness and boundary analysis

**C32, radius power bound.** The compound is the literal sorted-minor matrix,
with its exterior-basis and multiplicativity semantics inherited from the
reviewed C17–C20 development. `compoundMonoidHom` proves preservation of one and
multiplication from those results; `compound_word_product` respects the actual
chronological matrix word. For each fixed word length, compact attainment in
the compound image is lifted to an original word, preserving every letter and
its order. The map need not be injective. Thus the norm estimate applies to the
compound of the very same original product, not to independently selected
generators.

For each real `a > rho(M)`, the existing arbitrary-radius envelope supplies
`a > 0` and a bound `K*a^n`. Applying the compound estimate gives the fixed
factor `compoundNormConstant d k * K^k` outside the word-length power, enlarged
to its maximum with one. The base is `(a^k)^n`. The fixed factor is removed using the proved
exponential-envelope radius theorem, and a right-neighborhood limit of the
continuous map `a -> a^k` gives the exact upper bound `rho(M)^k`. No logarithm,
positive-radius assumption, or zero-radius division occurs.

The allowed case `k=0` has a one-dimensional exterior space, identity action,
and `rho(M)^0=1`, including when `rho(M)=0`. The source proof still has a positive
base `a^0=1`; the compound-dimension theorem supplies positive dimension for
every `k<=d`. Empty words are retained in the monoid identity and all-length
growth bound. Degrees greater than `d` are outside this contract's premise,
rather than silently assigned a positive exterior dimension.

**C32, degree-one equality.** `singleton_minor_covers` constructs the actual
singleton ordered embedding for each coordinate, transports it through the
literal subset index and finite enumeration, and cancels the two inverse maps.
Every original matrix entry is therefore an entry of the degree-one compound.
The proof uses the named one-by-one determinant theorem, rather than assuming
the enumeration is the identity permutation. Entry bounds give the fixed
factor `d`, and the same-original-word comparison removes `max(1,d)` at the
radius level. Together with the upper bound at degree one this proves exact
equality. Positive ambient dimension is explicit in C32. The intermediate
entry statement is also coherent at dimension zero, where its universal
entry comparison is vacuous and the spectral norm is zero.

**C34 and its Hausdorff helpers.** The distance is the original maximum of
two sup-inf spectral-norm expressions, identified with the Hausdorff distance
of actual Euclidean operator images by the reused MF05 theorem. The image
helper chooses a nearest generator in the opposite compact nonempty family,
uses its bound by the original Hausdorff distance, and applies the stated
Lipschitz estimate. It repeats this construction in the reverse direction;
the second direction correctly invokes symmetry. It uses the proved Mathlib
matching criterion, with a nonnegative bound, and proves compactness and
nonemptiness of both images.

For the compound specialization, membership in `M union N` provides exactly
the common norm-ball bound needed by C21. Its symbolic Lipschitz constant is
positive under the frozen `1<=k<=d` and `L>0` assumptions. There is no finite
generator restriction and no injectivity requirement on the exterior map.
Zero distance and coinciding generators are included. Degree zero is not
asserted by C34, whose frozen positive-degree premise is used in the final
transfer; it remains covered by C32 where needed.

**C35, positive Hausdorff scaling.** Scalar multiplication is the actual image
map `A -> (c:Complex) • A`. Its difference norm is exactly `c` times the
original norm for `c>0`, giving one inequality through the image helper. The
inverse image under `c^-1` is proved equal to the original family using the
literal scalar product, so applying the same inequality in reverse and
multiplying by the positive `c` gives equality. Only this explicitly positive
scalar is inverted. Neither family's radius is assumed positive. The final
zero-reference-radius case must still be handled by the final theorem before
using a reciprocal radius; C35 does not conceal that obligation.

**C36, root-free lower transfer.** If `u>=1`, `z<=1` suffices. Otherwise
`0<=u<=1` and `k>=1` allow writing `k=n+1`, bounding `u^n<=1`, and multiplying
by the nonnegative `u` to obtain `u^k<=u`. Transitivity proves the exact frozen
conclusion. This covers `u=0`, `u=1`, `z=0`, and `k=1`, using only integer
powers. No root computation, interval subdivision, or spectral computation
is performed. The parameter `hz0` is not needed by this proof of the frozen
contract; its unchanged presence is deliberate and its linter warning is
retained, not suppressed. It does not hide a missing hypothesis or a failed
check.

## Proof quality, reuse, and attribution

The retained Tau Ceti correctness, generality, quality, reuse and attribution
rubrics were applied in the bounded scope. F01 requested comments adjacent to
the two `change` bridges in `CompoundFirstDegree`, explaining the explicit
inverse index maps and the one-coordinate determinant specialization. The
author added exactly those comments. I inspected the diff and independently
checked equality after removing comments; theorem headers and proof tokens
remain unchanged. The final file is SHA-256
`db60dc5dbb17877a7ba1fda9e23cdc09d85f43f5a8a736ab8c66c4d9a42c5348`.
Actual local261 successfully checked it. F01 is closed.

The implementation reuses existing compound algebra/norm bounds, actual word
image lifting, arbitrary-radius exponential envelopes, Mathlib's determinant
and finite-index equivalences, and the canonical Hausdorff identification.
Targeted searches and source inspection located and checked the relevant
Mathlib matching criterion, limit-order theorem, singleton determinant and
subset-index equivalence at the pinned revision. No located library theorem
directly replaces the problem-specific compound or literal canonical-distance
transfer. The constants remain symbolic, outside the word-length exponent;
there is no enumeration of dimensions, words, permutations, or matrix entries
for numerical certification.

George Stepaniants' name, Department of Computing and Mathematical Sciences,
and California Institute of Technology are credited. Existing MF05/MF07 and
Colbrook attribution is retained; the canonical manuscript retains the
Epperlein–Wirth target and cited mathematical background. I did not add or
publish an email address.

## Actual local evidence and limits of this approval

I read each complete successful target-module log and matched its exact source,
receipt, output-file hash, and direct dependency-output bindings. The results
are actual **root-owned local macOS Lean runs**, with one compiler process,
one thread and a 4096 MiB cap. All six final printed declarations have only
`propext`, `Classical.choice`, and `Quot.sound`, with successful kernel trust
assertions. This is evidence inspection, not a second reviewer compilation.

| Module | Successful local run | Scope |
|---|---:|---|
| CompoundRadius | 254 | Compound-radius helper |
| CompoundFirstDegree | 261 | Exact commented C32 |
| HausdorffImages | 256 | General image-Hausdorff transfer |
| CompoundHausdorff | 256 | Exact C34 |
| HausdorffScaling | 259 | Exact C35 |
| RootLowerBound | 255 | Exact C36; retained unused-parameter warning |

These receipts also contain development failures outside the successful
module claims: the earlier degree-one source in 254, HausdorffImages and
CompoundPartition in 255, the earlier scaling source in 256,
GroupedMinorDeterminant in 259, and CompoundLowerTransfer in 261. The receipts
are retained unchanged. None of these whole development runs is described here
as an all-module pass. The final successful sources above supersede only their
own earlier failed versions.

The read-only verifier authenticates the 37-source scope, six unchanged frozen
files, four literal contract headers, six actual successful commands and logs,
comment-only correction, and local resource settings. It launches no compiler,
Comparator, external process, or network call. It is not a replacement for the
mathematical review or a new kernel execution. No MF-06 Linux Comparator run,
whole-target acceptance, publication readiness, or completed-target count
increase is claimed by this packet.
