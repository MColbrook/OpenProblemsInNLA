# Independent early review of MF-06 C17–C23

Reviewer: /root/nm04_final_referee1. I have never authored or edited these MF-06 definitions, statements, proof bodies, or compiler harnesses. This is a limited nonauthor review of four modules and seven contracts; it does not approve the complete MF-06 target. I ran no Lean, Lake, Comparator, or GitHub job.

## Conclusion

No mathematical correctness or statement-alignment blocker was found in the exact C17–C23 sources bound in SCOPE.json. The retained root-run evidence for local214, local217, and local220 is consistent with successful compilation of these seven literal frozen contracts. One narrow proof-quality comment request is recorded below. The completed-original-target count change is zero. The remaining MF-06 contracts, full assembled proof, fresh independent replay, final Linux kernel/Comparator controls, and publication metadata are outside this approval.

## Statement and definition boundary

I read the complete frozen MF06 Definitions, all 38 frozen statement headers, the numerical-target sheet (especially N4), and the imported MF05/MF07 definitions. The spectral norm is the Euclidean continuous-linear operator norm. Compounds are determinants of the actual sorted k-minors, with coordinates supplied by the actual finite-subset equivalence. Tensors are literal Kronecker matrices reindexed by finProdFinEquiv. No proposed result is hidden in a hypothesis or replacement object.

The freeze record binds six original files after two independent statement reviews. This review verifies those hashes and the seven literal theorem headers against the proof source; it does not treat a successful compiler as a semantic review. STATEMENT-HEADERS.json still contains its historical draft-stage label inside the frozen bytes; STATEMENT-FREEZE.json is the later authority. Do not modify this historical record merely to relabel it.

## Mathematical and code assessment

- C17 uses the cardinality of k-element subsets and positivity for k ≤ d. It is valid for d = 0, k = 0, and k > d where the latter has no positivity assertion.
- C18 evaluates the genuine exterior-power map in the standard exterior basis. The dual determinant has transposed coordinates; the proof identifies that transpose explicitly and uses det_transpose, with no missing sign. I inspected the pinned Mathlib exterior basis/dual-coordinate definitions rather than assuming a convention.
- C19 derives identity and multiplicativity through the matrix of the genuine exterior-power map. Degree zero has one coordinate and the empty determinant is one. Degrees above d have no entries; no fictitious positive-dimensional basis is introduced.
- C20 bounds every minor by k! times the kth power of the spectral norm, then applies the already-proved dimension-times-max-entry estimate. The positive constant is choose(d,k) k! for k ≤ d. At k = 0, including d = 0, the RHS uses the conventional zeroth power and correctly bounds the one-dimensional identity.
- C21 proves a finite-product difference bound with an extra factor L, preserving the empty-product induction case. Positive L is cancelled only in the determinant step, and k ≥ 1 justifies k = (k - 1) + 1. Summing symbolically over permutations gives k! k L^(k-1); the compound dimension supplies the remaining factor. Zero differences and singular matrices need no division by a matrix norm.
- C22 reuses Mathlib's Kronecker identity and multiplicativity and the bijective reindexing lemma. The same finite-product equivalence is used on both axes. No positivity hypothesis is needed for the algebraic equalities, including zero-dimensional matrices.
- C23 obtains the upper estimate by entry bounds. For the lower estimate it chooses maximum-modulus entries of both nonempty finite matrices, bounds each operator norm by dimension times that entry, and identifies their product as an actual Kronecker entry. Positivity of m and n is used for the maxima. It never divides by either matrix norm, so zero matrices are retained.

These conservative N4 constants depend on dimension, degree, and the chosen local norm ball; they do not depend on word length. They are therefore compatible with the later planned nth-root limits. The stronger downstream radius statements and the full canonical lower-Lipschitz theorem have not been proved or approved by this limited review.

## Computation, reuse, and readability

No matrix-size, permutation, determinant, interval, or numerical mesh enumeration is performed. The proofs use symbolic finite sums, polynomial/ring identities, and inequalities. Each exported contract prints its axioms and applies LeanCert's kernel trust assertion; no interval certificate is needed for these symbolic helpers. This is not a claim that the final MF06 development's required LeanCert numerical certificate has already been integrated and verified.

The proof bodies reuse the pinned Mathlib determinant bound, exterior basis/map, Kronecker algebra, and existing MF07 Euclidean coordinate/operator bounds. I read the central reused norm helpers and determinant/exterior APIs. Targeted local searches for determinant Lipschitz, norm Kronecker, and product-difference bounds found no direct replacement for the new estimates. The short finite-product norm and maximum-entry helpers have concrete consumers and reuse the generic Finset API. The available Tau Ceti materials here are review rubrics, not a complete TauCeti mathematical source checkout; no exhaustive global duplication claim is made.

All four modules credit George Stepaniants, his department and university, AI assistance, and relevant mathematical/formal sources. I found no George email in the reviewed text. This is not a full future-publication archive privacy audit.

## F01 — narrow proof-quality documentation request

The pinned proof-quality rubric requires an explanation for definitional changes. In the original reviewed bytes, the paired `change` statements in CompoundAlgebra (literal minor/exterior dual determinant), the `change ... at h` in CompoundNorm (complex absolute value and the compound determinant), and the `change` in TensorAlgebra (reindexed Kronecker entry) lacked adjacent explanations.

Requested resolution: add comments explaining the exact frozen wrappers and coordinate convention being expanded. No mathematical or frozen-statement alteration is required. The author has already added suitable comments at the CompoundAlgebra and TensorAlgebra sites during this review; CompoundNorm was requested subsequently. Any later comment-only source approval must be bound separately to its exact bytes and actual run evidence. This is a small proof-quality request, not a correctness blocker or reason to weaken the target.

## Evidence limits

I read all four fresh root-run logs in full: CompoundAlgebra in 214, CompoundNorm and TensorAlgebra in 217, and CompoundLipschitz in 220. They contain the expected seven declarations, each with only propext, Classical.choice, and Quot.sound, without error or warning output. Receipts bind source hashes, dependency output hashes, exact commands, serial execution, one thread, and the 4096 MiB limit.

The replayable Python verifier checks the copied source/statement/log/receipt relationships; it does not invoke a compiler, authenticate GitHub, replay the kernel, or prove mathematics. Root's local executions remain distinct from my inspection. No MF06 Comparator run or completed-target acceptance is asserted.

