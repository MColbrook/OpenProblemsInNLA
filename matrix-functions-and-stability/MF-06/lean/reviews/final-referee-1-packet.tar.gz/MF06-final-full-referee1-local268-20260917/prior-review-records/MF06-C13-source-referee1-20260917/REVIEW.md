# MF06 C13 — independent bounded source review

Reviewer: `/root/nm04_final_referee1`. This reviewer did not author any MF06 proof,
definition, or frozen statement, and did not run Lean, Lake, Comparator, a GitHub
job, or an external Tau Ceti review service. Review date: 17 September 2026.

**Verdict: approve the exact C13 source argument for this bounded review.** No
mathematical or statement-alignment blocker remains. The two requested local
explanatory comments are present. This is not approval of the entire MF06
solution, a completed Comparator check, or an additional verified problem.

## Exact scope

The target is frozen contract C13,
`NLA.MF06.block_nonresonance_product_bounded`. Its literal header hash is
`e15a572027bcb21af4291afe78cb67731e6b4ad01fc56373b8f14fabc61a0a5a`.
`SCOPE.json` binds the six frozen files, all 45 project dependency sources, the
retained original solution/statement, the author guide, and the six pinned Tau
Ceti review documents. All 28 new MF06 modules in this closure were read in
full. Four reused modules were also read in full: MF05 GeneralEnvelope and
RootLimit, and MF07 CompactGrowth and Definitions. The remaining reused modules
are retained and hash-bound for dependency continuity; this bounded task does
not claim a new full human-style review of every reused proof body or Mathlib.
The prior separate C17–C23 review of TensorAlgebra remains applicable.

I compared the original solution's §4 with the frozen definitions and C13
header, then read the word, paired-family, tensor, block-radius, and induction
arguments. The C13 implementation header is byte-identical to its retained
frozen header. The six frozen input hashes are unchanged. This is a textual and
semantic source review; final elaborated-type matching is still a separate
Comparator gate for full MF06.

The theorem concerns an arbitrary compact, nonempty set of complex square
matrices in positive dimension, a surjective finite block labeling, actual
upper-block triangularity, product-bounded diagonal families, and strict
subunit joint spectral radius for every distinct same-generator tensor pair.
It concludes a uniform bound for the spectral norm of every actual word. The
frozen norm is the Euclidean operator norm; product boundedness and joint
spectral radius use the actual family-growth sequence. No finite-generator
assumption, independent tensor switching, or bounded word-length replacement
has been introduced.

## Correctness and alignment findings

1. **The paired word is genuinely paired.** `pairedFamily` is the image of
   `A ↦ tensorMatrix (f A) (g A)` on one original family. `paired_matrixProduct`
   retains the same original chronological list in both factors. Image-word
   lifting chooses preimages letter by letter and does not require an
   injective generator map. The actual radius envelope and tensor-norm
   comparison give a single fixed constant times `q^length(w)`, with
   `0 < q < 1`.
2. **The transition bound has the required separation.** For two positions,
   splitting the original list exposes the same middle subword in both
   factors. The endpoint subwords are already covered by diagonal product
   boundedness, giving `K^4 F q^(j-i-1)`. This legitimate grouping improves the
   informal manuscript's looser constant; it does not change a hypothesis.
   Adjacent positions have the empty middle word. Division is only by the
   chosen positive `q`, never by a possibly zero matrix norm. The scalar
   half-total cut and geometric sum provide a bound independent of word
   length, including the empty list and zero weights.
3. **The off-diagonal estimate controls the literal product.** The chronological
   Duhamel formula is a finite sum over the actual suffix, generator, and
   prefix. Entrywise estimates yield the displayed fixed dimension constants,
   followed by a proved bound on the full spectral norm. Dimension factors
   remain outside the exponential in word length.
4. **Infinite compact families are retained.** Compactness supplies a uniform
   generator entry bound. The maximum over words of a fixed length is taken
   on the compact space `Fin n → M` for the full original `M`, not on a finite
   subset. Images of the block maps remain compact and nonempty. The growth
   and radius comparisons use the existing actual root-limit/envelope
   arguments.
5. **Block regrouping is a coordinate identity.** Binary grouping constructs
   the coordinate bijection and proves the reindexed matrix is exactly the
   required two-block matrix. Leading and final words are proved submatrices
   of the corresponding original words. Tensor compression uses the same
   original generator and explicit fiber coordinates. A grouped leading block
   includes its off-diagonal blocks; it has not been replaced by a diagonal
   family.
6. **The strict grouped radius is proved.** Tensor coordinates are labeled by
   the first original block. The compressed tensor identity and a fixed-factor
   word comparison reduce each diagonal radius to an original distinct-pair
   radius. The finite maximum is strictly below one. C12 supplies the actual
   triangular radius formula; its source argument was also read, including
   diagonal envelopes, similarity damping, and the imported interspersed
   estimate. The reverse inequality uses actual block compression. Zero
   radii are included by the positive-rate limiting argument.
7. **The induction closes all cases.** Zero blocks contradict positive
   dimension and the supplied labeling. One block covers all coordinates.
   The successor case proves every hypothesis for the leading family,
   combines its bound with the last-block bound, and invokes the proved
   grouped paired-radius and binary-family theorems. There is no hidden
   invertibility or nonzero-word-norm premise.

## Quality, generality, and reuse

The pinned Tau Ceti correctness, proof-quality, generality, attribution, and
reuse rubrics were applied within the stated scope. Requested comments now
explain the two fragile definitional bridges: exposing `leadingBlockMap` as a
composite before `Set.image_image`, and expanding that map while preserving
the same chronological list. Both are immediately adjacent to the relevant
`change` commands. The final singleton-label repair proves equality of `Fin`
coordinates explicitly; it is mathematically the same base case and changes
no statement.

The proof uses symbolic list splitting, finite sums, coordinate identities,
and geometric estimates. It introduces no interval grid or enumeration of
dimensions or word lengths. C13 has no new numerical interval obligation;
the separate genuine kernel-mode LeanCert certificate belongs to the C09/C10
route, outside this approval. The C13 module sets `leancert.trust` to kernel
and asserts kernel trust for the exported theorem.

Selected searches of the pinned Mathlib LinearAlgebra and Analysis sources
found no replacement joint-spectral-radius/nonresonance theorem. Existing
block-triangular multiplication, submatrix reindexing, and Kronecker product
identities are reused. This is not an exhaustive claim about every upstream
library lemma. The retained source credits George Stepaniants, Department of
Computing and Mathematical Sciences, California Institute of Technology,
records substantial Codex assistance, and preserves imported authorship.

## Actual local evidence and limits

Root's development run 243 is retained by receipt hash
`e79f952c40f1d77ab4f7b36824c486276bb32fa944e067fb0397a2ebb42f589e`.
The current 45-source C13 closure matches the immutable local243 snapshot.
Within that closure, LeadingWords, LeadingInheritance, and BlockNonresonance
were freshly compiled; 42 modules used exact-source-matched successful local
outputs, as recorded by root's runner. All three fresh full logs were read.
The final C13 command exited zero in 7.439769583987072 seconds. Its printed
axioms are exactly `propext`, `Classical.choice`, and `Quot.sound`. The actual
commands use Lean 4.33.1, one thread, and a 4096 MiB limit.

Run 243 as a whole was **not** successful: the unrelated C29
`AllocationNormBridge` module failed. Earlier runs 239 and 241 also contain
real failures, retained here: map unfolding and a singleton `Fin` instance,
respectively. They are not treated as successful checks. The exact C13
repairs are successful in 243. The author guide's older pending-build wording
is retained as historical context, not substituted for the terminal receipt.

The review verifier checks retained bytes, frozen/header agreement, source
closure, local receipt/log bindings, and the declared scope. It is an ordinary
read-only evidence verifier, not Lean or Comparator, and cannot replace either.
No final Linux C13 Comparator result is claimed. Full MF06 completion, other
contracts, publication readiness, and a campaign count increase are outside
this verdict.
