# MF06 C15 — independent source review

Reviewer: `/root/nm04_final_referee1`, 17 September 2026. I have not authored any
MF06 proof, definition, or frozen statement. I ran no Lean, Lake, Comparator,
or GitHub job. **Approve the exact C15 source argument**, ending in
`IrreducibleFlag.lean` SHA256
`eb751f21aabf7ab5cfe6232a621c9e9415757377c741587a807c32489a305b6d`.
There is no mathematical, alignment, or quality blocker, and no required edit.
This is a bounded C15 approval, separate from the C13 and C29 reviews; full
MF06 and its final Linux verification remain outside this verdict.

## Target and reviewed scope

The frozen C15 theorem `irreducible_flag` starts with only positive dimension
and an arbitrary set `M` of complex matrices. It must construct a number of
blocks between one and `d`, a surjective coordinate labeling, two actual
inverse matrices, upper block triangularity of the conjugated family, and
irreducibility of every literal diagonal family. Its implementation header
is byte-identical to the frozen header with SHA256
`2280af70852c1a2f19dcdd1c908bd4065f60da9aed22c766a936c197a316551a`.
The six statement-first frozen files are unchanged.

I read the full nine-module route: InvariantChain, NestedIndependent,
AdaptedBasis, FlagLabeling, FlagMatrices, FlagCoordinates, FlagQuotient,
FlagIrreducibility, and IrreducibleFlag. I also read BlockCoordinates and the
relevant actual frozen definitions, original solution §5, and frozen
source-correspondence/numerical-plan requirements. All 15 project dependency
sources are retained by hash. The other existing imported bodies are reused,
not newly claimed as fully re-reviewed here. The old planning documents'
unproved/pending wording is historical; actual250 is the subsequent local
proof evidence.

## Mathematical and code findings

1. **The chain is derived, not supplied as an oracle.** The ordered type used
   for saturation consists precisely of the original common invariant
   subspaces. Bottom and top are proved invariant. The finite-dimensional
   submodule orders have both ascending and descending well-foundedness;
   these properties pass to the invariant subtype. The reused Mathlib
   cover-sequence theorem then supplies a finite chain between the endpoints,
   saturated inside that subtype. Strict finrank increase gives `r ≤ d`;
   positive ambient dimension rules out a zero-length chain. Saturation is
   not mistakenly taken in an unrelated family or assumed in C15's header.
2. **The adapted basis is built inside the actual subspaces.** Nested
   independent sets are extended within each increasing flag subspace.
   The terminal set spans the whole space and is linearly independent,
   hence is an actual basis. Its cardinality is proved to be `d` before
   reindexing. Every flag level is spanned by the corresponding subset of
   this same basis. No invariant complement or orthonormal adapted basis is
   assumed.
3. **Labels identify the actual successive quotient dimensions.** A basis
   vector receives its first flag level minus one. A basis vector is nonzero,
   so this level is positive; the top level bounds it by `r`. Membership is
   proved equivalent to the strict prefix-label inequality. If a label were
   missing, two successive spanned prefixes would coincide, contradicting
   strictness. Thus every label occurs, and the final literal fibers have
   positive dimension. The labels need not occupy contiguous coordinates,
   which the frozen definition explicitly permits.
4. **The similarity has the correct direction and two inverses.** Forward
   and backward matrices are the two basis-coordinate maps. Matrix
   composition proves both `Q * R = 1` and `R * Q = 1`. The transformed
   matrix is proved to be exactly `R * A * Q`, matching `conjugateFamily`.
   Its entries are actual basis coefficients of `A(B j)`. Invariance of
   the prefix containing `B j` makes every coefficient at a larger block
   label zero, which is precisely the frozen upper-triangular convention.
5. **The block action really is the quotient action.** The block projection
   extracts the basis coefficients indexed by the frozen fiber enumeration.
   On the next prefix, lower-label summands vanish by upper triangularity,
   and higher-label summands vanish because the vector is in that prefix.
   The remaining sum is exactly the action of the literal diagonal
   submatrix. This retains the original generator and does not drop an
   off-diagonal term without justification.
6. **The restricted kernel and surjectivity are proved.** Within the next
   prefix, zero block projection is equivalent to membership in the previous
   prefix. The restriction matters: no false whole-space kernel identity is
   used. Every block vector has an explicit preimage obtained by extending
   its coefficient function by zero outside its fiber and applying the
   inverse basis-coordinate map. The preimage belongs to the next prefix.
7. **Saturation yields actual diagonal irreducibility.** For a diagonal
   invariant subspace `S`, the proof forms `T = F_(i+1) ∩ L⁻¹(S)` in the
   original ambient space. Prefix invariance and the proved intertwining
   identity make `T` common invariant. The previous prefix lies in `T`, and
   `T` lies in the next prefix. Saturation makes `T` one endpoint. In the
   first case, surjectivity plus the restricted kernel gives `S = 0`; in the
   second, surjectivity gives `S = top`. No irreducibility hypothesis or
   abstract quotient theorem is smuggled into the final contract.

Every step keeps the original quantifier over all generators. No compactness,
nonemptiness, or finite-family assumption appears. For an empty family every
subspace is invariant, so the saturated chain has irreducible one-dimensional
quotients; the same construction handles it without an exception. Infinite
families also need no enumeration. The final theorem assumes positive
ambient dimension exactly as frozen; its coordinate helpers allow zero
fibers where meaningful, while final surjectivity excludes them.

## Quality, reuse, and computational scope

The pinned Tau Ceti correctness, generality, proof-quality, attribution, and
reuse guidance was applied. The modules explain the actual chain, basis,
coordinate, and quotient constructions. The representation bridges have
concrete statements, and the short `change`/`rfl` steps expose the stated
coordinate definitions. The final assembly has no hidden condition or
opaque existence axiom. No required documentation correction was found.

The selected Mathlib reuse audit inspected the actual cover-sequence theorem
and its proof at `Order/OrderIsoNat.lean:305`, and the existing basis-flag
interface. Both retained files match the pinned Mathlib commit
`0df444a360eaa60ab8c11dca51a86af692955474`. A flag constructed from a preexisting
basis does not by itself provide an adapted basis or a saturated common
invariant flag, so the new construction is justified. Existing basis extension,
span/support, finite-dimension, matrix-composition, and coordinate APIs are
reused. This selected search is not an exhaustive claim about every library.

The proof is symbolic. It performs no matrix enumeration, numerical search,
interval grid, or floating-point computation. No new interval certificate is
needed for C15. Kernel-mode LeanCert settings and trust assertions remain in
the code; the separate numerical certificate obligations are outside this
approval. The source credits George Stepaniants, his department and Caltech,
Codex assistance, and retains imported mathematical authorship.

## Actual local evidence and limits

Root's actual250 receipt is bound by SHA256
`fbe862881c9d6f1e7c774afaf35056d6d3622eee60ad9a806df815a52271f3e3`.
C15's 15-module closure consists of one fresh final module and 14
exact-source-matched reused modules. C15 exited zero in
20.886902458034456 seconds. Its printed axioms are exactly `propext`,
`Classical.choice`, and `Quot.sound`. The recorded command uses Lean 4.33.1,
one thread, and a 4096 MiB limit. Actual250 has no failures, but its two other
fresh modules are not included in this C15 source approval.

For additional provenance, I traced all nine new source modules through the
recorded reuse chain to their matching successful compilations in runs 237,
238, 241, 243, 246, 248, 249, and 250, checking every intervening receipt hash,
source hash, and output hash. Their full successful logs were read and
retained. Some earlier runs also contain unrelated failures; those failures
are preserved and are not labeled whole-run successes. The bounded verifier
replays this chain without compiling anything.

This review does not claim final elaborated-type Comparator acceptance,
Linux kernel/sandbox execution, full MF06 approval, or an increase in the
number of verified original targets. Those remain separate gates.
