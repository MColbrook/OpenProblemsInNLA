# MF06 C29 — bounded independent source review

Reviewer: `/root/nm04_final_referee1`, 17 September 2026. This reviewer has not
authored MF06 proof/definition/statement sources and has run no Lean, Lake,
Comparator, or GitHub job. **Approve the exact successful C29 source**, SHA256
`c3e34bc086e424d5b9ec57dd1007ec8fbb44fc0e7b767d99e7ffd5f92b27c76d`.
No mathematical, alignment, or proof-quality blocker was found. No edit is
required by this review. This verdict is separate from C13 and C15 and does
not approve or count the full MF06 target.

The reviewed frozen contract is `allocation_tensor_norm_bridge`, C29. Its
literal header hash is
`0236a58e1cc81820df106160df92fea7d4a436976c580d758dc8238ad83d8185`.
I read the full AllocationNormBridge and AllocationDimensions modules, the
construction plan, the relevant frozen definitions and original solution §5,
especially equation (8), and the actual local244 log. Earlier independent
reviews covered the unchanged CompoundAlgebra and TensorAlgebra definitions
and norm machinery. All 20 project closure sources are retained and bound;
this scoped review does not claim to newly re-review every imported body.

The original equation (8) reorders each block's two exterior factors. The
frozen C29 target permits a fixed positive dimension factor and asks for every
original matrix `P`, without triangularity, invertibility, boundedness, or
positivity assumptions. The implementation proves precisely that header.
The same six independently frozen files remain unchanged.

The key lemma is an exact entry factorization. At each original block it
compares the two allocation degrees. If the second degree is larger, it uses
the second matrix entry for the max allocation and the first for the min;
otherwise it keeps their order. In each case **both row and column indices
move together**. Thus it does not create a mixed minor with unrelated row and
column degrees. Ties are harmless. The dependent indices have the required
max/min degrees after the explicit rewrites. Classical choice assembles the
finite coordinate tuples, and `Fintype.equivFin` with its inverse recovers
exactly those tuples. Multiplying the scalar identities gives the full entry
identity. Only commutativity of complex multiplication is used to swap factors.

The literal reindexed Kronecker entry is exactly the left-hand entry product.
The proof unfolds it, applies the exact factorization, takes the norm of a
product, and bounds each resulting entry by the genuine Euclidean operator
norm. The proved finite-matrix entry bound gives
`D = allocationDim b a * allocationDim b c`, cast to the reals. This constant
depends only on the fixed labeling and allocations, not on `P` or a later
word length. A sharper norm identity is unnecessary for the frozen existential
constant target or later root-growth comparison.

`allocation_dimensions` proves each allocation coordinate type is nonempty:
each degree lies between zero and its block dimension, so its actual exterior
basis is nonempty. Their dependent product is nonempty, including the empty
label product. Hence both dimensions are at least one and `D > 0`. The
argument covers empty fibers, degree zero, empty ambient/label spaces when
the supplied types exist, singular matrices, vanishing minors, and all-zero
entries. It never divides by an entry, a determinant, or a norm, and does not
form an inverse. All compound factors are evaluated on the same `P`.

The pinned Tau Ceti correctness, generality, proof-quality, attribution and
reuse guidance was applied within this scope. The coordinate-reordering
lemma and module documentation explain the representation bridge. Existing
entry and cardinality norm bounds are reused; no Hilbert tensor-norm theorem,
matrix enumeration, or interval grid is added. No numerical certificate is
needed for this symbolic C29 step. Kernel-mode LeanCert settings and trust
assertions are retained; the separate numerical certificate route is outside
this approval. Attribution to George Stepaniants and his department/Caltech,
Codex assistance, and imported prior authorship is preserved.

Root's actual development run 244 receipt has SHA256
`4742fb439e345b5311d3f53097e23543ecc0247d1f7e49d92df623b3b07f4084`.
It completes this 20-module closure with one fresh C29 compile and 19
exact-source-matched reused outputs. The C29 command exited zero in
20.331870292080566 seconds using Lean 4.33.1, one thread and 4096 MiB.
Both printed exports, the factorization lemma and final theorem, have exactly
`propext`, `Classical.choice`, and `Quot.sound`. Run 244 has no failed or blocked
modules. This is a local source/build result; no C29 Linux Comparator result
or full MF06 acceptance is claimed.

`python3 verify_review.py --live` rechecks these source/header/receipt/log
bindings. It performs only ordinary read-only evidence checks, never a
compiler or Comparator execution.
