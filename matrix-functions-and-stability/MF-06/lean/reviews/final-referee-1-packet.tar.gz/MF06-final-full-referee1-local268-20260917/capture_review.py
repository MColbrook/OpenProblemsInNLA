from pathlib import Path
import hashlib,json,shutil,gzip,datetime,difflib
R=Path(__file__).resolve().parent
B=Path('/private/tmp/nla-lean-next-20260915');P=B/'next-proofs/MF-06';L=Path('/private/tmp/nla-lean-local-shared-20260916');D=B/'MF06-type-diagnostics-270'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
copy_map={}
def keep(src,rel):
 src=Path(src);dest=R/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);copy_map[str(src)]={'path':str(rel),'sha256':sha(src)}
a=json.loads((B/'MF06-LOCAL-COMPLETE-268.json').read_text());assert sha(B/'MF06-LOCAL-COMPLETE-268.json')=='7c138cd627b595aa7e18c625cc39b73a673ed0434d6020664d77d769b2cdeaa6'
keep(B/'MF06-LOCAL-COMPLETE-268.json','evidence/LOCAL-COMPLETE-268.json')
for rel,h in a['sources'].items():
 assert sha(P/rel)==h==sha(B/'MF06-local268-source-snapshot'/rel)
 keep(P/rel,Path('source')/rel)
frozen=json.loads((P/'STATEMENT-FREEZE.json').read_text())['source_sha256']
for rel,h in frozen.items():
 assert sha(P/rel)==h
 if not (R/'source'/rel).exists():keep(P/rel,Path('source')/rel)
for rel in ['STATEMENT-FREEZE.json','STATEMENTS-FIRST.json','REUSE-SOURCE-PINS.json','lakefile.toml','lake-manifest.json','lean-toolchain','SOURCE-INPUTS.json','source-inputs/canonical/README.md','source-inputs/canonical/solution.md']:
 keep(P/rel,Path('source')/rel)
for f,h in a['retained_original_evidence'].items():
 assert sha(Path(f))==h
 keep(f,Path('evidence/origins')/Path(f).relative_to(L))
keep(a['assembly'],'evidence/ASSEMBLY-268.json')
for f in ['COMPARISON.json','CERTIFICATE-CONSUMPTION.json','certificate-body-route.json']:
 keep(D/f,Path('evidence/diagnostic270')/f)
for f in ['challenge-types.json','solution-types.json']:
 raw=(D/f).read_bytes();dest=R/'evidence/diagnostic270'/(f+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));copy_map[str(D/f)]={'path':str(dest.relative_to(R)),'sha256':sha(D/f),'gzip':True}
for f in sorted((D/'sources/NLA/MF06Diagnostics').glob('*.lean')):
 keep(f,Path('evidence/diagnostic270/sources')/(f.name+'.txt'))
for f in [L/'runs/development-270/RECEIPT.json',L/'ASSEMBLY-270.json']:
 keep(f,Path('evidence/diagnostic270')/f.name)
for f in sorted((L/'runs/development-270').glob('*.log')):
 keep(f,Path('evidence/diagnostic270/logs')/f.name)
prior=['MF06-C13-source-referee1-20260917','MF06-C15-source-referee1-20260917','MF06-C29-source-referee1-20260917','MF06-C17-C23-early-referee1-20260917','MF06-C17-C23-comment-continuation-referee1-20260917','MF06-transfer-C32-C34-C35-C36-referee1-20260917']
refs={}
for n in prior:
 Q=B/'reviews'/n;mf=next(Q.glob('MANIFEST*'));refs[n]={'manifest':mf.name,'manifest_sha256':sha(mf)}
 for f in [Q/'SCOPE.json',Q/'REVIEW.md',Q/'VERDICT.json',mf]:
  if f.is_file():keep(f,Path('prior-review-records')/n/f.name)
T=B/'reviews/MF06-transfer-C32-C34-C35-C36-referee1-20260917/standards'
for f in sorted(T.rglob('*')):
 if f.is_file():keep(f,Path('standards')/f.relative_to(T))
old=json.loads((L/'runs/development-264/RECEIPT.json').read_text())['source_inputs'];diffs={}
for f,h in a['sources'].items():
 if f in old and old[f]!=h:
  before=B/'MF06-local264-source-snapshot'/f;keep(before,Path('evidence/changes264')/f)
  txt=''.join(difflib.unified_diff(before.read_text().splitlines(True),(P/f).read_text().splitlines(True),fromfile=f+'@264',tofile=f+'@268'))
  diffs[f]={'before':old[f],'after':h,'diff':txt}
(R/'evidence/changes264/CHANGES.json').write_text(json.dumps(diffs,indent=2)+'\n')
ledger=json.loads((R/'READ-LEDGER-DRAFT.json').read_text())
ledger['current_full_reads']=sorted(set(ledger['current_full_reads'])|set(ledger['not_yet_full_reread']))
ledger['not_yet_full_reread']=[];ledger['reviewed_source_sha256']=a['sources'];ledger['scope_note']='All 119 project closure sources have complete personal reads in this final review or the named exact-source earlier bounded reviews. Library packages remain pinned dependencies; this is not a new review of all Mathlib/LeanCert implementations.'
(R/'READ-LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n')
(R/'READ-LEDGER-DRAFT.json').unlink()
scope={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/nm04_final_referee1','reviewer_is_nonauthor':True,'reviewer_authored_proof_or_frozen_definition_sources':False,'reviewer_Lean_Lake_Comparator_runs':False,'did_read_other_final_referee_verdict_before_own_conclusions':False,'scope':'Independent complete-original-target mathematical and code source review for MF-06, bound to all119 local268 closure sources and all38 original contracts; not publication-package approval or Linux/runtime acceptance.','project':str(P),'immutable_source_snapshot':str(B/'MF06-local268-source-snapshot'),'local_complete_sha256':sha(B/'MF06-LOCAL-COMPLETE-268.json'),'local_complete_modules':119,'frozen_contracts':38,'proof_sources':a['sources'],'frozen':frozen,'pinned_compiler_sha256':'1b370cfcbf44e80d1b1ab9a4c73951f9f7c242140bcff9bc577576554','mathlib_revision':'0df444a360eaa60ab8c11dca51a86af692955474','leancert_revision':'621a43d7cf21f87872392a01e874f2f1dbddc926','prior_bounded_review_references':refs,'live_evidence':copy_map,'independent_Linux_Comparator':'not yet run for this candidate','count_change':0}
# Exact compiler pin is copied from actual receipt, avoiding manually transcribed trust data.
scope['pinned_compiler_sha256']=json.loads(Path(a['receipt']).read_text())['compiler_sha256']
(R/'SCOPE.json').write_text(json.dumps(scope,indent=2)+'\n')
print('captured',len(copy_map),'source/record items, all119 sources, six frozen files, all217 original evidence files; compressed original type dumps retained losslessly')
