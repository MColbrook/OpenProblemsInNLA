#!/usr/bin/env python3
"""Read-only evidence/integrity replay. Does NOT invoke Lean, Lake, Comparator or network.
Default uses retained bytes. --live also authenticates current sources, original
records, frozen snapshot and local olean outputs against the reviewed evidence.
It cannot substitute for mathematical review or an independently executed kernel.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,re
R=Path(__file__).resolve().parent
args=argparse.ArgumentParser();args.add_argument('--live',action='store_true');aargs=args.parse_args()
checks=0
def ck(ok,msg):
 global checks
 checks+=1
 if not ok:raise AssertionError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def j(rel):return json.loads((R/rel).read_text())
def strip_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2
  elif depth and s.startswith('-/',i):depth-=1;i+=2
  elif depth:i+=1
  elif s.startswith('--',i):
   p=s.find('\n',i);i=len(s) if p<0 else p
  else:out.append(s[i]);i+=1
 ck(depth==0,'balanced Lean comments')
 return ''.join(out)
manifest=j('MANIFEST.json')
ck(set(manifest)=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p != R/'MANIFEST.json'},'exact review payload inventory')
for rel,h in manifest.items():ck(sha((R/rel).read_bytes())==h,'manifest '+rel)
s=j('SCOPE.json');agg=j('evidence/LOCAL-COMPLETE-268.json');headers=j('source/STATEMENT-HEADERS.json')['headers'];cfg=j('source/comparator.json')
ck(sha((R/'evidence/LOCAL-COMPLETE-268.json').read_bytes())==s['local_complete_sha256'],'complete record binding')
ck(s['reviewer_is_nonauthor'] and not s['reviewer_authored_proof_or_frozen_definition_sources'],'nonauthor scope')
ck(not s['reviewer_Lean_Lake_Comparator_runs'] and s['count_change']==0,'honest no reviewer compiler/count')
ck(not s['did_read_other_final_referee_verdict_before_own_conclusions'],'independence scope')
ck(len(headers)==38 and [h['declaration'] for h in headers]==cfg['theorem_names'],'all38 contract map')
ck(set(cfg['permitted_axioms'])=={'propext','Classical.choice','Quot.sound'},'exact permitted axioms')
ck(len(s['proof_sources'])==119 and agg['sources']==s['proof_sources'],'119 source map')
ck(agg['exact_contracts']==38 and agg['actual_local_closure_modules']==119 and agg['count_change']==0,'aggregate limited scope')
for rel,h in s['frozen'].items():ck(sha((R/'source'/rel).read_bytes())==h,'frozen '+rel)
freeze=j('source/STATEMENT-FREEZE.json')
ck(freeze['source_sha256']==s['frozen'] and len(freeze['accepted_reviews'])==2 and freeze['proof_implementation_authorized'],'reviewed pre-body frozen boundary')
code={};imports={}
for rel,h in s['proof_sources'].items():
 raw=(R/'source'/rel).read_bytes();ck(sha(raw)==h,'source '+rel);t=strip_comments(raw.decode());code[rel]=t
 bad=re.search(r'\b(?:sorry|sorryAx|admit|axiom|unsafe|native_decide|ofReduceBool|implemented_by|extern)\b|^\s*(?:run_cmd|run_tac|initialize|elab|macro)\b',t,re.M)
 ck(bad is None,'forbidden proof command/token '+rel+': '+(bad.group(0) if bad else ''))
 ck(not re.search(r'import\s+.*Challenge',t),'no Challenge import '+rel)
 ck(not re.search(r'leancert.trust\s+"(?!kernel")',t),'kernel trust only '+rel)
 mod=rel[:-5].replace('/','.');deps=[]
 for line in re.findall(r'^import\s+([^\n]+)',t,re.M):
  for dep in line.split():
   if dep.startswith('NLA.') or dep=='Solution':deps.append(dep)
   else:ck(dep.startswith(('Mathlib.','LeanCert.')),'known pinned package import '+dep)
 imports[mod]=deps
allmods={p[:-5].replace('/','.') for p in s['proof_sources']}
seen=set()
def visit(m):
 if m in seen:return
 ck(m in imports,'source import exists '+m);seen.add(m)
 for d in imports[m]:visit(d)
visit('Solution');ck(seen==allmods,'entire exact119 Solution closure')
challenge=strip_comments((R/'source/Challenge.lean').read_text())
for h in headers:
 ck(sha(h['header'].encode())==h['header_sha256'],'frozen header hash '+h['id'])
 ck(h['header']+' := by' in challenge,'literal Challenge header '+h['id'])
 matches=[rel for rel,t in code.items() if h['header']+' := by' in t]
 ck(len(matches)==1,'unique literal proof header '+h['id'])
 ck('#print axioms '+h['declaration'] in code['Solution.lean'],'Solution axiom export '+h['id'])
 ck('#assert_trust kernel '+h['declaration'] in code['Solution.lean'],'Solution trust export '+h['id'])
ledger=j('READ-LEDGER.json');ck(not ledger['not_yet_full_reread'],'read coverage finished')
ck(set(ledger['current_full_reads'])|set(ledger['prior_full_reads'])==set(s['proof_sources']),'full personal reads or exact reviewed continuation for119')
ck(ledger['reviewed_source_sha256']==s['proof_sources'],'read ledger exact bytes')
# Authenticate retained raw evidence against original hash map, without treating a
# success summary as an independent proof-checker execution.
raw_by_original={}
for original,v in s['live_evidence'].items():
 b=(R/v['path']).read_bytes();b=gzip.decompress(b) if v.get('gzip') else b
 ck(sha(b)==v['sha256'],'retained original '+original);raw_by_original[original]=b
 if aargs.live:ck(Path(original).is_file() and sha(Path(original).read_bytes())==v['sha256'],'live original '+original)
def orig_json(path):return json.loads(raw_by_original[path])
for original,h in agg['retained_original_evidence'].items():ck(original in raw_by_original and sha(raw_by_original[original])==h,'all217 retained evidence '+original)
receipt=orig_json(agg['receipt'])
ck(sha(raw_by_original[agg['receipt']])==agg['receipt_sha256'],'actual268 receipt')
ck(receipt['completed_modules']==119 and not receipt['failed_modules'] and not receipt['blocked_modules'] and receipt['end'],'actual268 terminal all119')
ck(receipt['max_compiler_processes']==1 and receipt['threads']==1 and receipt['memory_cap_mib']==4096,'actual single compiler limits')
ck(receipt['compiler_sha256']==s['pinned_compiler_sha256'] and receipt['platform']=='darwin','actual compiler/platform')
cmds={c['module']:c for c in receipt['commands']}
ck(set(cmds)==allmods,'actual268 modules exact closure')
ck(sum('argv' in c for c in cmds.values())==2 and sum(c.get('status')=='reused_exact_successful_local_output' for c in cmds.values())==117,'two fresh117 exact reuses')
origins={v['module']:v for v in agg['commands_and_successful_origins']};ck(set(origins)==allmods,'all119 successful origins')
outputs={m:o['command']['output_sha256'] for m,o in origins.items()}
for m,o in origins.items():
 rel=o['canonical_source_path'];expected=s['proof_sources'][rel]
 ck(o['source_sha256']==expected,'origin source '+m)
 rr=orig_json(o['success_origin_receipt']);fc=next(c for c in rr['commands'] if c['module']==m)
 ck(fc==o['command'] and fc['exit_code']==0 and fc['end'],'actual fresh successful command '+m)
 ck(sha(raw_by_original[o['success_origin_receipt']])==o['receipt_sha256'],'fresh receipt '+m)
 ck(fc['source_sha256']==expected and rr['compiler_sha256']==s['pinned_compiler_sha256'],'fresh source/compiler '+m)
 memory_flags=[x for x in fc['argv'] if x.startswith('--memory=')]
 ck('--threads=1' in fc['argv'] and len(memory_flags)==1 and 0<int(memory_flags[0].split('=')[1])<=4096,'fresh limits '+m)
 ck(set(fc['dependency_olean_sha256'])==set(imports[m]),'fresh direct import coverage '+m)
 for d,h in fc['dependency_olean_sha256'].items():ck(outputs[d]==h,'fresh dependency output '+m+' '+d)
 log=str(Path(o['success_origin_receipt']).parent/(m+'.log'));lb=raw_by_original[log]
 ck(sha(lb)==fc['log_sha256'],'fresh log '+m)
 lt=lb.decode();ck(not re.search(r'\berror:|\bsorryAx\b|\bLean.ofReduceBool\b',lt),'fresh log no errors/untrusted axioms '+m)
 for ax in re.findall(r'depends on axioms:\s*\[([^\]]*)\]',lt):
  ck(set(x.strip() for x in ax.split(',') if x.strip())<=set(cfg['permitted_axioms']),'fresh log axiom list '+m)
 path=agg['receipt'];visited=set()
 while True:
  ck(path not in visited,'acyclic reuse '+m);visited.add(path);pr=orig_json(path);c=next(c for c in pr['commands'] if c['module']==m)
  ck(c['source_sha256']==expected and c['output_sha256']==outputs[m],'reuse source/output '+m)
  if 'argv' in c:
   ck(path==o['success_origin_receipt'] and c==fc,'reuse reaches exact fresh origin '+m);break
  ck(c['status']=='reused_exact_successful_local_output','recognized reuse '+m)
  # The original development-02 record predates receipt-link reuse and embeds
  # the complete development-01 command for the dependency-free MF07 definitions.
  if 'transitive_source_hashes' not in c:
   ck(m=='NLA.MF07.Definitions' and not imports[m] and c.get('prior_command')==fc,'exact authenticated legacy dependency-free reuse')
   break
  for rp,rh in c['transitive_source_hashes'].items():ck(s['proof_sources'].get(rp)==rh,'reuse transitive source '+m+' '+rp)
  path=c['prior_receipt'];ck(sha(raw_by_original[path])==c['prior_receipt_sha256'],'reuse prior receipt '+m)
 if aargs.live:
  out=Path(fc['argv'][fc['argv'].index('-o')+1]);ck(sha(out.read_bytes())==outputs[m],'current actual olean '+m)
solution_origin=origins['Solution'];sl=raw_by_original[str(Path(solution_origin['success_origin_receipt']).parent/'Solution.log')].decode()
parsed={name:set(v.strip() for v in vals.split(',')) for name,vals in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",sl)}
ck(set(parsed)==set(cfg['theorem_names']),'actual final log all38 exact names')
for name in cfg['theorem_names']:ck(parsed[name]==set(cfg['permitted_axioms']),'actual final std3 '+name)
# Independently recompute the recorded diagnostic comparison from original dumps.
dbase='evidence/diagnostic270/'
ch=json.loads(gzip.decompress((R/(dbase+'challenge-types.json.gz')).read_bytes()));so=json.loads(gzip.decompress((R/(dbase+'solution-types.json.gz')).read_bytes()));comp=j(dbase+'COMPARISON.json')
ck(len(ch)==len(so)==38,'actual type dump38')
ck([r['name'] for r in ch]==cfg['theorem_names']==[r['name'] for r in so],'diagnostic name scope')
for x,y in zip(ch,so):
 ck(x['levelParams']==y['levelParams'],'universe match '+x['name'])
 ck(x['binderNormalizedType']==y['binderNormalizedType'],'elaborated type match '+x['name'])
ck(comp['all38_match'] and comp['source_complete_record_sha256']==s['local_complete_sha256'],'diagnostic binding')
ck(sha(gzip.decompress((R/(dbase+'challenge-types.json.gz')).read_bytes()))==comp['challenge_dump_sha256'],'challenge dump raw SHA')
ck(sha(gzip.decompress((R/(dbase+'solution-types.json.gz')).read_bytes()))==comp['solution_dump_sha256'],'solution dump raw SHA')
ct=(R/(dbase+'sources/ChallengeTypes270.lean.txt')).read_text();st=(R/(dbase+'sources/SolutionTypes270.lean.txt')).read_text()
ck(ct.split('\nprivate def diagnosticEraseBinderNames')[0].rstrip()==(R/'source/Challenge.lean').read_text().replace('import NLA.MF06.Definitions','import NLA.MF06.Definitions\nimport Lean',1).rstrip(),'independently elaborated exact Challenge boundary')
ck(st.startswith('import NLA.MF06.CanonicalLower\nimport Lean\n'),'diagnostic actual proof import')
ck('ci.value? (allowOpaque := true)' in st and 'body.getUsedConstants' in st,'actual opaque body read')
drec=j(dbase+'RECEIPT.json');ck(not drec['failed_modules'] and not drec['blocked_modules'] and drec['end'],'actual270 terminal success')
ck(sha((R/(dbase+'RECEIPT.json')).read_bytes())==comp['receipt_sha256'],'actual270 receipt binding')
for c in drec['commands']:
 if 'argv' not in c:continue
 rel=c['argv'][-1];p=R/(dbase+'sources/'+Path(rel).name+'.txt');ck(sha(p.read_bytes())==c['source_sha256'],'diagnostic source '+c['module'])
 ck(c['exit_code']==0 and sha((R/(dbase+'logs/'+c['module']+'.log')).read_bytes())==c['log_sha256'],'diagnostic actual success/log '+c['module'])
body=j(dbase+'certificate-body-route.json');br={r['name']:set(r['bodyConstants']) for r in body};cons=j(dbase+'CERTIFICATE-CONSUMPTION.json')
ck(sha((R/(dbase+'certificate-body-route.json')).read_bytes())==cons['body_dump_sha256'],'actual body dump binding')
for path in cons['actual_consumption_paths']:
 for x,y in zip(path,path[1:]):ck(y in br[x],'genuine certificate body edge '+x+' -> '+y)
ck('LeanCert.Validity.verify_strict_upper_bound_dyadic_checked' in br['NLA.MF05.half_radius_certificate'],'kernel LeanCert theorem in actual certificate body')
ck('interval_decide (trust := kernel)' in code['NLA/MF05/Numerical.lean'],'kernel mode literal certificate')
if aargs.live:
 for rel,h in s['proof_sources'].items():
  ck(sha((Path(s['project'])/rel).read_bytes())==h,'live candidate source '+rel)
  ck(sha((Path(s['immutable_source_snapshot'])/rel).read_bytes())==h,'immutable local268 source '+rel)
 for rel,h in s['frozen'].items():ck(sha((Path(s['project'])/rel).read_bytes())==h,'live frozen '+rel)
print(json.dumps({'result':'PASS','checks':checks,'scope':'Read-only full-source review integrity and actual local268/270 evidence replay; no reviewer compiler/Comparator execution','live':aargs.live,'local_proof_modules':119,'contracts':38,'count_change':0}))
